<?php 
include $_SERVER['DOCUMENT_ROOT']."/includes/database.php";
include $_SERVER['DOCUMENT_ROOT']."/data/locales.php";

function mkdir_split($id,$path) {
  $a = $path;
  while (strlen($id) > 0) {
    $a .= "/".substr($id,0,1);
    $id = substr($id,1,99);
    if (!file_exists($a)) {
      exec("mkdir --mode=777 ".$a);
    }
  }
  $a .= "/";
  return $a;
}

function split_id($id) {
      while (strlen($id) > 0) {
        $a .= "/".substr($id,0,1);
        $id = substr($id,1,99);
      }
      $a .= "/";
      return $a;
    }
    
function logevent($description) {
	global $client_path,$myuser;
	$handle = fopen($_SERVER['DOCUMENT_ROOT']."/cdata/".$client_path."/logs/".$client_path."_".date("Y-m-d",time())."_log.txt","a");
	fwrite($handle,"\"".date("Y-m-d H:i:s",time())."\",\"".$_SERVER['REQUEST_URI']."\", ".$_SERVER['HTTP_X_FORWARDED_FOR'].",\"".$myuser['userid']."\",\"".$myuser['fname']." ".$myuser['lname']."\",\"".$description."\"\n");
	fclose($h);
	
}

$career_types = array(0=>"Full-Time",1=>"Part-Time",2=>"Freelance",3=>"Internship");

$status = array("Pending", "Shipped", "Canceled");

$dow = array(
	"1" =>"Monday",
	"2" =>"Tuesday",
	"3" =>"Wednesday",
	"4" =>"Thursday",
	"5" =>"Friday",
	"6" =>"Saturday",
	"7" =>"Sunday"
	);

$months = array(
  "1" => "January",
  "2" => "February",
  "3" => "March",
  "4" => "April",
  "5" => "May",
  "6" => "June",
  "7" => "July",
  "8" => "August",
  "9" => "September",
  "10" => "October",
  "11" => "November",
  "12" => "December",
);

function filesize_format($bytes, $format = '', $force = '') {
  $force = strtoupper($force);
  $defaultFormat = '%01d %s';
  
  if (strlen($format) == 0) $format = $defaultFormat;
  
  $bytes = max(0, (int) $bytes);
  $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
  $power = array_search($force, $units);
  
  if ($power === false) $power = $bytes > 0 ? floor(log($bytes, 1024)) : 0;

  return sprintf($format, $bytes / pow(1024, $power), $units[$power]);
}

//Current Start item number | Total Items | Display Per Page | URL To Append stuff
function paging($pno,$items,$ippage,$url,$width) {
  $pages = $items / $ippage;
  $current_page = floor($pno / $ippage)+1;


  if (!strpos($url,"?")) { $url .= "?"; } else { $url .= "&"; }

  $return .= "<div style='width:".$width.";'>\n";
  $return .= "<div style='float:right;'>\n";
  $return .= "<div class='pno_text'>Page&nbsp;</div>";
  for ($x=0;$x<$items;$x=$x+$ippage) {
    $page++;
    if ($current_page == $page) {
      $return .= "<div class='pno_on'>".$page."</div>\n";
    } elseif ($page >= ($current_page-6) && $page <= ($current_page+6)) {
      $return .= "<div class='pno_off' onClick=\"location.href='".$url."start=".(($page-1)*$ippage)."';\" onmouseover=\"this.className='pno_hover';\" onmouseout=\"this.className='pno_off';\">".$page."</div>\n";
    } elseif ($page == $current_page-7) {
      $return .= "<div class='pno_off' onClick=\"location.href='".$url."start=".(($page-1)*$ippage)."';\" onmouseover=\"this.className='pno_hover';\" onmouseout=\"this.className='pno_off';\">&lt;</div>\n";
    } elseif ($page == $current_page+7) {
      $return .= "<div class='pno_off' onClick=\"location.href='".$url."start=".(($page-1)*$ippage)."';\" onmouseover=\"this.className='pno_hover';\" onmouseout=\"this.className='pno_off';\">&gt;</div>\n";
    }
  }

  return $return;
}

function clean_up($str){
  $str = stripslashes($str);
  $str = strtr($str, get_html_translation_table(HTML_ENTITIES));
  $str = str_replace( array("\x82", "\x84", "\x85", "\x91", "\x92", "\x93", "\x94", "\x95", "\x96",  "\x97"), array("&#8218;", "&#8222;", "&#8230;", "&#8216;", "&#8217;", "&#8220;", "&#8221;", "&#8226;", "&#8211;", "&#8212;"),$str);
  return $str;
}

if(!function_exists('format_phone')) {
	function format_phone($sPhone){
	$sPhone = ereg_replace("[^0-9]",'',$sPhone);
	
	switch(strlen($sPhone)) {
		case 10:
			$sArea = substr($sPhone,0,3);
			$sPrefix = substr($sPhone,3,3);
			$sNumber = substr($sPhone,6,4);
			$sPhone = "(".$sArea.") ".$sPrefix."-".$sNumber;
		break;
		case 7:
			$sPrefix = substr($sPhone,0,3);
			$sNumber = substr($sPhone,3,4);
			$sPhone = $sPrefix."-".$sNumber;	
		break;
		default:
		break;
	}
	
	return($sPhone);
	}
}

if(!function_exists('send_email')) {
	function send_email($from_email, $from_name, $to_email, $subject, $body, $html='true', $cc='', $files='') {
		require_once($_SERVER['DOCUMENT_ROOT']."/includes/phpmailer.php");
		$mail = new PHPMailer();
		$mail->From = $from_email;
		$mail->AddAddress($to_email);
		if ($cc) {
			$mail->AddCC($cc);
		}
		$mail->IsHTML($html);
		$mail->FromName = $from_name;
		$mail->Subject = $subject;
		$mail->Body = $body;

		if (is_array($files)) {
			foreach ($files as $key => $file) {
				$mail->AddAttachment($file);
			}
		}

		if (!$mail->Send()) {
			return true;
		}
		else {
			return false;
		}
	}
}


function display_io_web($oid) {
	$query = "SELECT * FROM orders WHERE OID='".$oid."'";
	$order = mysql_fetch_assoc(mysql_query($query));

	$company = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['CID']."'"));

	if ($order['AID']) {
		$agency = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['AID']."'"));
	}
	$rep = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE userid='".$company['company_primary_rep']."'"));

	if ($order['IID']=="0") { 
		$contact = mysql_fetch_assoc(mysql_query("SELECT * FROM contacts where CID='".$order['CID']."' and primary_contact='1'"));
	} 
	else {
		$contact = mysql_fetch_assoc(mysql_query("SELECT * FROM contacts where IID='".$order['IID']."'")); 	 
	}

	# Automatically show the 944 barter template if the order has barter attached to it
	$order_has_barter = get_order_total_barter($oid);

	if ($order['CTID'] == 1 && $order_has_barter > 0) {
		$order['CTID'] = 4;
	}

	$ct = mysql_fetch_assoc(mysql_query("SELECT * FROM contract_templates WHERE CTID='".$order['CTID']."'"));

	$result = mysql_query("SELECT * FROM line_items");
	while ($row = mysql_fetch_assoc($result)) {
		$li[$row['LID']]['name'] = $row['lineitem_name'];
		$li[$row['LID']]['dbname'] = $row['lineitem_dbfield'];
	}

	$lfields = explode(",",$ct['ct_lineitems']);
	// $output .= "<!--START-->\n";
	$output .= "<table width=800 cellpadding=0 cellspacing=6 style='background:#FFFFFF;border:1px solid #A0A0A0;'>";
	$output .= "<tr>";
	$output .= "<td colspan=3 align=center style='padding:20px;'><img src='/images/contract_templates/".$ct['CTID'].".jpg'></td>";
	$output .= "</tr>";

	$output .= "<tr>";
	$output .= "<td colspan=3 align=center style='font:normal 32px arial;padding-bottom:20px;'>".$ct['ct_title']."</td>";
	$output .= "</tr>";

	$output .= "<tr>";

	$output .= "<td valign=top width=37% style='padding-left:20px;'>";
	$output .= "<div style='font:bold 13px arial;'>Advertiser Bill To</div>";
	$output .= $company['company_name']."<br>";
	$output .= $contact['contact_firstname']." ".$contact['contact_lastname']."<br>";
	$output .= $contact['contact_address']."<br>";
	if ($contact['contact_address2'] != "") { $output .= $contact['contact_address2']."<br>"; } 
	$output .= $contact['contact_city'].", ".$contact['contact_state']." ".$contact['contact_zip'];
	$output .= "</td>";

	$output .= "<td valign=top width=30%>";
	if ($agency['company_name'] || $agency['company_address']) :
		$output .= "<div style='font:bold 13px arial;'>Ad Agency</div>";
		$output .= $agency['company_name']."<br>";
		$output .= $agency['company_address']."<br>";
		$output .= $agency['company_address2']."<br>";
		$output .= $agency['company_city'];
		if ($agency['company_city'] && $agency['company_state']) {
			$output .= ', ';
		}
		$output .= $agency['company_state']." ".$agency['company_zip'];
	endif;
	$output .= "</td>";

	$output .= "<td valign=top width=33% style='padding-right:20px;'>";
	$output .= "<div style='font:bold 13px arial;'>Publisher</div>";
	$output .= "Rep: ".$rep['fname']." ".$rep['lname']."<br>";
	if ($rep['phone_work']) {
		$output .= format_phone($rep['phone_work'])."<br>";
	}
	$output .= $rep['email']."<br>";
	$output .= "Contract Date: ".date("m/d/Y",strtotime($order['created_date']))."<br>";
	$output .= "Contract Number: ".$oid."";
	$output .= "</td>";

	$output .= "</tr>";

	$output .= "<tr><td colspan=3 align=right style='padding-left:10px;padding-right:10px;'>";

	$output .= "<hr size=1>\n\n";

	############ AD SALES #############

	$query  = "SELECT oa.net-oa.barter AS cashnet,";
	$query .= "oa.price AS ratecardprice, ";
	$query .= "oa.agency_discount AS agencydiscount, ";
	$query .= "oa.gross, ";
	$query .= "oa.barter, ";
	$query .= "oa.other_discount AS otherdiscount, ";
	$query .= "s.ad_size_name AS adsize,";
	$query .= "p.pub_name AS publication,";
	$query .= "i.iss_name AS issue, ";
	$query .= "asz.ad_size_name AS adsize, ";
	$query .= "c.ad_color_name AS color, ";
	$query .= "ap.ad_position_name AS premiumposition, ";
	$query .= "note AS adnotes, ";
	$query .= "rd.def_name AS ratecardname ";
	$query .= "FROM orders_adsales AS oa ";
	$query .= "INNER JOIN ad_size AS s ON oa.SizeID=s.sizeID ";
	$query .= "INNER JOIN pubs AS p ON oa.PubID=p.id ";
	$query .= "INNER JOIN issues AS i ON oa.IssueID=i.id ";
	$query .= "INNER JOIN ad_color AS c ON c.colorID=oa.ColorID ";
	$query .= "INNER JOIN ad_size AS asz ON asz.sizeID=oa.SizeID ";
	$query .= "INNER JOIN ratecard_def AS rd ON rd.defID=oa.DefID ";
	$query .= "INNER JOIN ad_position AS ap ON ap.positionID=oa.PosID ";
	$query .= "WHERE oa.OID='".$oid."' ";
	$query .= "ORDER BY i.iss_report_date, oa.OAID";
	$result = mysql_query($query) or die(mysql_error());
	if (mysql_num_rows($result)) {
		$x = 0;
		$output .= "<table width=100% cellpadding=0 cellspacing=1>\n";
		while ($row = mysql_fetch_assoc($result)) {
			$x++;
			unset($lrow);
			foreach ($lfields AS $key => $value) {
				if ($x==1) {
					$ltitle .= "<td align=left><b>".$li[$value]['name']."</b></td>\n";
				}
				$lrow .= "<td align=left>".(($row[$li[$value]['dbname']])?($row[$li[$value]['dbname']]):("&nbsp;"))."</td>\n";
			}
			$lrow = "<tr>".$lrow."</tr>";
			$lrows .= $lrow;

			$order_total += $row['cashnet'];
			$order_barter += $row['barter'];
		}
		$output .= "<tr>\n".$ltitle."</tr>\n";
		$output .= $lrows;
		$output .= "</table>\n";
		$output .= "<hr size=1>\n\n";
	}


	############ SERVICES #############

	$query  = "SELECT * ";
	$query .= "FROM orders_services AS os ";
	$query .= "INNER JOIN services AS s ON os.SID=s.sID ";
	//$query .= "INNER JOIN service_categories AS sc ON s.scatID=sc.scatID ";
	$query .= "WHERE OID='".$oid."'";

	$result = mysql_query($query) or die(mysql_error());
	if (mysql_num_rows($result)) {
		$output .= "<table width=100% cellpadding=0 cellspacing=10>\n";
		$output .= "<tr>\n";
		$output .= "<td align=left nowrap><b>Service Name</b></td>\n";
		$output .= "<td align=left colspan=3><b>Notes</b></td>\n";
		$output .= "<td align=right nowrap><b>Cash Net</b></td>\n";
		$output .= "<td align=right><b>Barter</b></td>\n";
		/// $output .= "<td align=right><b>Barter</b></td>\n";
		$output .= "</tr>\n";

		while ($row = mysql_fetch_assoc($result)) {
			$output .= "<tr>\n";
			$output .= "<td align=left>".$row['service_name']."</td>\n";
			$output .= "<td align=left colspan=3>".$row['order_note']."</td>\n";
			$output .= "<td align=right>".number_format($row['order_total'], 2, '.', ',')."</td>\n";
			$output .= "<td align=right>".number_format($row['order_barter'], 2, '.', ',')."</td>\n";
			/// $output .= "<td align=right>".$row['order_barter']."</td>\n";
			$output .= "</tr>\n";
			$order_total += $row['order_total'];
			$order_barter += $row['order_barter'];
		}
		$output .= "</table>\n";
		$output .= "<hr size=1>\n";
	}


	############### COMMON FOOTER ##############
	if ($order['comments']) { $output .= "<center><b>Notes: </b>".$order['comments']."</center>"; }

	if ($order_barter) {
		$output .= "<b>Barter Due:</b> \$".number_format($order_barter,2)."<br>\n";
	}
	$output .= "<b>Cash Due:</b> \$".number_format($order_total,2)."\n";
	$output .= "</td></tr>\n";

	$output .= "<tr><td colspan=3 valign=top style='padding:20px;'>";
	$output .= $ct['ct_body'];
	$output .= "</td></tr>\n";

	$output .= "</table>\n\n";
	// $output .= "<!--END-->\n";
	
	return $output;
}

function display_io_print ($oid) {
	if ($oid) {
	  $query = "SELECT * FROM orders WHERE OID='".$oid."'";
	  $order = mysql_fetch_assoc(mysql_query($query));
	  $company = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['CID']."'"));

	  if ($order['AID']) {
	    $agency = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['AID']."'"));
	  }

	  $rep = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE userid='".$company['company_primary_rep']."'"));
	    if ($order['IID']=="0") { 
	  	$contact = mysql_fetch_assoc(mysql_query("SELECT * FROM contacts where CID='".$order['CID']."' and primary_contact='1'"));
	   } else {
	    $contact = mysql_fetch_assoc(mysql_query("SELECT * FROM contacts where IID='".$order['IID']."'")); 	 
	  }
	}

	# Automatically show the 944 barter template if the order has barter attached to it
	$order_has_barter = get_order_total_barter($oid);

	if ($order['CTID'] == 1 && $order_has_barter > 0) {
		$order['CTID'] = 4;
	}

	$ct = mysql_fetch_assoc(mysql_query("SELECT * FROM contract_templates WHERE CTID='".$order['CTID']."'"));

	$result = mysql_query("SELECT * FROM line_items");
	while ($row = mysql_fetch_assoc($result)) {
	  $li[$row['LID']]['name'] = $row['lineitem_name'];
	  $li[$row['LID']]['dbname'] = $row['lineitem_dbfield'];
	}

	$lfields = explode(",",$ct['ct_lineitems']);
	$html .="

	<style>
	.row { border-bottom:1px solid #000000; }
	</style>
	";
	//$html .= "<div style='text-align:left'><img src='http://".$client_path.".944x.com/cdata/".$client_path."/contract_templates/".$ct['CTID'].".jpg'></div>";
	if ($ct['ct_title']!="") { 
		$html .="<center><xlarge>".$ct['ct_title']."</xlarge></center>";
	}

	$html .= "<table width=100% cellpadding=0 cellspacing=6>";
	$html .= "<tr>";

	//$html .= "<td valign=top>";
	if ($ct['ct_type']=="1") {
	  $html .= "<td valign=top>";
	  $html .= "<b>Advertiser</b></td>";
	  $html .= "<td valign=top>";
	  $html .= "<b>Ad Agency</b></td>";
	  $html .= "<td valign=top>";
	  $html .= "<b>Publisher</b></td>";
	} else {
	  $html .= "<td valign=top>";
	  $html .= "<b>Bill To:</b></td>";
	  $html .= "<td valign=top>";
	  $html .= "<b>Sales Rep</b></td>";
	}


	$html .="</tr><tr>";

	$html .= "<td>";
	$html .= $company['company_name']."<br>";
	$html .= $contact['contact_firstname']." ".$contact['contact_lastname']."<br>";
	$html .= $contact['contact_address']."<br>";
	$html .= $contact['contact_address2']."<br>";
	$html .= $contact['contact_city'].", ".$contact['contact_state']." ".$contact['contact_zip'];
	$html .= "</td>";
	if ($ct['ct_type']=="1") {
	  $html .= "<td>";
	  if ($agency['company_name'] || $agency['company_address']) :
		  $html .= $agency['company_name']."<br>";
		  $html .= $agency['company_address']."<br>";
		  $html .= $agency['company_address2']."<br>";
		  $html .= $agency['company_city'].", ".$agency['company_state']." ".$agency['company_zip'];
	  endif;
	  $html .= "</td>";
	}

	$html .= "<td>";
	if ($ct['ct_type']=="1") {
	  $html .= "Rep: ";
	}
	$html .= $rep['fname']." ".$rep['lname']."<br>";
	if ($rep['phone_work']) {
	  $html .= format_phone($rep['phone_work'])."<br>";
	}
	$html .= $rep['email']."<br>";
	$html .= "Contract Date: ".date("m/d/Y",strtotime($order['created_date']))."<br>";
	$html .= "Contract Number: ".$oid."";
	$html .= "</td>";

	$html .= "</tr></table>";

	$html .= "<hr size=1>\n\n";

	############ AD SALES #############

	$query  = "SELECT oa.net-oa.barter AS cashnet,";
	$query .= "oa.price AS ratecardprice, ";
	$query .= "oa.agency_discount AS agencydiscount, ";
	$query .= "oa.gross, ";
	$query .= "oa.barter, ";
	$query .= "oa.other_discount AS otherdiscount, ";
	$query .= "s.ad_size_name AS adsize,";
	$query .= "p.pub_name AS publication,";
	$query .= "i.iss_name AS issue, ";
	$query .= "asz.ad_size_name AS adsize, ";
	$query .= "c.ad_color_name AS color, ";
	$query .= "ap.ad_position_name AS premiumposition, ";
	$query .= "note AS adnotes, ";
	$query .= "rd.def_name AS ratecardname ";
	$query .= "FROM orders_adsales AS oa ";
	$query .= "INNER JOIN ad_size AS s ON oa.SizeID=s.sizeID ";
	$query .= "INNER JOIN pubs AS p ON oa.PubID=p.id ";
	$query .= "INNER JOIN issues AS i ON oa.IssueID=i.id ";
	$query .= "INNER JOIN ad_color AS c ON c.colorID=oa.ColorID ";
	$query .= "INNER JOIN ad_size AS asz ON asz.sizeID=oa.SizeID ";
	$query .= "INNER JOIN ratecard_def AS rd ON rd.defID=oa.DefID ";
	$query .= "INNER JOIN ad_position AS ap ON ap.positionID=oa.PosID ";
	$query .= "WHERE oa.OID='".$oid."' ";
	$query .= "ORDER BY i.iss_report_date, oa.OAID";

	$result = mysql_query($query) or die(mysql_error());
	$totalrows = $totalrows + mysql_num_rows($result);

	if (mysql_num_rows($result)) {
	  $x = 0;
	  $html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
	  while ($row = mysql_fetch_assoc($result)) {
	    $x++;
	    unset($lrow);
	    foreach ($lfields AS $key => $value) {
	      if ($x==1) {
	        $ltitle .= "<td align=left><b>".$li[$value]['name']."</b></td>\n";
	      }
	      $lrow .= "<td align=left".(($li[$value]['name']=="Issue")?(" width=30%"):("")).">".(($row[$li[$value]['dbname']])?($row[$li[$value]['dbname']]):("&nbsp;"))."</td>\n";
	    }
	    $lrow = "<tr>".$lrow."</tr>";
	    $lrows .= $lrow;

	    $order_total += $row['cashnet'];
	    $order_barter += $row['barter'];
	  }
	  $html .= "<tr>\n".$ltitle."</tr>\n";
	  $html .= $lrows;
	  $html .= "</table>\n";
	  $html .= "<hr size=1>\n\n";

	}	
	############ SERVICES #############

	$query  = "SELECT * ";
	$query .= "FROM orders_services AS os ";
	$query .= "INNER JOIN services AS s ON os.SID=s.sID ";
	//$query .= "INNER JOIN service_categories AS sc ON s.scatID=sc.scatID ";
	$query .= "WHERE OID='".$oid."'";

	$result = mysql_query($query) or die(mysql_error());
	$totalrows = $totalrows + mysql_num_rows($result);

	if (mysql_num_rows($result)) {
	  $html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
	  $html .= "<tr>\n";
	  $html .= "<td align=left><b>Service Name</b></td>\n";
	  $html .= "<td align=left colspan=3><b>Notes</b></td>\n";
	  $html .= "<td align=right nowrap><b>Total Cash</b></td>\n";
	  $html .= "<td align=right nowrap><b>Total Barter</b></td>\n";
	  $html .= "</tr>\n";

	  while ($row = mysql_fetch_assoc($result)) {
	    $html .= "<tr>\n";
	    $html .= "<td align=left valign=top class='row'>".$row['service_name']."</td>\n";
	    $html .= "<td align=left valign=top class='row' colspan=3>".$row['order_note']."</td>\n";
	    $html .= "<td align=right valign=top>".number_format($row['order_total'], 2, '.', ',')."</td>\n";
	    $html .= "<td align=right valign=top>".number_format($row['order_barter'], 2, '.', ',')."</td>\n";
	    $html .= "</tr>\n";

	    $order_total += $row['order_total'];
	    $order_barter += $row['order_barter'];
	  }
	  $html .= "</table>\n";
	  $html .= "<hr size=1>\n";
	}
	  $html .= "<table width=100% cellpadding=0 cellspacing=1><tr><td align='right'>";
	if ($order_barter) {
	  //hiding barter due - cjc
	  $html .= "<b>Barter Due:</b> \$".number_format($order_barter,2)."<br>\n";
	}
	//hiding cash due - cjc
	$html .= "<b>Cash Due:</b> \$".number_format($order_total,2)."<br>\n";
	$html .= "</td></tr></table>\n";




	$html .= "<tr><td colspan=3 valign=top>";
	if ($order['comments']) { $html .= "<center><b>Notes: </b>".$order['comments']."</center><br><br>"; }
	$html .= $ct['ct_body'];
	$html .= "</td></tr>\n";
	$html .= "</table>\n";
	
	return $html;
}


function get_order_total_net($oid) {
	$total_net_query = "SELECT SUM(
		(SELECT IFNULL(SUM(oa.net), 0) AS adsales FROM orders AS o LEFT JOIN orders_adsales AS oa ON o.OID = oa.OID WHERE o.oid = '$oid' AND (oa.`kill` = '0' OR oa.kill_keep_invoice = 1)) +  
		(SELECT IFNULL(SUM(order_total), 0) AS services FROM orders AS o LEFT JOIN orders_services AS os ON o.OID = os.OID WHERE o.oid = '$oid' AND os.`kill` = '0')
		) AS total_net
	";
	$total_net_result = mysql_query($total_net_query);
	list($total_net) = mysql_fetch_row($total_net_result);
	
	return $total_net;
}


function get_order_total_barter($oid) {
	$total_barter_query = "SELECT SUM(
		(SELECT IFNULL(SUM(oa.barter), 0) AS adsales FROM orders AS o LEFT JOIN orders_adsales AS oa ON o.OID = oa.OID WHERE o.oid = '$oid' AND (oa.`kill` = '0' OR oa.kill_keep_invoice = 1)) +  
		(SELECT IFNULL(SUM(order_barter), 0) AS services FROM orders AS o LEFT JOIN orders_services AS os ON o.OID = os.OID WHERE o.oid = '$oid' AND os.`kill` = '0')
		) AS total_barter
	";
	$total_barter_result = mysql_query($total_barter_query);
	list($total_barter) = mysql_fetch_row($total_barter_result);
	
	return $total_barter;
}


function generate_io_pdf($oid) {
	require_once($_SERVER['DOCUMENT_ROOT']."/includes/html2fpdf/html2fpdf.php"); 
	include_once ($_SERVER['DOCUMENT_ROOT'].'/includes/database.php');
	include_once($_SERVER['DOCUMENT_ROOT'].'/includes/functions.php');
	require_once($_SERVER['DOCUMENT_ROOT'].'/includes/forge_fdf.php' );
	include_once('/var/www/html/com944x/public_htm/inc/functions-only.php');

  list($CTID) = mysql_fetch_row(mysql_query("SELECT CTID FROM 944x_944media.orders WHERE oid = '".$oid."'"));

	if ($CTID == 28) {
    if (get_order_total_barter($oid) > 0) {
    	$has_trade = 1;
    	$io_file = 'vr-io-with-trade.pdf';
    }
    else {
    	$io_file = 'vr-io-no-trade.pdf';
    }
	}
	else {
    if (get_order_total_barter($oid) > 0) {
    	$has_trade = 1;
    	$io_file = '944-io-with-trade.pdf';
    }
    else {
    	$io_file = '944-io-no-trade.pdf';
    }
	}

	$fdf_data_strings= array();
	$fdf_data_names= array();

	$billing_event = array(0 => 'no', 1 => 'yes');
	$ach_type_cs = array(1 => 'Checking', 2 => 'Savings');
	$ach_type_bp = array(1 => 'Business', 2 => 'Personal');
	$billing_address_choice = array(1 => 'Advertiser address as noted above is the correct billing contact address.', 2 => 'Media Agency address as noted above is the correct billing contact address.', 3 => 'Address entered below is the correct billing contact address:');
	$payment_method = array(1 => 'Credit Card', 2 => 'ACH', 3 => 'Check');

	$card_type = array();
	$card_type_query = "SELECT * FROM payment_method WHERE type = 'cc'";
	$card_type_result = mysql_query($card_type_query);
	while ($row = mysql_fetch_assoc($card_type_result)) {
		$card_type[$row['mid']] = stripslashes($row['name']);
	}

	$orders_forms_query = "SELECT orders_forms.payment_method AS payment_method, payby_card.type AS cc_type, payby_card.number AS cc_number, payby_card.expiration_month AS cc_expiration_month, payby_card.expiration_year AS cc_expiration_year, payby_card.code AS cc_code, payby_card.name AS cc_name, payby_card.address AS cc_address, payby_card.city AS cc_city, payby_card.state AS cc_state, payby_card.zip AS cc_zip, payby_card.signature AS cc_signature, payby_ach.account AS ach_account, payby_ach.routing AS ach_routing, payby_ach.type_cs AS ach_type_cs, payby_ach.type_bp AS ach_type_bp, payby_ach.bank_name AS ach_bank_name, payby_ach.account_name AS ach_account_name, orders_forms.billing_address_choice, billing_other.company AS billing_other_company, billing_other.contact AS billing_other_contact, billing_other.address AS billing_other_address, billing_other.city AS billing_other_city, billing_other.state AS billing_other_state, billing_other.zip AS billing_other_zip, orders_forms.billing_email, orders_forms.billing_po, orders_forms.payment_signature, orders_forms.payment_tax_id, orders_forms.terms_signature, orders_forms.terms_title, orders_forms.terms_date, orders_forms.ip_address, orders_forms.added, orders_forms.notes AS notes, orders_forms.billing_event, orders_forms.billing_event_initials, orders_forms.billing_event_initials_date, orders_forms.billing_terms, CONCAT(users.fname, ' ', users.lname) AS rep_signature, orders_forms.filename FROM orders_forms LEFT JOIN billing_other ON billing_other.id = orders_forms.billing_other_id LEFT JOIN payby_card ON payby_card.id = orders_forms.payby_card_id LEFT JOIN payby_ach ON payby_ach.id = orders_forms.payby_ach_id LEFT JOIN orders ON orders.OID = orders_forms.OID LEFT JOIN users ON users.userid = orders.created_id WHERE orders_forms.OID = '".$oid."'";

	$orders_forms_result = mysql_query($orders_forms_query);

	while ($row = mysql_fetch_assoc($orders_forms_result)) {
		foreach ($row as $field => $value) {
			$array[$field] = stripslashes($value);
		}
	}

	$checked = 'x';

	$array['billing_other_city_state_zip'] = $array['billing_other_city'].' '.$array['billing_other_state'].' '.$array['billing_other_zip'];

	$exploded_date = explode('/', $array['terms_date']);
	$array['date_1'] = $exploded_date[0].'/'.$exploded_date[1];
	$array['date_2'] = $exploded_date[2];

	$exploded_name = explode(' ', $array['payment_signature']);
	$initials_1 = substr($exploded_name[0], 0, 1);
	$initials_2 = substr(array_pop($exploded_name), 0, 1);
	$array['initials'] = $initials_1 . $initials_2;

	$array['cc_type'] = $card_type[$array['cc_type']];
	$array['ach_type_cs'] = $ach_type_cs[$array['ach_type_cs']];
	$array['ach_type_bp'] = $ach_type_bp[$array['ach_type_bp']];
	$array['billing_event_' . $billing_event[$array['billing_event']]] = $checked;
	$array['payment_method_' . $array['payment_method']] = $checked;
	$array['billing_address_choice_' . $array['billing_address_choice']] = $checked;
	$array['billing_payment'] = $checked;

	# Only output the last 4 of the credit card
	if ($array['cc_number']) {
		$array['cc_number'] = '.. '.cc_last_4($array['cc_number']);
	}

	if ($array['billing_terms'] == '-1') {
		$array['billing_terms_pre_payment'] = $checked;
	}
	elseif ($array['billing_terms'] == '0') {
		$array['billing_terms_due_upon_receipt'] = $checked;
	}
	else {
		$array['billing_terms_net_' . $array['billing_terms']] = $checked;
	}

	if ($array['notes']) {
		$array['notes'] = "Client Notes:\n\n".$array['notes'];
	}

	if ($array['billing_po']) {
		$array['billing_po_checked'] = $checked;
	}

	switch ($array['payment_method']) {
		case '2':
			foreach ($array as $field => $value) {
				if ($field == 'initials' || $field == 'date_1' || $field == 'date_2') {
					$array['ach_'.$field] = $value;
					$array[$field] = '';
				}
			}

		case '3':
			foreach ($array as $field => $value) {
				if (strpos($field, 'cc_') !== FALSE || strpos($field, 'ach_') !== FALSE || $field == 'initials' || $field == 'date_1' || $field == 'date_2') {
					$array['check_'.$field] = $value;
					$array[$field] = '';
				}
			}
			break;
	}

	// echo display_io_web($oid);
	$html = display_io_print($oid);
	// list($associated_company) = mysql_fetch_row(mysql_query("SELECT ct.associated_company FROM 944x_944media.orders LEFT JOIN 944x_944media.contract_templates AS ct ON orders.CTID = ct.CTID WHERE oid = '".$oid."'"));

	// echo $html;

	$pdf = new HTML2FPDF();
	$pdf->AddPage();
	$pdf->Image("/var/www/html/com944x/www/cdata/944/contract_templates/".$CTID.".jpg",65,10);
	// $pdf->Image("../cdata/".$client_path."/contract_templates/".$ct['CTID'].".jpg",65,10);
	$pdf->WriteHTML($html);
	// $pdf->Output('doc.pdf','I');
	$pdf->Output($_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-pg1-'.$array['filename'].'.pdf');

	// print_r($array);
	// exit;

	// Add job number to hash..
	// $mktime = mktime();
	// if (!$_POST['hash']) {
	// 	$_POST['hash'] = md5($_POST['fname'].$_POST['lname'].$_POST['ssn_1'].$_POST['ssn_2'].$_POST['ssn_3'].$mktime);
	// }

	foreach ($array as $key => $value) {
	  // translate tildes back to periods
	  $fdf_data_strings[ strtr($key, '~', '.') ]= $value;
	}

	$fields_hidden= array();
	$fields_readonly= array();

	$fdf= forge_fdf( '',
			 $fdf_data_strings,
			 $fdf_data_names,
			 $fields_hidden,
			 $fields_readonly );

	$fdf_fn= tempnam( '.', 'fdf' );
	$fp= fopen( $fdf_fn, 'w' );
	if( $fp ) {
	  fwrite( $fp, $fdf );
	  fclose( $fp );

		exec ( 'pdftk '.$_SERVER['DOCUMENT_ROOT'].'/data/templates/'.$io_file.' fill_form '. $fdf_fn. ' output '.$_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-terms-'.$array['filename'].'.pdf flatten');
		exec ( 'pdftk '.$_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-pg1-'.$array['filename'].'.pdf '.$_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-terms-'.$array['filename'].'.pdf cat output '.$_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-'.$array['filename'].'.pdf flatten' );

		// copy($_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-'.$array['filename'].'.pdf', '/var/www/html/com944x/www/cdata/944/io/'.$oid.'.pdf');
		exec ( 'cp '.$_SERVER['DOCUMENT_ROOT'].'/data/io/io-'.$oid.'-'.$array['filename'].'.pdf /var/www/html/com944x/www/cdata/944/io/'.$oid.'.pdf');
	
		unlink( $fdf_fn ); // delete temp file
	}
	else { // error
		echo 'Error: unable to open temp file for writing fdf data: '. $fdf_fn;
	}
}

?>
