<?php 
# Also update /var/www/html/life944/www/templates/paperless/check_logins.phpx if pw is changed
$MASTER_PASSWORD_TRAFFICKER = 'quest7(nasal';
$MASTER_PASSWORD_TRAFFICKER2 = 'pays369/scum';

switch ($_SERVER['SERVER_NAME']) {
	case 'local.clients':
		$url_clients = 'local.clients';
		$url_944 = 'local.944';
		break;

	case 'dev.clients':
		$url_clients = 'dev.clients';
		$url_944 = 'dev.944';
		break;

	case 'clients3.944.com':
		$url_clients = 'clients3.944.com';
		$url_944 = 'www3.944.com';
		break;

	case 'stage-clients.944.com':
		$url_clients = 'stage-clients.944.com';
		$url_944 = 'stage.944.com';
		break;

	case 'clients.944.localhost':
		$url_clients = 'clients.944.localhost';
		$url_944 = '944.localhost';
		break;
	
	default:
		$url_clients = 'clients.944.com';
		$url_944 = 'www.944.com';
		break;
}

if ($_SERVER['SERVER_NAME'])
 
if ($_GET['logmeout']=="please") {
	setcookie("944clients","",time()-3000,"/","$url_clients");
	setcookie("944companies","",time()-3000,"/","$url_clients");
	setcookie("944clientshash","",time()-3000,"/","$url_clients");
	header("Location: //$url_944/paperless/");
	exit;
}

if ($_POST['CID']) { 
	$sqlCompany_first = " company.CID='".$_POST['CID']."' AND";
	$sqlCompany_second = " (company.CID='".$_POST['CID']."' OR company.AID='".$_POST['CID']."') AND";
}


// Allow users to change companies themselves
if ($_GET['change_company'] && !$_POST['fmlogin'] && $_COOKIE['944clients']) {
	$myuser_query = "SELECT * FROM contacts WHERE IID = '".$_COOKIE['944clients']."'";
	$myuser_result = mysql_query($myuser_query);
	$myuser = mysql_fetch_assoc($myuser_result);
	
	$query = "SELECT company.CID,company.associated_company,company_name FROM contacts JOIN company on company.CID=contacts.CID WHERE ".$sqlCompany_second." contacts.dead='0' AND contacts.contact_email='".$myuser['contact_email']."' AND company.dead = '0'";
	$query .= " UNION ";
	$query .= "SELECT company.CID,company.associated_company,company_name FROM contacts JOIN company on company.AIID=contacts.IID WHERE ".$sqlCompany_second." contacts.dead='0' AND contacts.contact_email='".$myuser['contact_email']."' AND company.dead = '0'";
	$query .= " GROUP BY CID";
    $rs = mysql_query($query);
	
	// If there is more than one company associated with that ID, make them choose a company
	if (mysql_num_rows($rs)>1 && !$_POST['CID']) {
		echo "<form method=post action=//$url_clients>";
		echo "We found multiple clients linked to your account.  Which account would you like to use?<br><br>";
		while ($row = mysql_fetch_assoc($rs)) {
			echo "<input type='radio' name='CID' value='".$row['CID']."'> ".$row['company_name']." (Account #".$row['CID'].")<br>";
		}
		echo "<input type=hidden name=user value='".$myuser['contact_email']."'>";
		echo "<input type=hidden name=md5_pass value='".$myuser['password']."'>";
		echo "<input type=hidden name=fmlogin value=1>";
		echo "<br><input type=submit name=submit value=Continue></form>";
		die();
	} 
	elseif (!$_POST['CID']) {
		?>
		<script type="text/javascript" charset="utf-8">
			alert('No other companies associated with this account.');
		</script>
		<?php 
	}
}


if ($_POST['fmlogin']) {
	if ($_POST['fmlogin'] && $_POST['user'] && ($_POST['pass'] || $_POST['md5_pass'])) {

		##
		## Modified by: Beau Frusetta
		## Modified on: 2009-04-28
		## Description: This password is no longer valid - shouldn't allow clients in at all
		## 
		/*
        if ($_POST['pass']=="944magazine") {
	       	echo "To ensure the security of your account it is necessary to change your default password, 944magazine.  <br>To request a new password, <a href=http://www.944.com/paperless/?requestemail=".$_POST['user'].">click here</a>.  Your new password will be sent to ".$_POST['user'].".";
	       	die();
   	  	}
		*/

		// [EJC 2009-02-13]
		// Added back in the $sqlCompany variable so that the cookie is correctly set based on the chosen company 
		// if a contact is associatead with more than one

		$ppl_query = "SELECT IID FROM contacts LEFT JOIN company AS company ON company.CID = '".$_POST['CID']."' AND contacts.CID = '".$_POST['CID']."' WHERE ".$sqlCompany_first." contacts.contact_email='".$_POST['user']."' and contacts.dead='0' and (contacts.password=MD5('".$_POST['pass']."') OR contacts.password='".$_POST['md5_pass']."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER2."') GROUP BY IID";
		// echo $ppl_query;
		// exit;
		list ($pplID) = mysql_fetch_row(mysql_query($ppl_query));
		// echo $pplID;
		// echo '<hr/>';
		// exit;

		// [EJC 2009-07-23]
		// Added in the $adID variable to allow ad agencies to upload artwork for any of their clients
		$ad_query = "SELECT IID FROM contacts LEFT JOIN company AS company ON company.AID = '".$_POST['CID']."' AND company.AIID = contacts.IID WHERE contacts.contact_email='".$_POST['user']."' and contacts.dead='0' and (contacts.password=MD5('".$_POST['pass']."') OR contacts.password='".$_POST['md5_pass']."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER2."') GROUP BY IID";
		// echo $ad_query;
		// exit;
		list ($adID) = mysql_fetch_row(mysql_query($ad_query));
		// echo $adID;
		// exit;




		$query = "SELECT company.CID,company.associated_company,company_name FROM contacts JOIN company on company.CID=contacts.CID WHERE ".$sqlCompany_second."  contacts.contact_email='".$_POST['user']."' AND contacts.dead='0' AND company.dead = 0 AND (password=MD5('".$_POST['pass']."') OR password='".$_POST['md5_pass']."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER2."')";
		$query .= " UNION ";
		$query .= "SELECT company.CID,company.associated_company,company_name FROM contacts JOIN company on company.AIID=contacts.IID WHERE ".$sqlCompany_second."  contacts.contact_email='".$_POST['user']."' AND contacts.dead='0' AND company.dead = 0 AND (password=MD5('".$_POST['pass']."') OR password='".$_POST['md5_pass']."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER."' OR '".$_POST['pass']."'='".$MASTER_PASSWORD_TRAFFICKER2."')";
		$query .= " GROUP BY CID";

	// echo "<!--\n$query\n-->\n";
		// echo $query;
		$rs = mysql_query($query);

		// If there is more than one company associated with that ID, make them choose a company

        if (mysql_num_rows($rs)>1 && !$_POST['CID']) {
            echo "<form method=post action=//$url_clients>";
             echo "We found multiple clients linked to your account.  Which account would you like to use?<br><br>";
            while ($row = mysql_fetch_assoc($rs)) {
                echo "<input type='radio' name='CID' value='".$row['CID']."'> ".$row['company_name']." (Account #".$row['CID'].")<br>";
            }
            echo "<input type=hidden name=user value='".$_POST['user']."'>";
            echo "<input type=hidden name=pass value='".$_POST['pass']."'>";
            echo "<input type=hidden name=fmlogin value=1>";
            echo "<br><input type=submit name=submit value=Continue></form>";
            die();
		}

      	if ($pplID || $adID) {
			if (!$pplID && $adID) {
				$userID = $adID;
			}
			elseif ($pplID) {
				$userID = $pplID;
			}
			
			// if ($_POST['CID']) {
			// 	$_SESSION['CID'] = $_POST['CID'];
			// }

			// [EJC 2009-04-16]
			// Add a check so that if Royce logs in with his master password, he can't access any 944 companies, only Six Degrees, per Star
			// [EJC 2009-04-30]
			// Removed this check as Royce needs to access both companies' companies now :)
			$row = mysql_fetch_assoc($rs);
			if ($_POST['pass'] == $MASTER_PASSWORD_TRAFFICKER2 && $row['associated_company'] != 2) {
				// echo 'ERROR: Only Six Degrees companies can be accessed using Royce\'s master password.';
				// exit;
			}

	        $time_hash = md5(strtotime("now"));
	        setcookie("944clients",$userID,time()+3000000,"/","$url_clients");
	        setcookie("944companies",$_POST['CID'],time()+3000000,"/","$url_clients");
	        setcookie("944clientshash",$time_hash,time()+3000000,"/","$url_clients");
	        mysql_query("UPDATE contacts SET webhash='".$time_hash."' WHERE IID='".$userID."'");
	        header("Location: //$url_clients/");
	        exit;
      	} else {
			/*
	        $error = "Incorrect Login";
	        echo "Bad username and password.  If you'd like to reset your password please <a href=http://www.944.com/paperless/?requestemail=".$_POST['user'].">click here</a>. <br><br>OR<br><br>";
	        echo "You are not set up as a contact with any clients in our database, Please contact your 944 Representative to have your login email assigned to the client you are trying to login for.";
	        die();
			*/
			header("Location: //$url_944/paperless/?login_error=1");
			exit;
      	}
    }

	header("Location: //$url_944/paperless/?login_error=1");
	// @include($_SERVER['DOCUMENT_ROOT']."/includes/not_logged_in.php");
	exit();
}

$myuser_query = "SELECT * FROM contacts as c inner join company as co on co.CID = c.CID WHERE c.IID='".$_COOKIE['944clients']."'";
$myuser = mysql_fetch_assoc(mysql_query($myuser_query));

// If the user is an ad agency (company_type == 2), load in that company's info instead
if ($_COOKIE['944companies'] && $_COOKIE['944companies'] != $myuser['CID'] && $myuser['company_type'] == 2) {
	unset($myuser);

	$myuser_query = "SELECT * FROM contacts as c inner join company as co on co.AIID = c.IID AND co.CID = '".$_COOKIE['944companies']."' WHERE c.IID='".$_COOKIE['944clients']."'";
	$myuser = mysql_fetch_assoc(mysql_query($myuser_query));
}

// if ($_POST['CID']) {
	// $myuser['CID'] = $_POST['CID'];
// }

# Added an exception for test@944.com account so that multiple logins are allowed
// if (($myuser['webhash'] != $_COOKIE['944clientshash'] || !$myuser['IID']) && $myuser['IID'] != 77003) {

# Removed the 1 login per user restriction, only reset the cookie if there is no valid login
if (!$myuser['IID']) {
	$error = "Session Expired";
	setcookie("944clients","",time()-3000,"/","$url_clients");
	setcookie("944companies","",time()+3000000,"/","$url_clients");
	setcookie("944clientshash","",time()-3000,"/","$url_clients");
	header("Location: //$url_944/paperless/?login_error=1");
	// include $_SERVER['DOCUMENT_ROOT']."/includes/not_logged_in.php";
	exit();
}

?>