<?php 
echo "<style>\n";
echo "BODY { background:#FAFAFA;margin: 0px; }\n";
echo "TD { font:normal 11px arial; }\n";
echo "INPUT { font:normal 11px arial;border:1px solid #49AFD0; }\n";
echo "</style>\n";


echo "<center>\n";
echo "<br><br><br><br>\n";
echo "<h1>944 Clients Login</h1>\n";
echo "<table cellpadding=0 cellspacing=0 style='border:1px solid #49AFD0;'>\n";
echo "<form method='post'>";
echo "<input type='hidden' name='fmlogin' value='1'>\n";
echo "<tr><td bgcolor=#49AFD0 style='padding:3px;font:bold 12px arial;color:#FFFFFF;'>Please login below.</td></tr>\n";
echo "<tr><td style='padding:6px;'>";
if ($error) {
  echo $error;
}
echo "<table width=100% cellpadding=0 cellspacing=0>\n";
echo "<tr><td>Email:&nbsp;</td><td><input type='text' name='user' style='width:150px;'></td></tr>";
echo "<tr><td>Password:&nbsp;</td><td><input type='password' name='pass' style='width:150px;'></td></tr>";
echo "<tr><td colspan=2 align=right><input type='submit' value='Login Now' style='margin-top:5px;background:#49AFD0;color:#FFFFFF;'></td></tr>";
echo "</table>\n";
echo "</td></tr>\n";
echo "</form>\n";
echo "</table>\n";
echo "</center>\n";

?>
