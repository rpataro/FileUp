<?php
@include($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");
@include($_SERVER['DOCUMENT_ROOT']."/includes/require_login.php");

$newpath = $_SERVER['DOCUMENT_ROOT']."/templates".implode("/",$path)."index.php";

if ($_POST) {
  @include(str_replace("index.php","post.php",$newpath));
}

@include($_SERVER['DOCUMENT_ROOT']."/templates/header.php");
//@include($_SERVER['DOCUMENT_ROOT']."/templates/subnav.php");

if (file_exists($newpath)) {
  @include($newpath);
} else {
  @include($_SERVER['DOCUMENT_ROOT']."/templates/index.php");
}

@include($_SERVER['DOCUMENT_ROOT']."/templates/footer.php");

?>
