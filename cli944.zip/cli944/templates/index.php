<?php 
include_once('/var/www/html/com944x/www/inc/functions-only.php');

$iss_report_date = common_getCurrentIssueDate();

$query = "select SUM(ifnull(c.net-c.barter, 0)) - SUM(ifnull(f.payments, 0))+ SUM(ifnull(order_total,0)) - SUM(ifnull(g.payments, 0))
from orders a
inner join company b ON a.CID =b.CID
left join orders_adsales c ON a.OID =c.OID AND `kill` ='0'
LEFT join invoices e ON c.OAID =e.OTID AND e.OT =1
left join orders_services d ON a.OID =d.OID
LEFT join  (SELECT SUM(payments) as payments
                                ,IVID FROM payments
                                GROUP BY IVID) f ON e.IVID =f.IVID
LEFT  join invoices h ON d.OSID =h.OTID AND h.OT =2
LEFT join  (SELECT SUM(payments) as payments
                                ,IVID FROM payments
                                GROUP BY IVID) g ON h.IVID =g.IVID
where probability ='100'
AND a.cid='".$myuser['CID']."'
AND (e.IVID is not null OR h.IVID  IS NOT NULL)
GROUP BY a.CID";

list ($owed) = mysql_fetch_row(mysql_query($query));

$ios_query =  "SELECT COUNT(orders.OID) FROM 944x_944media.orders WHERE orders.CID = '".$myuser['CID']."' AND orders.probability IN (90, 95, 98) AND orders.kill_rep_id = 0 ORDER BY orders.OID DESC";
list ($ios) = mysql_fetch_row(mysql_query($ios_query));

$artwork_query =  "select COUNT(TID) 
from job_tickets as jt
inner join orders_adsales as oa on oa.OAID = jt.OTID 
inner join orders as o on o.OID = oa.OID 
inner join pubs as p on p.id = oa.PubID
inner join issues as i on i.id = oa.IssueID
inner join ad_position as ap on ap.positionID = oa.PosID
inner join ad_size as s on s.sizeID = oa.SizeID
inner join company c on c.CID = o.CID
where OT='1' 

and o.CID='".$myuser['CID']."' 
and jt.last_status !='2'    and (datediff(iss_material_date,now()) >= 0 OR iss_report_date >= '".$iss_report_date."')
order by i.iss_report_date asc";
// echo $artwork_query;
list ($artwork) = mysql_fetch_row(mysql_query($artwork_query));

# Add a javscript redirect if the client only has one of the three main functions that pertains to them..
if ($owed && !$ios && !$artwork) {
	$redirect = '/invoices/';
}
elseif ($ios && !$owed && !$artwork) {
	$redirect = '/io/';
}
elseif ($artwork && !$ios && !$owed) {
	$redirect = '/artwork/';
}

if ($redirect) {
	?>
	<script type="text/javascript">
		window.location = "<?php echo $redirect?>";
	</script>
	<?php 
}
?>

<p class="section_title">Welcome...</p>

<div style = "margin-left:0px;line-height:13px;">

	<b>Account Balance</b>: <a href = "/invoices/">$<?php echo number_format(($owed*1),2);?></a><br>
	<br/>
	<b>Pending Insertion Orders</b>: <a href = "/io/"><?php echo number_format($ios);?></a><br>
	<br/>
	<b>Pending Ads</b>: <a href = "/artwork/"><?php echo number_format($artwork);?></a><br>
	<br/>

</div>

