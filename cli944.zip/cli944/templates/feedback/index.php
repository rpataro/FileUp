<p class="section_title">Feedback / Help</p>

<?php if (!$_GET['email']) { ?>
<form method="POST">
<table cellpadding="4" cellspacing="0" border="0" width="100%" class = "activity_box">
<tr>
	<td width="75">Name</td>
	<td><input class = "textbox" type="text" name = "name" value="<?php echo $myuser['contact_firstname']." ".$myuser['contact_lastname'];?>"></td>
</tr>
<tr>
	<td>E-Mail</td>
	<td><input class = "textbox" type="text" name = "email" value="<?php echo $myuser['contact_email'];?>"></td>
</tr>
<tr>
	<td>Subject</td>
	<td><input class = "textbox" type="text" name = "subject"></td>
</tr>
<tr>
	<td colspan="2">
	<textarea class = "textbox" name="body" style = "height:200px;"></textarea>
	</td>
</tr>
<tr>
	<td colspan="2">
	<input type="submit" value="Send Feedback" class="button">
	</td>
</tr>
</table>
</form>

<?php } else if ($_GET['email']=="sent") {
	print "Your Feedback has been sent!";
} else if ($_GET['email']=="error") {
	print "There has been an error while trying to send your feedback, Please send an email to <a href = 'mailto:webmanager@944.com'>webmanager@944.com</a>";
}