<?php 

require_once($_SERVER['DOCUMENT_ROOT']."/html2fpdf/html2fpdf.php"); 

$query  = "SELECT *,i.CTID as CTID, i.IVID as IVID FROM invoices AS i ";
$query .= "INNER JOIN orders AS o ON o.OID=i.OID ";
$query .= "LEFT JOIN (SELECT SUM(case when method IN(94, 95) THEN payments*-1 ELSE payments end) as payments ,SUM(barter_payments) as barter_payments,IVID ";  
$query .= "FROM payments GROUP BY IVID) AS b ON b.IVID=i.IVID "; 
if ($_REQUEST['OT']=="1") {
  $query .= "INNER JOIN orders_adsales AS oa ON oa.OAID=i.OTID ";
} elseif ($_REQUEST['OT']=="2") {
  $query .= "INNER JOIN orders_services AS os ON os.OSID=i.OTID ";
}
$query .= "WHERE i.OTID='".$_REQUEST['OTID']."' ";
$query .= "AND i.OT='".$_REQUEST['OT']."'";

$order = mysql_fetch_assoc(mysql_query($query));

///this is used later so we can display the old invoice (i.e. in what was imported from MagMgr)
if (substr($order['invoice_id'],0,5)=="2007-") {
	$old_invoice_id = $order['invoice_id'];
} else ($order['invoice_id']);

///echo $order['invoice_id']; die;
$ct = mysql_fetch_assoc(mysql_query("SELECT * FROM contract_templates WHERE CTID='".$order['CTID']."'"));

$company = mysql_fetch_assoc(mysql_query("SELECT *, case when company_payment = 0 THEN 'Due On Receipt' WHEN company_payment = -1 THEN 'Pre-Pay' ELSE CONCAT('NET', ' ', company_payment) END AS term  FROM company WHERE CID='".$order['CID']."'"));
if ($order['AID']) {
  $agency = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['AID']."'"));
}
if ($company['BIID']) {
  //***  billing address 
  
  $billingaddress = mysql_fetch_assoc(mysql_query("SELECT * from contacts a INNER JOIN company b ON a.CID =b.CID where IID = '".$company['BIID']."'"));
	$mailto = $billingaddress['contact_address']; 
	$mailto2 = $billingaddress['contact_address2'];
  $mailtocity = $billingaddress['contact_city'];
	$mailtostate = $billingaddress['contact_state'];
	$mailtozip = $billingaddress['contact_zip'];
	$mailtocountry = $billingaddress['contact_country'];
} else {
  $billing = $company;
}
$rep = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE userid=(select company_primary_rep from company where CID='".$order['CID']."')"));


$result = mysql_query("SELECT * FROM line_items");
while ($row = mysql_fetch_assoc($result)) {
  $li[$row['LID']]['name'] = $row['lineitem_name'];
  $li[$row['LID']]['dbname'] = $row['lineitem_dbfield'];
}

$lfields = explode(",",$ct['ct_lineitems']);
$html .="

<style>
.row { border-bottom:1px solid #000000; }
</style>
";



//$html .= "<img src='../cdata/".$client_path."/contract_templates/".$ct['CTID'].".jpg'><br>";
$html .= "<center><xlarge>".$ct['ct_title']."</xlarge></center>";

$html .= "<b>Bill To:</b><br>";
$html .= $billingaddress['company_name']."<br>";
$html .= $mailto."<br>";
if ($mailto2 != "" ) { $html .= $mailto2."<br>";}
$html .= $mailtocity.", ".$mailtostate." ".$mailtozip."	$mailtocountry";

$html .= "<br><br><br><br>Advertiser Name: <b>".$company['company_name'].",  (#".$order['CID']." ) </b><br><br>";

$html .= "<hr size=1>\n\n";

$html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
$html .= "<tr>\n";
$html .= "<td><b>INVOICE DATE</b></td>\n";
$html .= "<td><b>DUE DATE</b></td>\n";
$html .= "<td><b>INVOICE #</b></td>\n";
$html .= "<td><b>PO #</b></td>\n";
$html .= "<td><b>TERM</b></td>\n";
$html .= "<td><b>SALES REP</b></td>\n";
$html .= "</tr>\n";
$html .= "<tr>\n";
$html .= "<td>".date("m/d/Y",strtotime($order['invoice_date']))."</td>\n";
$html .= "<td>".date("m/d/Y",strtotime($order['invoice_duedate']))."</td>\n";
$html .= "<td>".$order['IVID']."-R</td>\n";
$html .= "<td>".$order['ponum']."</td>\n";
$html .= "<td>".$company['term']."</td>\n";
$html .= "<td>".$rep['fname']." ".$rep['lname']."</td>\n";
$html .= "</tr>\n";
$html .= "</table>\n";

$html .= "<hr size=1>\n\n";

if ($order['OT']=="1") {
############ AD SALES #############

$query  = "SELECT oa.net-oa.barter AS cashnet,";
$query .= "oa.price AS ratecardprice, ";
$query .= "oa.agency_discount AS agencydiscount, ";
$query .= "oa.gross, ";
$query .= "oa.barter, ";
$query .= "oa.other_discount AS otherdiscount, ";
$query .= "s.ad_size_name AS adsize,";
$query .= "p.pub_name AS publication,";
$query .= "i.iss_name AS issue, ";
$query .= "asz.ad_size_name AS adsize, ";
$query .= "c.ad_color_name AS color, ";
$query .= "ap.ad_position_name AS premiumposition, ";
$query .= "note AS adnotes, ";
$query .= "rd.def_name AS ratecardname ";
$query .= "FROM orders_adsales AS oa ";
$query .= "INNER JOIN ad_size AS s ON oa.SizeID=s.sizeID ";
$query .= "INNER JOIN pubs AS p ON oa.PubID=p.id ";
$query .= "INNER JOIN issues AS i ON oa.IssueID=i.id ";
$query .= "INNER JOIN ad_color AS c ON c.colorID=oa.ColorID ";
$query .= "INNER JOIN ad_size AS asz ON asz.sizeID=oa.SizeID ";
$query .= "LEFT JOIN ratecard_def AS rd ON rd.defID=oa.DefID ";
$query .= "INNER JOIN ad_position AS ap ON ap.positionID=oa.PosID ";
$query .= "WHERE OAID='".$order['OTID']."'";

$result = mysql_query($query) or die(mysql_error());

if (mysql_num_rows($result)) {
  $x = 0;
  $html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
  while ($row = mysql_fetch_assoc($result)) {
    $x++;
    unset($lrow);
    foreach ($lfields AS $key => $value) {
      if ($x==1) {
        $ltitle .= "<td align=left><b>".$li[$value]['name']."</b></td>\n";
      }
      $lrow .= "<td align=left>".(($row[$li[$value]['dbname']])?($row[$li[$value]['dbname']]):("&nbsp;"))."</td>\n";
    }
    $lrow = "<tr>".$lrow."</tr>";
    $lrows .= $lrow;
    
    $order_total += $row['cashnet'];
    $order_barter += $row['barter'];
  }
  $html .= "<tr>\n".$ltitle."</tr>\n";
  $html .= $lrows;
  $html .= "</table>\n";
  $html .= "<hr size=1>\n\n";
  
}
} elseif ($order['OT']=="2") {
############ SERVICES #############

$query  = "SELECT * ";
$query .= "FROM orders_services AS os ";
$query .= "INNER JOIN services AS s ON os.SID=s.sID ";
//$query .= "INNER JOIN service_categories AS sc ON s.scatID=sc.scatID ";
$query .= "WHERE OSID='".$order['OTID']."'";

$result = mysql_query($query) or die(mysql_error());
if (mysql_num_rows($result)) {
   $html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
  $html .= "<tr>\n";
  $html .= "<td align=left><b>Service Name</b></td>\n";
  $html .= "<td align=right><b>Notes</b></td>\n";
  $html .= "<td align=right><b>Total</b></td>\n";
  ///$html .= "<td align=right><b>Due Date</b></td>\n";
  $html .= "</tr>\n";
  
  while ($row = mysql_fetch_assoc($result)) {
    $html .= "<tr>\n";
    $html .= "<td align=left valign=top class='row'>".$row['service_name']."</td>\n";
    $html .= "<td align=right valign=top>".$row['order_note']."</td>\n";
    $html .= "<td align=right valign=top>".$row['order_total']."</td>\n";
    ///$html .= "<td align=right valign=top>".date("m/d/Y",strtotime($row['order_duedate']))."x</td>\n";
    $html .= "</tr>\n";  
    $order_total += $row['order_total'];
   
    $barterpaid =$order['barter_payments'];  
    //$order_barter += $row['order_barter'];
  }
  $html .= "</table>\n";
  $html .= "<hr size=1>\n";
}
}

  if ($old_invoice_id) {  $html .= "<center>This invoice was previously number #".$old_invoice_id.".  If you have already paid invoice #".$old_invoice_id.", please do not pay this invoice.</center><br>"; }
  
  
$html .= "<table width=100% cellpadding=0 cellspacing=1><tr><td align='right'>";
if ($order_barter) {
  $html .= "<b>Barter Due:</b> \$".number_format($order_barter,2)."<br>\n";
      $barterpaid =$order['barter_payments'];
    $html .= "<b>Barter Paid:</b> \$".number_format($barterpaid,2)."<br>\n";
}
$html .= "<b>Cash Due:</b> \$".number_format($order_total,2)."<br>\n"; 

    $cashpaid =$order['payments'];
$html .= "<b>Cash Paid:</b> \$".number_format($cashpaid,2)."<br>\n";
$html .= "</td></tr></table>\n";

$html .= "<tr><td colspan=3 valign=top>";
$html .= $ct['ct_body'];
$html .= "</td></tr>\n";
$html .= "</table>\n";


$pdf = new HTML2FPDF();
$pdf->AddPage();
$pdf->Image("../cdata/".$client_path."/contract_templates/".$ct['CTID'].".jpg",10,10);
$pdf->WriteHTML($html);

if ($_REQUEST['OT']=="1") {

	if ($order['tearfile']) {
	  //$pdf->AddPage();
		 $size = getimagesize("..".$order['tearfile']);
	  if ($size[0] > $size[1]) {
		$pdf->Image("..".$order['tearfile'],140,15,56,0);
	  } else {
		$pdf->Image("..".$order['tearfile'],140,15,0,68);
	  }
	  //$html = "<div style='text-align:center'><img src='http://".$_SERVER['HTTP_HOST'].$order['tearfile']."'></div>";
	  //$pdf->WriteHTML($html);
	} else {
	 //see if the image is stored in the new magbuilder
	 $sql = "select * from job_tickets where OTID='".$_REQUEST['OTID']."' AND OT='".$_REQUEST['OT']."'";
	 $ticket = mysql_fetch_assoc(mysql_query($sql));
	 $ticketID = $ticket['TID'];
	 
	 $sql = "select * from magbuilder_pieces where linkID = '1-".$ticketID."'";
	 $row = mysql_fetch_assoc(mysql_query($sql));
	 
	 if ($row['id']) {
	 
       	$imgFile = "/var/www/html/proof944/public_html/magbuilder/pieces/".$row['bookID']."/".$row['id']."/large.jpg";
			
		 $size = getimagesize($imgFile);
		  if ($size[0] > $size[1]) {
			$pdf->Image($imgFile,140,15,56,0);
		  } else {
			$pdf->Image($imgFile,140,15,0,68);
		  }
	
	 }
	 
	}

}

$pdf->Output('doc.pdf','I');

exit;

?>
