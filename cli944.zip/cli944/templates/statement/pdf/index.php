<?php 
@include $_SERVER['DOCUMENT_ROOT']."/includes/functions.php";
///@include $_SERVER['DOCUMENT_ROOT']."/includes/require_login.php";

if ($_REQUEST['oid']) {
  @include($_SERVER['DOCUMENT_ROOT']."/pdf/contract_templates.php");
  exit;
}
if ($_REQUEST['OT'] && $_REQUEST['OTID']) {
  @include($_SERVER['DOCUMENT_ROOT']."/templates/statement/pdf/invoice_templates.php");
  exit;
}
if ($_REQUEST['ioaid'] || $_REQUEST['iosid'] || $_REQUEST['siid']) {
  @include($_SERVER['DOCUMENT_ROOT']."/pdf/multiple_invoice_templates.php");
  exit;
}
if ($_REQUEST['mid']) {
  @include($_SERVER['DOCUMENT_ROOT']."/pdf/master_invoices.php");
  exit;
}
if ($_REQUEST['imid']) {
  @include($_SERVER['DOCUMENT_ROOT']."/pdf/multiple_master_invoices.php");
  exit;
}
if ($_REQUEST['sid']) {
  @include($_SERVER['DOCUMENT_ROOT']."/pdf/special_invoice_templates.php");
  exit;
}

?>
