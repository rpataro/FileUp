<?php 

require_once($_SERVER['DOCUMENT_ROOT']."/html2fpdf/html2fpdf.php"); 

if ($_REQUEST['oid']) {
  $query = "SELECT * FROM orders WHERE OID='".$_REQUEST['oid']."'";
  $order = mysql_fetch_assoc(mysql_query($query));
  $company = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['CID']."'"));
  if ($order['AID']) {
    $agency = mysql_fetch_assoc(mysql_query("SELECT * FROM company WHERE CID='".$order['AID']."'"));
  }
  $rep = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE userid='".$company['company_primary_rep']."'"));
    if ($order['IID']=="0") { 
  	$contact = mysql_fetch_assoc(mysql_query("SELECT * FROM contacts where CID='".$order['CID']."' and primary_contact='1'"));
   } else {
    $contact = mysql_fetch_assoc(mysql_query("SELECT * FROM contacts where IID='".$order['IID']."'")); 	 
  }
  
 
}

$ct = mysql_fetch_assoc(mysql_query("SELECT * FROM contract_templates WHERE CTID='".$order['CTID']."'"));
echo $ct ; 
$result = mysql_query("SELECT * FROM line_items");
while ($row = mysql_fetch_assoc($result)) {
  $li[$row['LID']]['name'] = $row['lineitem_name'];
  $li[$row['LID']]['dbname'] = $row['lineitem_dbfield'];
}

$lfields = explode(",",$ct['ct_lineitems']);
$html .="

<style>
.row { border-bottom:1px solid #000000; }
</style>
";
//$html .= "<div style='text-align:left'><img src='http://".$client_path.".944x.com/cdata/".$client_path."/contract_templates/".$ct['CTID'].".jpg'></div>";
$html .="<center><xlarge>".$ct['ct_title']."</xlarge></center>";

$html .= "<table width=100% cellpadding=0 cellspacing=6>";
$html .= "<tr>";

//$html .= "<td valign=top>";
if ($ct['ct_type']=="1") {
  $html .= "<td valign=top>";
  $html .= "<b>Advertiser</b></td>";
  $html .= "<td valign=top>";
  $html .= "<b>Ad Agency</b></td>";
  $html .= "<td valign=top>";
  $html .= "<b>Publisher</b></td>";
} else {
  $html .= "<td valign=top>";
  $html .= "<b>Bill To:</b></td>";
  $html .= "<td valign=top>";
  $html .= "<b>Sales Rep</b></td>";
}


$html .="</tr><tr>";

$html .= "<td>";
$html .= $company['company_name']."<br>";
$html .= $contact['contact_firstname']." ".$contact['contact_lastname']."<br>";
$html .= $contact['contact_address']."<br>";
$html .= $contact['contact_address2']."<br>";
$html .= $contact['contact_city'].", ".$contact['contact_state']." ".$contact['contact_zip'];
$html .= "</td>";
if ($ct['ct_type']=="1") {
  $html .= "<td>";
  $html .= $agency['company_name']."<br>";
  $html .= $agency['company_address']."<br>";
  $html .= $agency['company_address2']."<br>";
  $html .= $agency['company_city'].", ".$agency['company_state']." ".$agency['company_zip'];
  $html .= "</td>";
}

$html .= "<td>";
if ($ct['ct_type']=="1") {
  $html .= "Rep: ";
}
$html .= $rep['fname']." ".$rep['lname']."<br>";
if ($rep['phone_work']) {
  $html .= format_phone($rep['phone_work'])."<br>";
}
$html .= $rep['email']."<br>";
$html .= "Contract Date: ".date("m/d/Y",strtotime($order['created_date']))."<br>";
$html .= "Contract Number: ".$_REQUEST['oid']."";
$html .= "</td>";

$html .= "</tr></table>";

$html .= "<hr size=1>\n\n";

############ AD SALES #############

$query  = "SELECT oa.net-oa.barter AS cashnet,";
$query .= "oa.price AS ratecardprice, ";
$query .= "oa.agency_discount AS agencydiscount, ";
$query .= "oa.gross, ";
$query .= "oa.barter, ";
$query .= "oa.other_discount AS otherdiscount, ";
$query .= "s.ad_size_name AS adsize,";
$query .= "p.pub_name AS publication,";
$query .= "i.iss_name AS issue, ";
$query .= "asz.ad_size_name AS adsize, ";
$query .= "c.ad_color_name AS color, ";
$query .= "ap.ad_position_name AS premiumposition, ";
$query .= "note AS adnotes, ";
$query .= "rd.def_name AS ratecardname ";
$query .= "FROM orders_adsales AS oa ";
$query .= "INNER JOIN ad_size AS s ON oa.SizeID=s.sizeID ";
$query .= "INNER JOIN pubs AS p ON oa.PubID=p.id ";
$query .= "INNER JOIN issues AS i ON oa.IssueID=i.id ";
$query .= "INNER JOIN ad_color AS c ON c.colorID=oa.ColorID ";
$query .= "INNER JOIN ad_size AS asz ON asz.sizeID=oa.SizeID ";
$query .= "INNER JOIN ratecard_def AS rd ON rd.defID=oa.DefID ";
$query .= "INNER JOIN ad_position AS ap ON ap.positionID=oa.PosID ";
$query .= "WHERE OID='".$_REQUEST['oid']."'";
$query .= "ORDER BY i.iss_report_date ";

$result = mysql_query($query) or die(mysql_error());
$totalrows = $totalrows + mysql_num_rows($result);

if (mysql_num_rows($result)) {
  $x = 0;
  $html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
  while ($row = mysql_fetch_assoc($result)) {
    $x++;
    unset($lrow);
    foreach ($lfields AS $key => $value) {
      if ($x==1) {
        $ltitle .= "<td align=left><b>".$li[$value]['name']."</b></td>\n";
      }
      $lrow .= "<td align=left".(($li[$value]['name']=="Issue")?(" width=30%"):("")).">".(($row[$li[$value]['dbname']])?($row[$li[$value]['dbname']]):("&nbsp;"))."</td>\n";
    }
    $lrow = "<tr>".$lrow."</tr>";
    $lrows .= $lrow;
    
    $order_total += $row['cashnet'];
    $order_barter += $row['barter'];
  }
  $html .= "<tr>\n".$ltitle."</tr>\n";
  $html .= $lrows;
  $html .= "</table>\n";
  $html .= "<hr size=1>\n\n";
  
}	
############ SERVICES #############

$query  = "SELECT * ";
$query .= "FROM orders_services AS os ";
$query .= "INNER JOIN services AS s ON os.SID=s.sID ";
//$query .= "INNER JOIN service_categories AS sc ON s.scatID=sc.scatID ";
$query .= "WHERE OID='".$_REQUEST['oid']."'";

$result = mysql_query($query) or die(mysql_error());
$totalrows = $totalrows + mysql_num_rows($result);

if (mysql_num_rows($result)) {
  $html .= "<table width=100% cellpadding=0 cellspacing=1>\n";
  $html .= "<tr>\n";
  $html .= "<td align=left><b>Service Name</b></td>\n";
  $html .= "<td align=left><b>Notes</b></td>\n";
  $html .= "<td align=right><b>Qty</b></td>\n";
  $html .= "<td align=right><b>Total</b></td>\n";
  $html .= "<td align=right><b>Due Date</b></td>\n";
  $html .= "</tr>\n";
  
  while ($row = mysql_fetch_assoc($result)) {
    $html .= "<tr>\n";
    $html .= "<td align=left valign=top class='row'>".$row['service_name']."</td>\n";
    $html .= "<td align=left valign=top class='row'>".$row['order_note']."</td>\n";
    $html .= "<td align=right valign=top>".round($row['order_qty'],2)."</td>\n";
    $html .= "<td align=right valign=top>".$row['order_total']."</td>\n";
    $html .= "<td align=right valign=top>".date("m/d/Y",strtotime($row['order_duedate']))."</td>\n";
    $html .= "</tr>\n";
    
    $order_total += $row['order_total'];
    //$order_barter += $row['order_barter'];
  }
  $html .= "</table>\n";
  $html .= "<hr size=1>\n";
}
  $html .= "<table width=100% cellpadding=0 cellspacing=1><tr><td align='right'>";
if ($order_barter) {
  //hiding barter due - cjc
  //$html .= "<b>Barter Due:</b> \$".number_format($order_barter,2)."<br>\n";
}
//hiding cash due - cjc
//$html .= "<b>Cash Due:</b> \$".number_format($order_total,2)."<br>\n";
$html .= "</td></tr></table>\n";




$html .= "<tr><td colspan=3 valign=top>";
if ($order['comments']) { $html .= "<center><b>Notes: </b>".$order['comments']."</center><br><br>"; }
$html .= $ct['ct_body'];
$html .= "</td></tr>\n";
$html .= "</table>\n";


//if ($ct['ct_type']=="1") { $html .= "<div style='text-align:left'><img src='http://www.myjuggernaut.com/images/paymentconfirmations.jpg'></div>"; }

$pdf = new HTML2FPDF();
$pdf->AddPage();
$pdf->Image("../cdata/".$client_path."/contract_templates/".$ct['CTID'].".jpg",65,10);
$pdf->WriteHTML($html);
//$pdf->Image("../cdata/".$client_path."/pdf_images/proposal_terms_1.png",4,192,202);
if ($totalrows > 12 and $totalrows < 40) { 
	$pdf->AddPage();
} 
$pdf->Image("../cdata/".$client_path."/pdf_images/payment-options-form-1.png",4,192,202);
$pdf->AddPage();
//$pdf->Image("../cdata/".$client_path."/pdf_images/proposal_terms_2.png",0,8,210);
$pdf->Image("../cdata/".$client_path."/pdf_images/payment-options-form-2.png",0,8,210);
$pdf->AddPage();
//$pdf->Image("../cdata/".$client_path."/pdf_images/proposal_terms_3.png",0,8,210);
$pdf->Image("../cdata/".$client_path."/pdf_images/payment-options-form-3.png",0,8,210);

//if ($ct['ct_type']=="1") { 
// show contract payment options

	//$pdf->AddPage();
    //$html = "<div style='text-align:center'><img src='http://www.myjuggernaut.com/images/paymentoptionsform.jpg'></div>";
    //$pdf->WriteHTML($html);  
  
   // $pdf->AddPage();
    //$html = "<div style='text-align:center'><img src='http://www.myjuggernaut.com/images/paymentoptionsform2.jpg'></div>";
    //$pdf->WriteHTML($html);  
  
 //} 

  
$pdf->Output('doc.pdf','I');

exit;

?>
