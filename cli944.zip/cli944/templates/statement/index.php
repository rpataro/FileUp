<?php include_once('/var/www/html/com944x/www/inc/functions-only.php');?>

<div class="section_title">Payments History (Statement)</div>
<!-- <div class = "dotted" ></div> -->
<style>
/*.tbl { border-collapse:collapse;margin-top:1px; }*/
/*.tbl TD { border:1px solid #333333; }*/
</style>

<?php echo company_statement($myuser['CID'], 0);?>
