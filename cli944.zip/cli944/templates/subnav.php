<?php 

$subnav = array(
  "nightsites" => array(
    "" => "Home",
    "new" => "New Gallery",
  ),

);

if ($subnav[$path[1]]) {
  $x = 0;
  echo "<div style = 'background:#333333'>";
  foreach ($subnav[$path[1]] AS $key => $value) {
    $x++;
    if ($x > 1) { echo "&nbsp; | &nbsp;"; }
    echo "<a class='subnav' href='/_staff/".$path[1]."/".$key.(($key)?("/"):(""))."'".(($path[2] == $key)?(" style='font-weight:bold;'"):("")).">".$value."</a>";
  }
  echo "</div>";
  //echo "<hr size=1>";
} else {
  echo "<div class='subnav_links'>Select a tab above.</div>";
}
?>
</td></tr>
</table>
<table width=100% cellpadding=0 cellspacing=0>
<tr><td valign=top class='cbody' style="background: url(/images/bg.jpg) top right no-repeat;">
