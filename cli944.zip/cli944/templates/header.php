<?php 
$site_start = microtime();
?>


<html>
<head>
	<link type='text/css' rel='stylesheet' href='/templates/style.css'>
	<title>944 Client Center</title>
	<script src="/system/js/jquery-1.3.2.min.js" language="javascript" type="text/javascript"></script>
	<script src="/system/js/jquery-ui-1.7.1.custom.min.js" language="javascript" type="text/javascript"></script>
</head>
<body>
<table cellpadding="0" cellspacing="0" width="980" border="0" bgcolor="#eeeeee" align="center">
	<tr>
		<td colspan="2" align="right" valign="bottom" class="header" onClick="location.href='/'">
			<div class = "header_text">Welcome <?php echo $myuser['contact_firstname']." ".$myuser['contact_lastname'];?>.&nbsp;[<a href="?logmeout=please">Logout</a>]</div>
		</td>
	</tr>
	<tr>
		<td class = "content_area" valign="top">
		
		