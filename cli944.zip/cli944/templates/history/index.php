<p class="section_title">Ad History</p>

<?php 
$query = "
select jt.*,oa.OAID, oa.tearfile, p.pub_name, ad_size_name as size, ad_position_name as position, i.iss_name as issue, DATEDIFF(iss_report_date,NOW()) as daysdiff
from job_tickets as jt
inner join orders_adsales as oa on oa.OAID = jt.OTID 
inner join orders as o on o.OID = oa.OID 
inner join pubs as p on p.id = oa.PubID
inner join issues as i on i.id = oa.IssueID
inner join ad_position as ap on ap.positionID = oa.PosID
inner join ad_size as s on s.sizeID = oa.SizeID
where OT='1' 

and o.CID='".$myuser['CID']."' 
and jt.last_status !='2'  
order by i.iss_report_date DESC";

$result = mysql_query($query) or die(mysql_error());


echo "<!-- \n".$query."\n -->";

function get_flipbook_page($OAID) {
	$query  = "SELECT i.mgid_final, mp.id, mp.bookID, mp.pagenum, mp.national, mp.nationalBookID, mp.nationalPageID, o.OID,DATE(o.sold_date) AS sold_date, mbs.status,oa.IssueID,o.comments,oa.placement,o.probability,oa.compsep, oa.national,oa.OAID,oa.PosID,i.iss_name ";
	$query .= "FROM 944x_944media.orders_adsales AS oa ";
	$query .= "LEFT JOIN 944x_944media.orders AS o ON oa.OID=o.OID ";
	$query .= "LEFT JOIN 944x_944media.issues AS i ON i.id=oa.IssueID ";
	$query .= "LEFT JOIN 944x_944media.magbuilder_book_sections mbs on mbs.rsvItemID = oa.OAID and mbs.type = '1' ";
	$query .= "LEFT JOIN 944x_944media.magbuilder_pages mp on mp.id = mbs.pageID  ";
	$query .= " WHERE oa.OAID = '".$OAID."' ";
	$query .= " AND mp.pageNum IS NOT NULL ";

	$result = mysql_query($query);

	$page = mysql_fetch_assoc($result);

	if ($page['mgid_final'] && $page['pagenum']) {
		$flipbook_url = 'http://proofcenter.944.com/newflipbook/'.$page['mgid_final'].'/'.($page['pagenum'] + 1).'/';
	}

	return $flipbook_url;
}

if (mysql_num_rows($result)>0) { 
?>


<table cellpadding="4" cellspacing="0" border="0" class = "activity_box" width="100%">
	<tr class = "row_title">
		<td>Issue</td>	
		<td>Size</td>	
		<td>Position</td>	
		<td>Tearsheet</td>
		<td>Flipbook</td>
		<td align="center">Artwork</td>	
	</tr>
<?php 

while ($row = mysql_fetch_assoc($result)) {
	$count++; ?>
	<tr class = "row<?php echo $count%2;?>">
		<td><?php echo $row['issue'];?></td>	
		<td><?php echo $row['size'];?></td>	
		<td><?php echo ($row['position']=="None"?"":$row['position']);?></td>	
		<td><?php 

			if ($order['tearfile']) {
				$order['tearfile'];
			} else {
				//see if the image is stored in the new magbuilder
				$sql = "select jt.*, oa.IssueID from job_tickets as jt LEFT JOIN orders_adsales as oa ON oa.OAID = jt.OTID where jt.OTID='".$row['OAID']."' AND jt.OT='1'";
				$ticket = mysql_fetch_assoc(mysql_query($sql));
				
				//print_r($ticket);
				
				##
				## Code Change - 2009-02-18 - Beau Frusetta
				## Modified query below to use $row["OAID"] instead of $ticket["TID"] 
				## per direction from Lavon Woods and the changes made within MagBuilder
				##
				//$sql = "select * from magbuilder_pieces where linkID = '1-".$ticket["TID"]."' ";
				
				//Lavon Edited Query Booooeeeeyyy!!
				$sql = "select * from magbuilder_pieces where ( (linkID = '1-".$ticket["TID"]."' AND OAID = '".$row['OAID']."') OR (linkID = '1-".$ticket["TID"]."') OR (linkID = '1-".$row['OAID']."' AND TID = 0) ) AND bookID = '".$ticket['IssueID']."' ";
				echo "<!-- ".$sql." -->";
				//Dont want to throw this testing query away so I am commenting it out
				/*
					select mp.id, mp.bookID, mp.linkID, jt.TID, oa.OAID from magbuilder_pieces as mp 
					LEFT JOIN job_tickets as jt ON jt.OT = '1' AND jt.OTID = SUBSTRING(mp.linkID FROM 3)
					LEFT JOIN orders_adsales as oa ON oa.OAID = SUBSTRING(mp.linkID FROM 3)
					where 
					(mp.linkID = '1-58441' AND mp.OAID = '57411') 
					OR 
					(mp.linkID = '1-58441') 
					OR 
					(mp.linkID = '1-57411' AND mp.TID = 0)
				*/
				//END Lavon Edited Query Booooeeeeyyy!!
				//echo "<!-- MagBuilder SQL: $sql -->";
				
				$img = mysql_fetch_assoc(mysql_query($sql));
				
				if ($img['id']) {
					$imgFile = "/magbuilder/pieces/".$img['bookID']."/".$img['id']."/large.jpg";
					print "<a href = 'http://proofcenter.944.com".$imgFile."'>View Tearsheet</a>";
				}
			
			}		
		
		?></td>
		<td>
			<?php 
				if ($mb_image = get_flipbook_page($row['OAID'])) {
					echo '<a href="'.$mb_image.'">View Flipbook</a>';
				}
			?>
		</td>
		<td align="center"><?php if ($row['daysdiff']>=0) { ?><a href = "/artwork/submit/?TID=<?php echo $row['TID'];?>">Submit Artwork</a> <?php } ?>&nbsp;</td>	

	</tr>
<?php } ?>
</table>

<?php } else { print "You have no sales history."; }?>