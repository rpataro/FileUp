<?php 
include_once('/var/www/html/com944x/www/inc/functions-only.php');

$query = "UPDATE company SET ccnum='".encrypt_cc($_POST['card_number'],$_POST['CID'])."',ccexp='".$_POST['card_exp']."' WHERE CID='".$_POST['CID']."'";
// echo $query;
mysql_query($query);

$result = pay_invoice($_POST['IVID'], $_POST['card_amount'], 1, $_POST);

if ($result['success']) {
	$success = true;
	$result = "The transaction was successful, thank you.";

	@include $_SERVER['DOCUMENT_ROOT']."/includes/class.phpmailer.php";
	$mail = new PHPMailer();
	$mail->Host = "localhost";
	$mail->From = "webmanager@944.com";
	$mail->FromName = "944 Client Center";
	$mail->IsHTML(true);
	$mail->Subject = "Contact Paid Invoice #:".$_POST['IVID'];
	$mail->Body = "Contact: ".$myuser['contact_firstname']." ".$myuser['contact_lastname']."<br>Paid $".number_format($_POST['card_amount'], 2)."<br>For Invoice #".$_POST['IVID']."<br>http://www.myjuggernaut.com/billing/payments/search/?inum=".$_POST['IVID'];
	$mail->AddAddress('receivables@944.com');
	$mail->AddAddress('emmanuel@944.com');
	$mail->Send();

	header("location:/invoices/pay/result/?result=$result");
	exit;
}
elseif ($result['full_array']['FinalStatus'] == 'badcard') {
	$result = "The information provided is not valid. Error message: ".$result['full_array']['MErrMsg'];
	$result .= "<p>Please double-check your credit card information and try again.</p>";
	header("location:/invoices/pay/result/?result=$result");
	exit;	
}
elseif ($result['full_array']['FinalStatus'] == 'fraud') {
	$result = "The information provided is not valid. Error message: ".$result['full_array']['MErrMsg'];
	$result .= "<p>Please double-check your credit card information and try again.</p>";
	header("location:/invoices/pay/result/?result=$result");
	exit;	
}
elseif ($result['full_array']['FinalStatus'] == 'problem') {
	$result = "There was a problem processing this card. Error message: ".$result['full_array']['MErrMsg'];
	$result .= "<p>Please double-check your credit card information and try again.</p>";
	header("location:/invoices/pay/result/?result=$result");
	exit;	
}
else {
	// this should not happen
	$result = "There was an error processing your credit card, please try again.";
	header("location:/invoices/pay/result/?result=$result");
	exit;
}

?>