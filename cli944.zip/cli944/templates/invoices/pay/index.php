<?php 
$c = mysql_fetch_assoc(mysql_query("SELECT c.*,i.contact_firstname,i.contact_lastname FROM company AS c INNER JOIN contacts AS i ON i.CID=c.CID AND c.BIID = i.IID WHERE c.CID='".$myuser['CID']."'"));

?>
<div class='section_title'>Pay Invoice</div>
<!-- <div class = "dotted"></div> -->

<form method="post" name = "ccinfo">
	<table cellpadding="0" cellspacing="6" border="0" class="activity_box" width=500>
		<tr><td width=1% nowrap>Name:</td><td><input class = "textbox"  type="text" name="card_name" size="30" maxlength="30" value="<?php echo $c['contact_firstname']." ".$c['contact_lastname'];?>"></td></tr>
		<tr><td width=1% nowrap>Address</td><td><input class = "textbox"  type="text" name="card_address1" size="30" maxlength="30" value="<?php echo $c['company_address'];?>"></td></tr>
		<tr><td></td><td><input class = "textbox"  type="text" name="card_address2" size="30" maxlength="30" value="<?php echo $c['company_address2'];?>"></td></tr>

		<tr><td width=1% nowrap>City:</td><td><input class = "textbox"  type="text" name="card_city" size="30" maxlength="30" value="<?php echo $c['company_city'];?>"></td></tr>
		<tr><td width=1% nowrap>State:</td><td><input class = "textbox"  type="text" name="card_state" size="2" maxlength="2" value="<?php echo $c['company_state'];?>"></td></tr>
		<tr><td width=1% nowrap>Zip:</td><td><input class = "textbox"  type="text" name="card_zip" size="12" maxlength="12" value="<?php echo $c['company_zip'];?>"></td></tr>

		<tr>
			<td width=1% nowrap class='search_red'>Payment Method</td>
			<td colspan=4>
				<select name='method' style='width:430px;'>
					<option value='4'>Visa</option>
					<option value='5'>MasterCard</option>
					<option value='6'>Discover</option>
					<option value='8'>Amex</option>
				</select>
			</td>
		</tr>

		<tr><td width=1% nowrap>Card Number:</td><td><input class = "textbox"  type="text" name="card_number" size="20" maxlength="20" value=""></td></tr>
		<tr><td width=1% nowrap>Exp Date: (MM/YY)</td><td><input class = "textbox"  type="text" name="card_exp" size="6" maxlength="6" value="<?php echo $c['ccexp'];?>"></td></tr>
		<tr><td width=1% nowrap>CVV Code</td><td><input class = "textbox"  type="text" name="card_cvv" size="4" maxlength="4" value="<?php echo $c['cc_cvv'];?>"></td></tr>
		<tr><td width=1% nowrap>Amount:</td><td><input class = "textbox"  type="text" name="card_amount" size="10" maxlength="10" value="<?php echo $_GET['amount'];?>"></td></tr>
	</table>

	<input class = "button" type="submit" value="Submit">

	<input class = "textbox" type='hidden' name='CID' value='<?php echo $myuser['CID'];?>'>
	<input class = "textbox" type='hidden' name='IVID' value='<?php echo $_GET['IVID'];?>'>
</form>