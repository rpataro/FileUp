<div class='section_title'>Payment Result</div>
<div class = "dotted"></div>

<?php echo ($_GET['result']=="success"?"Payment Successfull":$_GET['result']);?>