<!--
	
<?php print_r($myuser); ?>
	
-->
<p class="section_title">Open Invoices</p>

<?php 

$invoices_sql = "
	SELECT invoices.OTID, 
	 	   invoices.OT, 
	  	   invoices.IVID, 
	       issues.iss_name, 
		   DATE_FORMAT(invoices.invoice_date, '%m/%d/%Y') AS 'invoice_date', 
		   DATE_FORMAT(invoices.invoice_duedate, '%m/%d/%Y') AS 'invoice_duedate', 
		   company.company_name AS 'company', 
		   IFNULL(agency.company_name,'None') AS 'agency', 
		   IFNULL(payments.payments,0) AS 'payments', 
		   IFNULL(payments.barter_payments,0) AS 'barter_payments', 
		   (orders_adsales.net - orders_adsales.barter) AS 'invoice_total', 
		   ((orders_adsales.net - orders_adsales.barter) - IFNULL(payments.payments,0)) AS 'balance_due' 
	FROM invoices 
		 INNER JOIN orders ON orders.OID = invoices.OID 
		 INNER JOIN company ON company.CID = orders.CID 
		 LEFT JOIN company AS agency ON agency.CID = invoices.AID 
		 INNER JOIN orders_adsales ON orders_adsales.OAID = invoices.OTID 
		 INNER JOIN issues ON issues.id = orders_adsales.IssueID 
		 INNER JOIN pubs ON pubs.id = orders_adsales.PubID 
	 	 LEFT JOIN (SELECT SUM(CASE WHEN method IN (94,95) THEN payments*-1 ELSE payments END) AS 'payments',
				   	   	   SUM(barter_payments) AS 'barter_payments', 
				       	   IVID 
					FROM payments
					WHERE CID = ".$myuser['CID']." 
					GROUP BY IVID) AS payments ON payments.IVID = invoices.IVID 
	WHERE invoices.OT = 1 
		  AND orders.CID = ".$myuser['CID']." 
		  AND (orders_adsales.net - orders_adsales.barter) > 0 
		  AND ((orders_adsales.net - orders_adsales.barter) - IFNULL(payments.payments,0)) > 0
	ORDER BY issues.iss_report_date
";
$invoices_query = mysql_query($invoices_sql);

$count = 0;

if (mysql_num_rows($invoices_query)==0) { 
	?> <p>You do not have any open invoices at this time. If you feel this information is inaccurate, please contact your Sales Representative.</p> <?php
} else {
	?>
	
	<p>Below is a list of invoices that have not yet been paid.  If you feel this information is inaccurate, please contact your Sales Representative.</p>
	
	<table cellpadding="4" cellspacing="0" border="0" class="activity_box" width="100%">
		<tr class="row_title">
			<td>Issue</td>
			<td>Invoice Amount</td>
			<td>Invoice Date</td>
			<td>Invoice Due Date</td>
			<td>View Invoice</td>
			<td>Pay Invoice</td>
		</tr>
		<?php while ($row = mysql_fetch_object($invoices_query)) { ?>
		<?php $count++; ?>
		<tr class="row<?php echo $count%2;?>">
			<td><?php echo $row->iss_name;?></td>
			<td>$<?php echo number_format($row->invoice_total,2);?></td>
			<td><?php echo date('m/d/Y', strtotime($row->invoice_date));?></td>
			<td><?php echo date('m/d/Y', strtotime($row->invoice_duedate));?></td>
			<td><a href="/pdf/?OT=1&OTID=<?php echo $row->OTID;?>" title="View Invoice" target="_blank">View Invoice</a></td>
			<td><a href="/invoices/pay/?IVID=<?php echo $row->IVID;?>&amount=<?php echo $row->balance_due;?>" title="Pay Invoice">Pay Invoice</a></td>
		</tr>
		<?php } ?>
	</table>
	
	<?php 
}