<?php 
	
	@include $_SERVER['DOCUMENT_ROOT']."/includes/class.phpmailer.php";
   $mail = new PHPMailer();
  // $mail->IsSMTP();
   $mail->Host = "localhost";
   $mail->From = $_POST['email'];
   $mail->FromName = $_POST['name'];
   $mail->IsHTML(true);
   $mail->Subject = ($_POST['subject']?$_POST['subject']:"Clients.944.com Address Change");
   $mail->Body = nl2br($_POST['body'])."<p>http://www.myjuggernaut.com/contacts/view/?id=".$myuser['IID'];
   $mail->AddAddress('finance@944.com');
   $mail->AddAddress('billing@944.com');
   //$mail->AddAddress('davidg@944.com');
	
   if ($mail->Send()) {
   	header("Location: /address/?email=sent");
     exit;
   } else {
     header("Location: /address/?email=error");
     exit;
   }
   ?>