<?php 
if ($_GET['TID']) {
	$ticket = mysql_fetch_assoc(mysql_query("
		select jt.*, oa.OAID, u.fname,u.lname,u.email, o.OID, p.pub_name, ad_size_name as size, ad_position_name as position, i.iss_name as issue, p.online
		from job_tickets as jt
		left join users as u on u.userid = jt.assigned
		inner join orders_adsales as oa on oa.OAID = jt.OTID 
		inner join orders as o on o.OID = oa.OID 
		inner join pubs as p on p.id = oa.PubID
		inner join issues as i on i.id = oa.IssueID
		inner join ad_position as ap on ap.positionID = oa.PosID
		inner join ad_size as s on s.sizeID = oa.SizeID
		where jt.TID='".$_GET['TID']."'"));

	$no_ticket = false;

	# Specify if the ad is an online ad, which will require a URL
	$online_ad = $ticket['online'];
}

else {
	# If no TID is passed, it's a file to be uploaded into the queue
	$no_ticket = true;
}

if ($no_ticket) {
	$header_text = 'Upload Into Queue: '.stripslashes($myuser['company_name']);
	$iframe_params = 'IID='.$myuser['IID'].'&ticketID=0&CID='.$myuser['CID'];
	$finished_link = 'CID='.$myuser['CID'];
	$passed_ticketID = 'CID-'.$myuser['CID'];
}
else {
	$header_text = $ticket['issue'].' ('.$ticket['size'] . ($ticket['position']!="None" ? $ticket['position'] : '').')';
	$iframe_params = 'IID='.$myuser['IID'].'&ticketID='.$ticket['TID'];
	$finished_link = 'TID='.$_GET['TID'];
	$passed_ticketID = $_GET['TID'];
}

if ($success == "true") { ?>
	<div class = "section_title">
	Artwork Submitted...</div>
	<div class = "dotted" ></div>
	<p><?php echo $ticket['issue'];?> (<?php echo $ticket['size'] ." ". ($ticket['position']!="None"?$ticket['position']:"");?>)</p>	
	<b><?php echo $filename;?></b> has been submitted!
	<br><br>
	<?php if ($_POST['description']) { ?>
	<b>Your Notes:</b><br>
	<div style = "margin:5px 50px 20px 0px;border:solid 1px #888888;background:#f7f7f7;padding:4px;">
		<?php echo nl2br($_POST['description']);?>
	</div>
	<?php } ?>
	<div class = "icon"><a href = "/artwork/"><img border=0 src = "/images/icons/picture.gif" align="left"> Return to Artwork</a></div>
<?php } elseif ($success=="false") { ?>
	<div class = "section_title">
	Error Submitting Artwork</div>
	<div class = "dotted" ></div>
	There was a problem uploading your Artwork.  Please try again.  If you continue to receive this message, contact your Sales Representative.
	<p>
	<a href = "/artwork/submit?TID=<?php echo $_GET['TID'];?>">Try Again</a>
	</p>
<?php } else { ?>
	<script type="text/javascript" src="/js/si.files.js"></script>

	<script language="javascript">
	function showfile(strPath) {

		document.getElementById('filebox').innerHTML = strPath
	}
	</script>

	
	
	
	<link rel="stylesheet" type="text/css" href="/system/css/swfupload.css" />
	<script type="text/javascript" src="/system/js/swfupload/swfupload.js"></script>
	<script type="text/javascript" src="/system/js/jquery.swfupload.js"></script>

	<script type="text/javascript">
	$(function(){
		$('#swfupload-control').swfupload({
			upload_url: "/templates/artwork/submit/upload.phpx",
			file_post_name: 'file',
			file_size_limit : "0",
			<?php if ($online_ad) : ?>
				file_types : "*.jpg;*.jpeg;*.gif;*.png;*.swf",
			<?php elseif ($online_ad === '0') : ?>
				file_types : "*.pdf",
			<?php else : ?>
				file_types : "*.*",
			<?php endif; ?>
			file_upload_limit : 10,
			flash_url : "/images/swfupload.swf",
			button_image_url : "/images/wdp_buttons_upload_114x29.png",
			button_width : 114,
			button_height : 29,
			button_placeholder : $('#upldbutton')[0],
			debug: false
		})
			
			
			.bind('fileQueued', function(event, file){
				
				<?php if ($online_ad) { ?>
						var url = $('#url').val();
						if (url != '') {
							var listitem='<li id="'+file.id+'" >'+
								'File: <em>'+file.name+'</em> ('+Math.round(file.size/1024)+' KB) <span class="progressvalue" ></span>'+
								'<div class="progressbar" ><div class="progress" ></div></div>'+
								'<p class="status" >Pending</p>'+
								'<span class="cancel" >&nbsp;</span>'+
								'</li>';
							$('#log').append(listitem);
							$('li#'+file.id+' .cancel').bind('click', function(){
								var swfu = jQuery.swfupload.getInstance('#swfupload-control');
								swfu.cancelUpload(file.id);
								$('li#'+file.id).slideUp('fast');
							});

							// Set the parameters
						    var param = {
								"action" : "upload",
						    	"ticketID" : "<?php echo $passed_ticketID?>",
								"IID" : "<?php echo $myuser['IID'];?>",
								"CID" : "<?php echo $myuser['CID'];?>",
								"company_name" : "<?php echo $myuser['company_name'];?>",
								"contact_firstname" : "<?php echo $myuser['contact_firstname'];?>",
								"url" : $('#url').val(),
								"OAID" : "<?php echo $ticket['OAID'];?>"
						    };
						    $(this).swfupload('setPostParams', param);

				            // start the upload since it's queued
				
							$(this).swfupload('startUpload');
						} else {
							alert('You must enter a URL for this banner before uploading your file(s).');
							return false;
						}
				
				<?php } else { ?>
						var listitem='<li id="'+file.id+'" >'+
							'File: <em>'+file.name+'</em> ('+Math.round(file.size/1024)+' KB) <span class="progressvalue" ></span>'+
							'<div class="progressbar" ><div class="progress" ></div></div>'+
							'<p class="status" >Pending</p>'+
							'<span class="cancel" >&nbsp;</span>'+
							'</li>';
						$('#log').append(listitem);
						$('li#'+file.id+' .cancel').bind('click', function(){
							var swfu = jQuery.swfupload.getInstance('#swfupload-control');
							swfu.cancelUpload(file.id);
							$('li#'+file.id).slideUp('fast');
						});

						// Set the parameters
					    var param = {
							"action" : "upload",
					    	"ticketID" : "<?php echo $passed_ticketID?>",
							"IID" : "<?php echo $myuser['IID'];?>",
							"CID" : "<?php echo $myuser['CID'];?>",
							"company_name" : "<?php echo $myuser['company_name'];?>",
							"contact_firstname" : "<?php echo $myuser['contact_firstname'];?>",
							"OAID" : "<?php echo $ticket['OAID'];?>"
					    };
					    $(this).swfupload('setPostParams', param);

			            // start the upload since it's queued

						$(this).swfupload('startUpload');
				<?php } ?>
			})
			
			
			.bind('fileQueueError', function(event, file, errorCode, message){
				alert('Size of the file '+file.name+' is greater than limit');
			})
			.bind('fileDialogComplete', function(event, numFilesSelected, numFilesQueued){
				$('#queuestatus').text('Files Selected: '+numFilesSelected+' / Queued Files: '+numFilesQueued);
			})
			.bind('uploadStart', function(event, file){
				$('#log li#'+file.id).find('p.status').text('Uploading...');
				$('#log li#'+file.id).find('span.progressvalue').text('0%');
				$('#log li#'+file.id).find('span.cancel').hide();
			})
			.bind('uploadProgress', function(event, file, bytesLoaded){
				//Show Progress
				var percentage=Math.round((bytesLoaded/file.size)*100);
				$('#log li#'+file.id).find('div.progress').css('width', percentage+'%');
				$('#log li#'+file.id).find('span.progressvalue').text(percentage+'%');
			})
			.bind('uploadSuccess', function(event, file, serverData){
				var item=$('#log li#'+file.id);
				item.find('div.progress').css('width', '100%');
				item.find('span.progressvalue').text('100%');
				//var pathtofile='<a href="/cdata/944/projects/'+file.name+'" target="_blank" >view &raquo;</a>';
				item.addClass('success').find('p.status').html('File Successfully Uploaded');
			})
			.bind('uploadComplete', function(event, file){
				// upload has completed, try the next one in the queue
				$(this).swfupload('startUpload');
			})

	});
	</script>

	<div class = "section_title">
		Submit Artwork
	</div>
	<!-- <div class = "dotted" ></div> -->

	<?php echo $header_text?>
	<br><br>


	<?php if ($online_ad) { ?>
		<label><b>URL:</b> </label>
		<input type="text" name="url" id="url" />
	<?php } ?>
	<div id="swfupload-control">
		<p>
			<?php if ($online_ad) : ?>
				<strong>Only JPG, PNG, GIF or SWF files are accepted for online ads</strong>. Upload up to 10 files, use ctrl (command/apple key for mac) to select multiple files.
			<?php elseif ($online_ad === '0') : ?>
				<strong>Only high-res PDF files are accepted for print ads</strong>. Upload up to 10 files, use ctrl (command/apple key for mac) to select multiple files.
			<?php else : ?>
				<strong>Only high-res PDF files are accepted for print ads.<br/>JPG, PNG, GIF or SWF files are accepted for online ads</strong>.<br/><br/>Upload up to 10 files, use ctrl (command/apple key for mac) to select multiple files.
			<?php endif; ?>
		</p>
		<input type="button" id="upldbutton" />
		<p id="queuestatus" ></p>
		<ol id="log"></ol>
	</div>
	
	<h3>Finished uploading?  <a href="/artwork/images/?<?php echo $finished_link?>">Click here</a>.</h3>

	<div class = "dotted" ></div>

	<h2>Having trouble with the flash uploader? Upload your file the old-fashioned way</h2>

	<form method="POST" enctype="multipart/form-data" action="/templates/artwork/submit/upload.phpx">
		<input type="hidden" name="ticketID" value="<?php echo $passed_ticketID?>">
		<input type="hidden" name="old_upload" value="1">
		<input type="hidden" name="IID" value="<?php echo $myuser['IID']?>">
		<input type="hidden" name="action" value="upload">

	<div style = "float:left;">
		<label class="cabinet"> 
		    <input type="file" name = "file" class="file" onchange="showfile(this.value);" />
		</label>
	</div>
	<div style = "float:left;margin:6px 0px 0px 5px;" id="filebox"></div>
	<br clear="all">
	<br clear="all">
	<!-- Optional description/directions: -->
	<!-- <textarea  name = "description" style = "font-size:11px;font-family:helvetica, sans-serif;color:#222222;background:#f7f7f7; border:solid 1px #888888;padding:2px;margin:5px 0px 10px 0px;width:100%;height:100px"></textarea> -->
	<br clear="all">
	<input class = "button" type="submit" value="Upload File">

	</form>

	<script type="text/javascript" language="javascript">
	SI.Files.stylizeAll();
	</script>

<?php } ?>