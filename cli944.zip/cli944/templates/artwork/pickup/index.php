<?php 
include_once('/var/www/html/com944x/www/includes/functions-only.php');

$ticket = mysql_fetch_assoc(mysql_query("
select jt.*, u.fname,u.lname,u.email, p.pub_name, p.online, oa.IssueID, oa.OAID, oa.SizeID, ad_size_name as size, ad_position_name as position, ad_spread, i.iss_name as issue
from job_tickets as jt
left join users as u on u.userid = jt.assigned
inner join orders_adsales as oa on oa.OAID = jt.OTID
inner join orders as o on o.OID = oa.OID
inner join pubs as p on p.id = oa.PubID
inner join issues as i on i.id = oa.IssueID
inner join ad_position as ap on ap.positionID = oa.PosID
inner join ad_size as s on s.sizeID = oa.SizeID
where jt.TID='".$_GET['TID']."'"));


$result = mysql_query("
select jt.*, p.pub_name, c.company_name, oa.OAID, ad_size_name as size, ad_position_name as position, ad_spread, i.iss_name as issue
from job_tickets as jt
inner join orders_adsales as oa on oa.OAID = jt.OTID
inner join orders as o on o.OID = oa.OID
inner join pubs as p on p.id = oa.PubID
inner join issues as i on i.id = oa.IssueID
inner join ad_position as ap on ap.positionID = oa.PosID
inner join ad_size as s on s.sizeID = oa.SizeID
inner join company c on c.CID = o.CID
where OT='1'

and o.CID='".$myuser['CID']."'
and jt.last_status !='2' AND p.online = '".$ticket['online']."' AND oa.SizeID = '".$ticket['SizeID']."' 
order by p.online, p.pub_name, i.iss_report_date DESC") or die(mysql_error());

function get_magbuilder_image($TID, $OAID, $IssueID) {
	$sql = "SELECT * FROM magbuilder_pieces WHERE ( (linkID = '1-".$TID."' AND OAID = '".$OAID."') OR (linkID = '1-".$TID."') OR (linkID = '1-".$OAID."' AND TID = 0) ) AND bookID = '".$IssueID."' ";
	// echo $sql;
	$img = mysql_fetch_assoc(mysql_query($sql));

	if ($img['id']) {
		$imgFile = "/magbuilder/pieces/".$img['bookID']."/".$img['id']."/large.jpg";
		return $imgFile;
	} 
	else {
		return FALSE;
	}	
}

// test
/*
if (!$_POST['pickup_ticket']) {
	$_POST['pickup_ticket'] = 62085;
	// $ticket = mysql_fetch_assoc(mysql_query("select jt.*, oa.IssueID from job_tickets AS jt LEFT JOIN orders_adsales AS oa ON oa.OAID = jt.OTID where jt.TID = '".$_POST['pickup_ticket']."' AND jt.OT = '1'"));
	$query = "select jt.*, oa.IssueID from job_tickets AS jt LEFT JOIN orders_adsales AS oa ON oa.OAID = jt.OTID where jt.OTID = '".$_POST['pickup_ticket']."' AND jt.OT = '1'";
	// echo $query;
	$pickup = mysql_fetch_assoc(mysql_query($query));

	$old_file = get_magbuilder_image($pickup['TID'], $_POST['pickup_ticket'], $pickup['IssueID']);
	// echo 'old file: '.$old_file;

	$old_file = get_magbuilder_image($pickup['TID'], $_POST['pickup_ticket'], $pickup['IssueID']);
	$filename_with_path = $old_file;
	$filename = array_pop(explode('/', $filename_with_path));
	echo $filename;

	unset($_POST['pickup_ticket']);
}
*/
// end test

?>

<script type="text/javascript" charset="utf-8">
	function saveImage(CFID, ticket_id, OTID, path) {
		$.post('http://www.myjuggernaut.com/ajax/jobtickets.phpx', {
			CFID: CFID,
			ticket_id: ticket_id,
			OTID: OTID,
			path: path,
			userid: 1,
			action: "send_to_magbuilder"
		}, function(data) {
			// alert('File saved successfully.' + data);
		});
	}
</script>


 <form name=pickup method=post action=/artwork/pickup/?TID=<?php echo $_GET['TID']?>>
 <div class = "section_title">
Submit Pickup Request</div>
<!-- <div class = "dotted" ></div> -->
<?php echo $ticket['issue'];?> (<?php echo $ticket['size'] . ($ticket['position']!="None" ? " ".$ticket['position'] : "");?>)

<?php if (!$_POST['pickup_ticket']) { ?>
        <!-- Form for defining which pickup -->
        <br><br>
        <p>Please select an issue to pick up from:</p>
        <blockquote>
        <?php 
            while ($row=mysql_fetch_assoc($result)) {
        ?>
            	<input type=radio name=pickup_ticket value="<?php echo $row['OAID']?>">
        	<?php 
				# Check to see if an image already exists in the ticket, and offer a preview if so
				$file = get_newest_file_from_ticket($row['TID']);
				$filename = '/var/www/html/com944x/www'.$file;

				if (file_exists($filename) && $file) {
					echo "<a href = 'http://www.myjuggernaut.com".$file."' target='_blank'>".$row['issue']."</a><br>";
				}
				else {
					echo $row['issue']."<br>";
				}
			} //while row = fetch assoc
        	?>
		</blockquote>
		<input type="submit" name="Submit" class="button" onClick="return confirm('Are you sure you wish to mark this ad as a pickup?');" value="Submit Pickup Request" />

<?php } else {

    # Send pickup confirmation
	// $ticket = mysql_fetch_assoc(mysql_query("select jt.*, oa.IssueID from job_tickets AS jt LEFT JOIN orders_adsales AS oa ON oa.OAID = jt.OTID where jt.TID = '".$_GET['TID']."' AND jt.OT = '1'"));

	$pickup = get_pickup_details($_POST['pickup_ticket']);

    $rep = mysql_fetch_assoc(mysql_query("select r.* from company as c inner join users as r on r.userid = c.company_primary_rep where c.CID ='".$myuser['CID']."'"));

	# Copy the old file into the pickup job ticket so that it can be easily pushed to Magbuilder
	// $old_file = get_magbuilder_image($pickup['TID'], $_POST['pickup_ticket'], $pickup['IssueID']);
	// $filename_with_path = $old_file;
	$filename_with_path = recursive_pickup_check($_POST['pickup_ticket']);
	$filename = array_pop(explode('/', $filename_with_path));

	$file_note = (file_exists($filename_with_path)) ? '<br><br>Pickup file found and automatically placed as new Client File in ticket.' : '';


	mysql_query("INSERT INTO order_status SET
			SDEFID='45',
			OT='1',
			OTID='".$_GET['TID']."',
			orderstatus_created_date='".date("Y-m-d H:i:s",strtotime("now"))."',
			orderstatus_creator='1',
            orderstatus_notes='Pickup Request From Client Center:<br> ".$pickup['ticket_name']." $file_note'
			");
	$order_status_id = mysql_insert_id();

	mysql_query("UPDATE job_tickets SET last_status='45' WHERE TID='".$_GET['TID']."'");
	mysql_query("UPDATE orders_adsales SET pickup_OAID = '".$_POST['pickup_ticket']."' where OAID='".$ticket['OTID']."'");

   @include $_SERVER['DOCUMENT_ROOT']."/includes/class.phpmailer.php";
	$mail = new PHPMailer();
	$mail->Host = "localhost";
	$mail->From = "webmanager@944.com";
	$mail->FromName = "Client Artwork";
	$mail->IsHTML(true);
	$mail->Subject = "Pickup ".$myuser['company_name'];
	$mail->Body = "Advertiser: ".$myuser['company_name']."<br>Contact: ".$myuser['contact_firstname']." ".$myuser['contact_lastname']." <br>For Ticket: ".$ticket['ticket_name']."<br>http://www.myjuggernaut.com/production/jobtickets/jobjacket/?id=".$_GET['TID']."<br>Pickup: ".$pickup['ticket_name'].$file_note;
	$mail->AddAddress('ads@944.com');
    $mail->AddCC($rep['email']);
    // $mail->AddAddress("juggernaut@944.com");
	$mail->Send() or die('Error sending e-mail alert');


	# Old system, copying JPG's into the latest status
	/*
	$step_query = "SELECT * FROM order_status WHERE OSID = '".$order_status_id."'";
	$step_result = mysql_query($step_query);
	$step = mysql_fetch_assoc($step_result);

	$_POST['folder'] = date("Y/m/d",strtotime($step['orderstatus_created_date']))."/".$step['OSID'];
	$final_path = "/var/www/html/com944x/www/cdata/944/order_status/";

	$path = $final_path;
	if(!file_exists($final_path.$_POST['folder'])) {
		$folder_array = explode("/",$_POST['folder']);
		foreach ($folder_array as $item) {
			$path .= $item."/";
			exec ("mkdir ".$path);
		}
	}

	# Only copy the file if a magbuilder piece already exists
	if (file_exists($filename_with_path)) {
		copy($filename_with_path, $final_path.$_POST['folder']."/".strtotime("now")."___".str_replace(" ","",$filename));
	}
	*/

	# New system, copy PDF into the Paperless upload area of new ticket
	if (file_exists($filename_with_path)) {
		mkdir("/var/www/html/com944x/public_html/cdata/944/client_files/".$_GET['TID']);
		$root_path = "/var/www/html/com944x/public_html";
		$path = "/cdata/944/client_files/".$_GET['TID'];

		mysql_query("INSERT INTO job_clientfiles SET TID='".$_GET['TID']."', date=NOW(), IID='".$myuser['IID']."', filename='$filename', description='".$_POST['description']."', source = 3");
	
		$job_clientfiles_insert_id = mysql_insert_id();

		copy($filename_with_path, $root_path.$path."/".$filename);

		# Only push through full pages for now
		if (($ticket['SizeID'] == 1 || $ticket['ad_spread'] == 1) && $filename) {
			send_to_magbuilder($job_clientfiles_insert_id, $_GET['TID'], $ticket['OAID'], $path.'/'.$filename, 1, 1, 1, $ticket['ad_spread']);
			
			?>
				<!-- <script type="text/javascript" charset="utf-8">
					$(document).ready(function() {
						saveImage('<?php echo $job_clientfiles_insert_id?>', '<?php echo $_GET['TID']?>', '<?php echo $ticket['OAID']?>', '<?php echo $path."/".$filename?>');
					});
				</script>	 -->
			<?php 
		}
	}
?>

        <!-- Confirm the pickup -->
		<br/>
		<br/>
		<p>
        	Thank you!  We've received your request to pick up artwork from:
		</p>

		<p>
			<?php echo stripslashes($pickup['ticket_name'])?>.
		</p>
<?php } ?>
        </form>
