<?php 
include_once('/var/www/html/com944x/www/inc/functions-only.php');

$first_date = date('Y-m-01');
// $iss_report_date = date('Y-m-d', strtotime('+ 1 month', strtotime($first_date)));
$iss_report_date = common_getCurrentIssueDate();

?>
<script type="text/javascript" charset="utf-8">
	function assignArtwork(id) {
		
		var control = document.getElementById("issueid-"+id);
		var ticketid = control.options[control.selectedIndex].value;
		
		if (ticketid!=0) { 
			$("#assign-artwork-form-"+id).fadeOut('fast', function() {
				$("#assign-artwork-submit-"+id).fadeIn('fast', function() {
					$.post('/ajax/company.phpx', {
						action: 'assign-artwork', 
						ticketid: ticketid, 
						cid: document.getElementById("cid-"+id).value, 
						filename: document.getElementById("filename-"+id).value, 
						cfid: id 
					}, function(data) {
						$("#artwork-"+id).html('<td colspan="3" align="left"><strong>Artwork has been assigned!</strong> Refresh this page to see the artwork assigned to this issue.</td>');
					});
				});
			});
		} else {
			alert("You must select an issue to assign the artwork to.");
		}
	}
</script>

<p class="section_title">Submit Artwork</p>

<p>
	Please review the ad design templates and artwork specs to ensure accuracy of your printed files. 
	Templates are available for each standard 944 ad size in Illustrator, Photoshop and InDesign.
</p>

<p>
	<a href="/artwork/guidelines/">View the <?php echo date('Y')?> Ad Design Templates</a>
</p>

<p>
	<a href="/images/2009_ad_specs.pdf">View the <?php echo date('Y')?> Artwork Specs/Deadlines</a>
</p>

<p class="section_title">
	Select from the following pending Advertisements:
</p>

<?php 

$sql = "
select jt.*, p.pub_name, c.company_name, ad_size_name as size, ad_position_name as position, i.id AS issues_id, i.iss_name as issue, oa.pickup_OAID 
from job_tickets as jt
inner join orders_adsales as oa on oa.OAID = jt.OTID 
inner join orders as o on o.OID = oa.OID 
inner join pubs as p on p.id = oa.PubID
inner join issues as i on i.id = oa.IssueID
inner join ad_position as ap on ap.positionID = oa.PosID
inner join ad_size as s on s.sizeID = oa.SizeID
inner join company c on c.CID = o.CID
where OT='1' 

and o.CID='".$myuser['CID']."' 
and jt.last_status !='2'    and (datediff(iss_material_date,now()) >= 0 OR iss_report_date >= '".$iss_report_date."')
order by i.iss_report_date asc, p.online, p.pub_name"
;

$result = mysql_query($sql) or die(mysql_error());

//		and i.iss_ad_date > '".date("Y-m-d")."'

echo "<!-- SQL: $sql -->";

$issues = array();

if (mysql_num_rows($result)>0) { 
?>


<table cellpadding="4" cellspacing="0" border="0" class = "activity_box" width="100%">
	<tr class = "row_title">
        <td>Client</td>
		<td>Issue</td>
		<td>Size</td>
		<td>Position</td>
		<td align="center">Date Ordered</td>	
		<td colspan=3></td>
	</tr>
<?php 

while ($row = mysql_fetch_assoc($result)) {
	$issues[$row['TID']] = $row['issue'];
	$count++; ?>
	<tr class = "row<?php echo $count%2;?>">
        <td><?php echo $row['company_name']?></td>
		<td><?php echo $row['issue'];?></td>
		<td><?php echo $row['size'];?></td>	
		<td><?php echo ($row['position']=="None"?"":$row['position']);?></td>	
		<td align="center"><?php echo date("m/d/y",strtotime($row['created_date']));?></td>	
		<td align="center">
		<?php 
		$files = mysql_query("select CFID from job_clientfiles where TID='".$row['TID']."'");
		if (mysql_num_rows($files) > 0) { 
			echo "<a href = '/artwork/images/?TID=".$row['TID']."'><img border=0 src = '/images/icons/images.gif'> View Artwork</a>"; 
		}
		elseif ($row['pickup_OAID']) {
			echo 'Pickup Submitted';
		}
		?>
		</td>
        <td align="right"><a href = "/artwork/pickup/?TID=<?php echo $row['TID'];?>"><?php echo ($row['pickup_OAID']) ? 'Change' : 'Submit'?> Pickup</a></td>
		<td align="right"><a href = "/artwork/submit/?TID=<?php echo $row['TID'];?>">Upload New Art</a></td>
	</tr>
<?php } ?>
</table>

<?php 
}

else {
	echo '<p style="font-weight: bold;">No pending ads were found.</p>';
}

echo '<div class = "dotted" ></div>';

if ($myuser['CID'] == 34387 || 1 == 1) { // Yeah, Beau will LOVE that 1 == 1 :) 
	echo '<p class="section_title">Queue For Artwork With Unassigned Issues</p>';
	// echo '<h3>Queue For Artwork With Unassigned Issues</h3>';

	// Display artwork in queue
	
	$queue_query = "SELECT cf.*, CONCAT(c.contact_firstname, ' ', c.contact_lastname) AS contact_name FROM job_clientfiles AS cf LEFT JOIN contacts AS c ON c.IID = cf.IID WHERE cf.CID = '".$myuser['CID']."' AND cf.TID = '0'";
	$queue_result = mysql_query($queue_query);

	if (mysql_num_rows($queue_result)) :
		?>

		<table cellpadding="4" cellspacing="0" border="0" class = "activity_box" width="100%">
			<tr class = "row_title">
		        <td>Uploaded</td>
		        <td>Uploaded By</td>
				<td>Filename</td>
				<td>Assign to Issue</td>
			</tr>
		<?php 

		while ($row = mysql_fetch_assoc($queue_result)) {
			$count++; ?>
			<tr class = "row<?php echo $count%2;?>" id="artwork-<?php echo $row["CFID"];?>">
				<td><?php echo date("m/d/y g:ia",strtotime($row['date']));?></td>	
		        <td><?php echo stripslashes($row['contact_name']);?></td>
		        <td><a href="http://www.myjuggernaut.com/cdata/944/client_files/CID-<?php echo $myuser['CID']?>/<?php echo $row['filename']?>"><?php echo stripslashes($row['filename']);?></a></td>
				<td>
					<div id="assign-artwork-<?php echo $row["CFID"];?>" class="assign-artwork">
						<div id="assign-artwork-form-<?php echo $row["CFID"];?>">
							<form>
								<!-- <fieldset  style="border: 0; margin-left: 0; padding-left: 0;"> -->
									<select name="issueid-<?php echo $row["CFID"];?>" id="issueid-<?php echo $row["CFID"];?>">
										<option value="0">Select Issue</option>
										<?php foreach($issues as $id=>$name) { ?>
										<option value="<?php echo $id;?>"><?php echo $name;?></option>
										<?php } ?>
									</select>
									<a href="javascript:assignArtwork(<?php echo $row["CFID"];?>);" title="Assign Issue"><span>Assign Issue</span></a>
									
									<input type="hidden" name="cid-<?php echo $row["CFID"];?>" id="cid-<?php echo $row["CFID"];?>" value="<?php echo $myuser['CID'];?>" />
									<input type="hidden" name="filename-<?php echo $row["CFID"];?>" id="filename-<?php echo $row["CFID"];?>" value="<?php echo $row["filename"];?>" />
									
								<!-- </fieldset> -->
							</form>
						</div>
						<div id="assign-artwork-submit-<?php echo $row["CFID"];?>" style="display:none;">
							<p class="submit">Assigning Artwork... <img src="/images/ajax-loader2.gif" class="submit"></p>
						</div>
						<div class="cleaner"></div>
					</div>
				</td>

				<!-- <td>[coming soon]</td> -->
			</tr>
		<?php } ?>
		</table>
		
		<div class = "dotted" ></div>

		<?php 

	else:
		echo '<p style="font-weight: bold;">No ads are in the unassigned queue.</p>'; 
		
	
	endif; // end if rows were found

	echo '<p>If the issue for which you are submitting art does not appear above, please <a href="/artwork/submit/">click here</a> to upload artwork into your queue.</p>';
}

?>
