<div class = "section_title">Artwork Templates</div>
<!-- <div class = "dotted" ></div> -->
Please begin by reviewing our <a href="/images/2009_ad_specs.pdf" target="_blank">Ad Deadlines/Sizes</a> and <a  target="_blank" href="/templates/artwork/guidelines/ad_guidelines.pdf">Ad Guidelines</a>.<br />
<br />
<strong>Downloads</strong>
<li><a href="/templates/artwork/guidelines/samples.zip">Samples (Full Page, Half Page, and Third Page in PDF format)</a>
<li><a href="/templates/artwork/guidelines/illustrator.zip">Illustrator</a>
<li><a href="/templates/artwork/guidelines/indesign.zip">InDesign</a>
<li><a href="/templates/artwork/guidelines/photoshop.zip">Photoshop</a>
<li><a href="/templates/artwork/guidelines/presets.zip">PDF Presets</a>

<br />

