<?php 
if ($_GET['TID']) {
	$ticket = mysql_fetch_assoc(mysql_query("
	select jt.*, u.fname,u.lname,u.email, p.pub_name, ad_size_name as size, ad_position_name as position, i.iss_name as issue
	from job_tickets as jt
	left join users as u on u.userid = jt.assigned
	inner join orders_adsales as oa on oa.OAID = jt.OTID 
	inner join orders as o on o.OID = oa.OID 
	inner join pubs as p on p.id = oa.PubID
	inner join issues as i on i.id = oa.IssueID
	inner join ad_position as ap on ap.positionID = oa.PosID
	inner join ad_size as s on s.sizeID = oa.SizeID
	where jt.TID='".$_GET['TID']."'"));
	// echo $_GET['TID']; 
	$no_ticket = false;
	$submit_link_extra = '?TID='.$_GET['TID'];
	$header_text = $ticket['issue'].' ('.$ticket['size'] . ($ticket['position']!="None" ? $ticket['position'] : '').')';
	$path_middle = $_GET['TID'];
}

else {
	// [EJC 2009-03-12]
	// If no TID is passed, it's a file to be uploaded into the queue
	$no_ticket = true;
	$submit_link_extra = '';
	$header_text = 'Currently in the Queue: '.stripslashes($myuser['company_name']);
	$path_middle = 'CID-'.$myuser['CID'];
}

?>

<div class = "section_title">
	Artwork Submission History
</div>
<!-- <div class = "dotted" ></div> -->
<p><?php echo $header_text?></p>		

<div class = "icon" style = "float:left"><a href = "/artwork/"><img border=0 src = "/images/icons/arrow_left.gif" align="left"> Go Back </a>&nbsp;&nbsp;&nbsp;</div>
<div class = "icon"><a href = "/artwork/submit/<?php echo $submit_link_extra?>"><img border=0 src = "/images/icons/add.gif" align="left"> Submit Artwork </a></div>
<br>
<?php 

	if ($no_ticket) {
		$result = mysql_query("select f.*,c.contact_firstname, c.contact_lastname from job_clientfiles as f inner join contacts as c on c.IID = f.IID where f.CID='".$_GET['CID']."' order by date desc") or die(mysql_error());
	}
	else {
		$result = mysql_query("select f.*,c.contact_firstname, c.contact_lastname from job_clientfiles as f inner join contacts as c on c.IID = f.IID where f.TID='".$_GET['TID']."' order by date desc") or die(mysql_error());
	}

	if (mysql_num_rows($result)==0) { ?>
		No Submissions.
	<?php } else { ?>
	<table cellpadding="4" cellspacing="0" border="0" class = "activity_box" width="100%">
	<tr class = "row_title">
		<td>Filename</td>
		<td>Size</td>
		<td>Date</td>
		<td>By</td>
	</tr>

	<?php while ($row = mysql_fetch_assoc($result)) {
		$count++;?>
		<tr class = "row<?php echo $count%2;?>">
			<td><a href="http://www.myjuggernaut.com/cdata/944/client_files/<?php echo $path_middle?>/<?php echo $row['filename']?>" target="_blank"><?php echo $row['filename'];?></a></td>
			<td><?php echo filesize_format(filesize("/var/www/html/com944x/www/cdata/944/client_files/".$path_middle."/".$row['filename']));?></td>
			<td><?php echo date("m/d/y g:ia",strtotime($row['date']));?></td>
			<td><?php echo $row['contact_firstname']." ".$row['contact_lastname'];?></td>
		</tr>
	<?php } ?>
	</table>
<?php } ?>