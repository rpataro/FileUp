<?php
include('/var/www/html/com944x/public_html/includes/functions-only.php');

$approved_query = "SELECT o.probability, o.payment_backup, c.payment_backup_required AS company_payment_backup FROM 944x_944media.orders AS o LEFT JOIN 944x_944media.company AS c ON c.CID = o.CID WHERE o.OID = '".$_GET['oid']."'";
$approved_result = mysql_query($approved_query);
list ($orders_probability, $payment_backup, $company_payment_backup) = mysql_fetch_row($approved_result);

# Override the IO-level backup payment requirement if bypass is set at a company level
if ($company_payment_backup == 0) {
	$payment_backup = 0;
}

// Bypass billing if the total net is $0 (cash and barter)
if (get_order_total_net($_GET['oid']) == 0) {
	$bypass_billing = 1;
}

// Check if order has barter, in which case a special tab has to be loaded
if (get_order_total_barter($_GET['oid']) != 0) {
	$has_trade = 1;
}

function get_terms($x) {
	if ($x < 0) {
		$output = 'Pre-Payment';
	}
	elseif ($x == 0) {
		$output = 'Due upon receipt';
	}
	else {
		$output = 'Net '.$x.' days, invoice date';
	}
	
	return $output;
}

function get_past_ccs($OID) {
	$cc_query = "SELECT pc.id, pc.number AS number, pc.expiration_month, pc.expiration_year FROM 944x_944media.orders AS o LEFT JOIN 944x_944media.company AS c ON c.CID = o.CID LEFT JOIN 944x_944media.payby_card AS pc ON pc.CID = c.CID WHERE o.OID = '".$OID."' AND pc.id IS NOT NULL AND pc.active = 1 GROUP BY pc.number ORDER BY pc.id DESC";
	$cc_result = mysql_query($cc_query);

	$cc_array = array();
	while ($row = mysql_fetch_assoc($cc_result)) {
		if (strlen($row['expiration_year']) == 2) {
			$row['expiration_year'] = '20'.$row['expiration_year'];
		}
		
		if ($row['expiration_year'] > date('Y') || ($row['expiration_year'] == date('Y') && $row['expiration_month'] >= date('m'))) {
			$cc_array[$row['id']] = cc_last_4($row['number']).', Exp. '.$row['expiration_month'].'/'.$row['expiration_year'];
		}
	}
	
	return $cc_array;
}

function get_past_ach($OID) {
	$ach_query = "SELECT pa.id, pa.account FROM 944x_944media.orders AS o LEFT JOIN 944x_944media.company AS c ON c.CID = o.CID LEFT JOIN 944x_944media.payby_ach AS pa ON pa.CID = c.CID WHERE o.OID = '".$OID."' AND pa.id IS NOT NULL AND pa.active = 1 GROUP BY pa.account ORDER BY pa.id DESC";
	$ach_result = mysql_query($ach_query);

	$ach_array = array();
	while ($row = mysql_fetch_assoc($ach_result)) {
		$ach_array[$row['id']] = $row['account'];
	}
	
	return $ach_array;
}

function get_last_order_details($OID) {
	$last_query = "SELECT of.* FROM 944x_944media.orders AS o LEFT JOIN 944x_944media.company AS c ON c.CID = o.CID LEFT JOIN 944x_944media.orders AS op ON op.CID = c.CID LEFT JOIN 944x_944media.orders_forms AS of ON of.OID = op.OID WHERE o.OID = '".$OID."' AND op.OID != '".$OID."' AND of.id IS NOT NULL ORDER BY of.id DESC LIMIT 1";
	$last_result = mysql_query($last_query);
	$last_order = mysql_fetch_assoc($last_result);

	return $last_order;
}

function get_billing_other($billing_other_id) {
	$billing_query = "SELECT * FROM 944x_944media.billing_other WHERE id = '".$billing_other_id."'";
	$billing_result = mysql_query($billing_query);

	$row = mysql_fetch_assoc($billing_result);
	
	return $row;
}

// if ($_GET['oid'] == 53239) {
	$has_existing_cc = get_past_ccs($_GET['oid']);
	$has_existing_ach = get_past_ach($_GET['oid']);
	$last_order = get_last_order_details($_GET['oid']);
	if ($last_order['billing_other_id']) {
		$billing_other = get_billing_other($last_order['billing_other_id']);
	}
// }

?>
<p class="section_title">Insertion Orders</p>

<style type="text/css" media="screen">
	#orders_form, .orders_form_subsection {
		background-color: #EEEEEE;		
	}

	.orders_form_subsection {
		padding: 10px;
	}
	
	.payment_method {
		margin-left: 15px;
	}
	
	.form_nav a {
		color: #999;
	}

	label.payment, label.billing, label.terms {
/*		float: left;*/
		display: block;
/*		width: 18em;*/
	}
	
	label.payment {
		width: 18em;
	}

	label.billing {
		width: 10em;
	}

	label.terms {
		width: 12em;
	}

	.save_button {
		display: block;
		width: 16em;
		margin-top: 20px;
		margin-bottom: 10px;
		padding: 5px;
		border: 1px solid #A0A0A0;
/*		background-color: #F2F2F2;*/
/*		background-color: #336699;*/
/*		color: #000;*/
	}
</style>

<script type="text/javascript" charset="utf-8">
	types = new Array();
	types[0] = 'instructions';
	types[1] = 'payment';
	types[2] = 'billing';
	<?php if ($has_trade) :?>
		types[3] = 'trade';
	<?php endif; ?>
	types[4] = 'terms';
	types[5] = 'approved';

	bypass_billing = <?php echo ($bypass_billing) ? 'true' : 'false'?>;
	has_trade = <?php echo ($has_trade) ? 'true' : 'false'?>;
 	has_existing_cc = <?php echo ($has_existing_cc) ? 'true' : 'false'?>;
 	has_existing_ach = <?php echo ($has_existing_ach) ? 'true' : 'false'?>;

	cc_decline = false;

	cc_fields = new Array('payby_card_number', 'payby_card_expiration_month', 'payby_card_expiration_year', 'payby_card_code', 'payby_card_name', 'payby_card_address', 'payby_card_city', 'payby_card_state', 'payby_card_zip', 'payby_card_signature');
	cc_selects = new Array('payby_card_type');

	ach_fields = new Array('payby_ach_account', 'payby_ach_routing', 'payby_ach_bank_name', 'payby_ach_account_name');
	ach_selects = new Array('payby_ach_type_cs', 'payby_ach_type_bp');

	other_payment_fields = new Array('payment_signature', 'payment_tax_id');

	billing_fields = new Array('billing_email');
	billing_selects = new Array('billing_address_choice');
	
	terms_fields = new Array('terms_signature', 'terms_title', 'terms_date');

	function checkboxToggle(x) {
		var cb_value = $("input[name=payment_method]:checked").val(); 

		for (var i=1; i <= 3; i++) {
			$('#body_payment_method_' + i).hide();
		};

		if (x == 3) {
			if ('<?php echo $payment_backup?>' == '1') {
				$('#body_payment_method_1').show();
				$('#body_payment_method_2').show();
			}
		};
		
		$('#body_payment_method_' + x).show();
	}

	function getPaymentMethod() {
		var output = $("input[name=payment_method]:checked").val(); 
		return output;
	}

	function checkOtherPayment() {
		for (var i=0; i < other_payment_fields.length; i++) {
			if (document.getElementById(other_payment_fields[i]).value == '') {
				var missing_field = 'All payment details must be completed.';
			}
		};

		// Do a more thorough check of payment_tax_id to ensure that the length is 9 numbers
		var payment_tax_id = $('#payment_tax_id').val();
		var payment_tax_id_regexpd = payment_tax_id.replace (/\D/g, '');
		var length_payment_tax_id = payment_tax_id_regexpd.length;
		
		var payment_tax_id_check = payment_tax_id_regexpd.match(/[0]{9}|[1]{9}|[2]{9}|[3]{9}|[4]{9}|[5]{9}|[6]{9}|[7]{9}|[8]{9}|[9]{9}|(123456789)/);
		
		if ((length_payment_tax_id != 9 || payment_tax_id_check != null) && missing_field == undefined) {
			var missing_field = 'SSN/Tax Id Number is not valid.';
		}
		
		return missing_field;
	}

	function checkCC(alertNow) {
		var missing_cc_field = undefined;
		
		if (has_existing_cc == true) {
			var cc_choice = $('#cc_choice').val();
		}
		else {
			var cc_choice = 0;
		}
		
		if (has_existing_cc == false || cc_choice == 0) {
			for (var i=0; i < cc_fields.length; i++) {
				if (document.getElementById(cc_fields[i]).value == '') {
					// missing_cc_field = missing_cc_field + ', ' + cc_fields[i];
					missing_cc_field = 'All credit card information must be completed to continue.';
				}
			};

			for (var i=0; i < cc_selects.length; i++) {
				if (document.getElementById(cc_selects[i]).options[document.getElementById(cc_selects[i]).selectedIndex].value == 0) {
					missing_cc_field = 'All credit card information must be completed to continue.';
				}
			};

			// Check credit card type and corresponding length
			var payby_card_type = $('#payby_card_type').val();
		
			var payby_card_number = $('#payby_card_number').val();
			var payby_card_number_regexpd = payby_card_number.replace (/\D/g, '');
			var length_payby_card_number = payby_card_number_regexpd.length;

			var payby_card_number_check = payby_card_number_regexpd.match(/[0]{15,16}|[1]{15,16}|[2]{15,16}|[3]{15,16}|[4]{15,16}|[5]{15,16}|[6]{15,16}|[7]{15,16}|[8]{15,16}|[9]{15,16}|(1234123412341234)|(123412341234123)/);
		
			// if ((length_payment_tax_id != 9 || payment_tax_id_check != null) && missing_cc_field == undefined) {
				// missing_cc_field = 'SSN/Tax Id Number is not valid.';
			// }

			// AMEX Card must be 15 digits
			if (length_payby_card_number != 15 && payby_card_type == 8) {
				var cc_invalid = 1;
			}
			// All other credit cards must be 16 digits
			else if (length_payby_card_number != 16 && payby_card_type != 8) {
				var cc_invalid = 1;
			}
			else if (payby_card_number_check != null) {
				var cc_invalid = 1;
			}

			if (cc_invalid == 1 && missing_cc_field == undefined) {
				missing_cc_field = 'Credit card number is not valid.';
			}
			else if (length_payby_card_number > 0) {
				missing_cc_field = preAuthCC();
				
				if (alertNow) {
					alert(missing_cc_field);
				}
			}
		}
	
		// alert ('after: ' + missing_cc_field);
		return missing_cc_field;
	}

	function preAuthCC() {
		var output;
		var cc_response = $.ajax({
		      url: "/ajax/io.phpx",
		      type: "POST",
		      data: ({
				action: 'preauth-cc',
				OID: '<?php echo $_GET['oid']?>',
				CID: '<?php echo $myuser['CID']?>',
				IID: '<?php echo $myuser['IID']?>',
				ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
				<?php if ($has_existing_cc) : ?>
				payby_card_id: cc_choice,
				<?php endif; ?>
				number: document.getElementById("payby_card_number").value,
				expiration_month: document.getElementById("payby_card_expiration_month").value,
				expiration_year: document.getElementById("payby_card_expiration_year").value,
				code: document.getElementById("payby_card_code").value,
				name: document.getElementById("payby_card_name").value,
				address: document.getElementById("payby_card_address").value,
				city: document.getElementById("payby_card_city").value,
				state: document.getElementById("payby_card_state").value,
				zip: document.getElementById("payby_card_zip").value,
				signature: document.getElementById("payby_card_signature").value,
				type: document.getElementById("payby_card_type").options[document.getElementById("payby_card_type").selectedIndex].value
			  }),
		      dataType: "html",
		      async:false,
		      success: function(msg){
		         // alert(msg);
		      }
		   }
		).responseText;

		if (cc_response != 'approved') {
			output = "This credit card was declined when a $1 pre-authorization charge was made:\n\n'" + cc_response + "'\n\nPlease review your card details and correct any errors, or try another card.";
		}

		return output;
	}

	function checkACH() {
		var ach_choice = $('#ach_choice').val();
		
		if (has_existing_ach == false || ach_choice == 0) {
			for (var i=0; i < ach_fields.length; i++) {
				if (document.getElementById(ach_fields[i]).value == '') {
					// var missing_field = missing_field + ', ' + ach_fields[i];
					var missing_field = 'All ACH information must be completed to continue.';
				}
			};	

			for (var i=0; i < ach_selects.length; i++) {
				if (document.getElementById(ach_selects[i]).options[document.getElementById(ach_selects[i]).selectedIndex].value == 0) {
					// var missing_field = missing_field + ', ' + ach_selects[i];
					var missing_field = 'All ACH information must be completed to continue.';
				}
			};	

			var payby_ach_routing = $('#payby_ach_routing').val();
			var payby_ach_routing_regexpd = payby_ach_routing.replace (/\D/g, '');
			var length_payby_ach_routing = payby_ach_routing_regexpd.length;

			var payby_ach_routing_check = payby_ach_routing_regexpd.match(/[0]{9}|[1]{9}|[2]{9}|[3]{9}|[4]{9}|[5]{9}|[6]{9}|[7]{9}|[8]{9}|[9]{9}|(123456789)/);

			if (missing_field == undefined && (length_payby_ach_routing != 9 || payby_ach_routing_check != null)) {
				var missing_field = 'Invalid ACH Routing Number.';
			}

			return missing_field;
		}
	}

	function checkTrade() {
		for (var i=1; i <= 6; i++) {
			// alert($('#trade_cb_' + i).val());
			if ($('#trade_cb_' + i).val() != 'on') {
				var missing_field = 'All trade terms must be agreed to in order to continue.';
			}
		};	

		return missing_field;	
	}

	function checkBilling() {
		for (var i=0; i < billing_fields.length; i++) {
			if (document.getElementById(billing_fields[i]).value == '') {
				// var missing_field = missing_field + ', ' + billing_fields[i];
				var missing_field = 'All billing information must be completed to continue.';
			}
		};

		for (var i=0; i < billing_selects.length; i++) {
			if (document.getElementById(billing_selects[i]).options[document.getElementById(billing_selects[i]).selectedIndex].value == 0) {
				var missing_field = 'All billing information must be completed to continue.';
			}
		};

		return missing_field;
	}

	function checkTerms() {
		for (var i=0; i < terms_fields.length; i++) {
			if (document.getElementById(terms_fields[i]).value == '') {
				// var missing_field = missing_field + ', ' + terms_fields[i];
				var missing_field = 'Signature, title and date are required in order to finalize the IO approval process.';
			}
		};

		return missing_field;
	}
		
	function checkPayment() {
		var item_chosen = $("input[name=payment_method]:checked").val(); 
		var output;

		if (item_chosen == 1) {
			output = checkCC(0);
		}

		if (item_chosen == 2) {
			output = checkACH();
		}

		if (item_chosen == 3) {
			if ('<?php echo $payment_backup?>' == '1') {
				var cc_msg;

				var ach_msg = checkACH();
				
				if (ach_msg != undefined) {
					cc_msg = checkCC(1);
				}
			}

			if (cc_msg != undefined && ach_msg != undefined) {
				output = 'A valid back-up payment method is required when paying by check. Please complete either the Credit Card or ACH section in its entirety.';
			}
		}

		if (output == undefined) {
			output = checkOtherPayment();
		}

		if (item_chosen == undefined) {
			output = 'You need to select a payment method before continuing.';
		}

		return output;
	}

	function fullyApprovedCheck() {
		$('#orders_form_approved').html('<h2>Checking Insertion Order Status.. Please Wait</h2><p><img src="/images/ajax-loader2.gif" width="16" height"16"></p>');

		$('#orders_form_approved').load("/ajax/io.phpx", {
		// $.post("/ajax/io.phpx", {
			action: 'fully-approved-check',
			OID: '<?php echo $_GET['oid']?>',
			CID: '<?php echo $myuser['CID']?>',
			IID: '<?php echo $myuser['IID']?>',
			ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>'
		}, function() {
			// alert('Done saving payments');
		});			
	}

	function loadForm(type) {
		// var types = new Array();
		if (type == 'approved') {
			fullyApprovedCheck();
		}

		if ('<?php echo $orders_probability?>' >= '98' && type != 'approved') {
			alert('No changes can be made to this IO as it has already been fully approved.');
		}
		else {
			for (x in types) {
				$('#orders_form_' + types[x]).slideUp('slow');
				$('#' + types[x] + '_nav').css('color', '#999');
			}

			$('#orders_form_' + type).slideDown('slow');
			$('#' + type + '_nav').css('color', '#000');
		}
	}
	
	function saveForm(x) {
		if (x == 1 && bypass_billing == false) {
			var payment = checkPayment();
			if (payment == undefined) {
				savePayment();
			}
		}

		if (x == 2 && bypass_billing == false) {
			var billing = checkBilling();
			if (billing == undefined) {
				saveBilling();
			}
		}

		if (x == 3 && bypass_billing == false) {
			var trade = checkTrade();
			if (trade == undefined) {
//				saveTrade();
			}
		}
		
		// If user is trying to approve final terms, do all checks..
		if (x == 4) {
			// If no net associated, skip the first 2 steps
			if (bypass_billing == false) {
				var payment = checkPayment();
				var billing = checkBilling();
			}
			
			if (has_trade == true) {
				var trade = checkTrade();
			}
			
			var terms = checkTerms();
			
			if (payment == undefined && billing == undefined && terms == undefined) {
				savePayment();
				saveBilling();

				// Save terms (will also update the final approval tab now the IO has been completed)
				saveTerms();
			}
		}

		if (payment != undefined) {
			alert(payment);
			var stop_now = 1;
		}

		if (billing != undefined) {
			alert(billing);
			var stop_now = 1;
		}

		if (trade != undefined && has_trade == true) {
			alert(trade);
			var stop_now = 1;
		}

		if (terms != undefined) {
			alert(terms);
			var stop_now = 1;
		}

		if (stop_now == undefined) {
			$('#' + types[x] + '_nav').css('color', '#999');
			$('#orders_form_' + types[x]).slideUp('slow');

			// If no net associated, skip the first 2 steps
			if (bypass_billing == true && x < 3) {
				x = 2;
			}

			if (has_trade == false && x == 2) {
				// skip trade if IO doesn't have any barter and we're on stage 2
				x = 3;
			}

			$('#' + types[x + 1] + '_nav').css('color', '#000');
			$('#orders_form_' + types[x + 1]).slideDown('slow');
		}
	}

	function newCC() {
		value = $('#cc_choice').val();
		// var control = document.getElementById("cc_choice");
		// var value = control.options[control.selectedIndex].value;
		
		if (value == 0) {
			$("#new_cc").slideDown('slow');
		}
		else {
			$("#new_cc").slideUp('slow');
		}
	}

	function newACH() {
		value = $('#ach_choice').val();
		
		if (value == 0) {
			$("#new_ach").slideDown('slow');
		}
		else {
			$("#new_ach").slideUp('slow');
		}
	}

	
	function billingAddress() {
		var control = document.getElementById("billing_address_choice");
		var value = control.options[control.selectedIndex].value;
		
		if (value == 3) {
			$("#billing_other").slideDown('slow');
		}
		else {
			$("#billing_other").slideUp('slow');
		}
	}
	
	function savePayment() {
		// $('#test').load("/ajax/io.phpx", {
		$.post("/ajax/io.phpx", {
			action: 'save-payment-cc',
			OID: '<?php echo $_GET['oid']?>',
			CID: '<?php echo $myuser['CID']?>',
			IID: '<?php echo $myuser['IID']?>',
			ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
			<?php if ($has_existing_cc) : ?>
			payby_card_id: $("#cc_choice").val(),
			<?php endif; ?>
			number: document.getElementById("payby_card_number").value,
			expiration_month: document.getElementById("payby_card_expiration_month").value,
			expiration_year: document.getElementById("payby_card_expiration_year").value,
			code: document.getElementById("payby_card_code").value,
			name: document.getElementById("payby_card_name").value,
			address: document.getElementById("payby_card_address").value,
			city: document.getElementById("payby_card_city").value,
			state: document.getElementById("payby_card_state").value,
			zip: document.getElementById("payby_card_zip").value,
			signature: document.getElementById("payby_card_signature").value,
			type: document.getElementById("payby_card_type").options[document.getElementById("payby_card_type").selectedIndex].value
		}, function() {
			$.post("/ajax/io.phpx", {
				action: 'save-payment-ach',
				OID: '<?php echo $_GET['oid']?>',
				CID: '<?php echo $myuser['CID']?>',
				IID: '<?php echo $myuser['IID']?>',
				ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
				<?php if ($has_existing_ach) : ?>
				payby_ach_id: $("#ach_choice").val(),
				<?php endif; ?>
				account: document.getElementById("payby_ach_account").value,
				routing: document.getElementById("payby_ach_routing").value,
				bank_name: document.getElementById("payby_ach_bank_name").value,
				account_name: document.getElementById("payby_ach_account_name").value,
				type_cs: document.getElementById("payby_ach_type_cs").options[document.getElementById("payby_ach_type_cs").selectedIndex].value,
				type_bp: document.getElementById("payby_ach_type_bp").options[document.getElementById("payby_ach_type_bp").selectedIndex].value
			}, function() {
				$.post("/ajax/io.phpx", {
					action: 'save-payment-other',
					OID: '<?php echo $_GET['oid']?>',
					CID: '<?php echo $myuser['CID']?>',
					IID: '<?php echo $myuser['IID']?>',
					ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
					payment_signature: $('#payment_signature').val(),
					payment_tax_id: $('#payment_tax_id').val(),
					payment_method: getPaymentMethod()
				}, function() {
					// alert('Done saving other');
				});
				// alert('Done saving ach');
			});
			// alert('Done saving cc');
		});
		
		// var payment_method_value = getPaymentMethod();
		// alert(payment_method_value);
	
	}
	
	function saveBilling() {
		// billing_address_choice
		var billing_address_choice_value = document.getElementById("billing_address_choice").options[document.getElementById("billing_address_choice").selectedIndex].value;
		var billing_printed_value = document.getElementById("billing_printed").options[document.getElementById("billing_printed").selectedIndex].value;
		
		$.post("/ajax/io.phpx", {
			action: 'save-billing',
			OID: '<?php echo $_GET['oid']?>',
			CID: '<?php echo $myuser['CID']?>',
			IID: '<?php echo $myuser['IID']?>',
			ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
			billing_email: document.getElementById("billing_email").value,
			billing_terms: $('#billing_terms').val(),
			billing_po: document.getElementById("billing_po").value,
			billing_printed: billing_printed_value,
			billing_address_choice: billing_address_choice_value
		}, function() {
			// alert('Done saving payments');
		});
		
		if (billing_address_choice_value == 3) {
			$.post("/ajax/io.phpx", {
				action: 'save-billing-other',
				OID: '<?php echo $_GET['oid']?>',
				CID: '<?php echo $myuser['CID']?>',
				IID: '<?php echo $myuser['IID']?>',
				ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
				company: document.getElementById("billing_other_company").value,
				contact: document.getElementById("billing_other_contact").value,
				address: document.getElementById("billing_other_address").value,
				city: document.getElementById("billing_other_city").value,
				state: document.getElementById("billing_other_state").value,
				zip: document.getElementById("billing_other_zip").value
			}, function() {
				// alert('Done saving payments');
			});			
		}
	}
	
	function saveTerms() {
		// Display a saving message while the file saves in the background..
		$('#orders_form_approved').html('<h2>Saving Insertion Order.. Please Wait</h2><p><img src="/images/ajax-loader2.gif" width="16" height"16"></p>');

		$('#orders_form_approved').load("/ajax/io.phpx", {
			action: 'save-terms',
			OID: '<?php echo $_GET['oid']?>',
			CID: '<?php echo $myuser['CID']?>',
			IID: '<?php echo $myuser['IID']?>',
			ip_address: '<?php echo $_SERVER['HTTP_X_FORWARDED_FOR']?>',
			terms_signature: document.getElementById("terms_signature").value,
			terms_title: document.getElementById("terms_title").value,
			terms_date: document.getElementById("terms_date").value,
			notes: document.getElementById("notes").value
		}, function() {
			fullyApprovedCheck();
		});
	}
	
</script>

<?php 
// Temporarily set CID to 4043 for testing
if (date('Y-m-d') <= '2009-05-15' && $myuser['CID'] == 34387) {
	$myuser['CID'] = 4043;
}

if ($_GET['oid']) :

	echo display_io_web($_GET['oid']);
	
	################ Set Up PHP Variables ##################

	// Need to come up with a way to show included events/marketing services, and their values..
	$event_included = '';
	$event_value = '';

	// If an approval form has not yet been filled out for this IO, get the user to do so now
	if ($order['orders_forms_id'] == 0) :
		?>
		<div id="orders_form">
			<p align="center">

				<span class="form_nav" ><a href="javascript:loadForm('instructions');" id="instructions_nav" >Instructions</a></span> 
				&gt; <span class="form_nav" ><a href="javascript:loadForm('payment');" id="payment_nav" >Payment Options</a></span> 
				&gt; <span class="form_nav" ><a href="javascript:loadForm('billing');" id="billing_nav" >Billing Details</a></span> 
				<?php if ($has_trade) :?>
				&gt; <span class="form_nav" ><a href="javascript:loadForm('trade');" id="trade_nav" >Trade</a></span>
				<?php endif; ?>
				&gt; <span class="form_nav" ><a href="javascript:loadForm('terms');" id="terms_nav" >Terms and Conditions</a></span>
				&gt; <span class="form_nav" ><a href="javascript:loadForm('approved');" id="approved_nav" >Final IO Approval</a></span>
			</p>

			<div id="orders_form_instructions" class="orders_form_subsection" style="display: none;">
				<h2>IO Approval Instructions</h2>
				
				<p>
					944 is committed to going green and helping you get through all the bureaucracy quickly and easily.
				</p>
				
				<p>
					You can now complete your IO online in less time than it takes to fax in a hard copy.
				</p>

				<?php 
				if ($bypass_billing) :
				?>
					<p>
						NOTE: Because this order has a net balance of $0, you are not required to complete any payment or billing options, you only need to agree to the terms and conditions.
					</p>
				<?php 
				endif;
				?>
							
				<div class="cleaner"></div>
				<a href="javascript:saveForm(0);" class="save_button">Get Started Now &gt;</a>
				
			</div>

			<div id="orders_form_payment" class="orders_form_subsection" style="display: none;">
				<h2>Payment Options Form</h2>

				<h3><input type="radio" name="payment_method" value="1" id="cb_payment_method_1" onclick="checkboxToggle(1)" checked><label for="cb_payment_method_1">Credit Card</label></h3>
				<div id="body_payment_method_1" class="payment_method">
					<p>
						By selecting payment by CREDIT CARD, I agree to the AUTO-PAY Terms. I understand that my Credit Card will be automatically charged on the 15th of each 
						month prior to the ad running. I also understand that payment is considered auto-pay each month for the length of the contract unless I notify 944 Media LLC in writing 
						with a change in preference 30 days in advance.
					</p>

					<?php if ($has_existing_cc) : ?>
						<select name="cc_choice" id="cc_choice" onchange="newCC();">
							<?php 
							foreach ($has_existing_cc as $id => $value) {
								?>
								<option value="<?php echo $id?>">Use Credit Card on File Ending In <?php echo $value?></option>
								<?php 
							}
							?>
							<option value="0">Enter New Credit Card Details Below:</option>
						</select>
						<p/>
					<?php endif; ?>

					<div id="new_cc" style="display: <?php echo ($has_existing_cc) ? 'none' : 'block'?>;">
						<div id="security_code" style="float: right; display: none;">
							<img src="/images/securecode.gif" />
						</div>
					
						<label class="payment">Credit Card Type:</label>
						<select name="type" id="payby_card_type">
							<option value="0">-- Choose One --</option>
							<?php 
							$cc_type_query = "SELECT * FROM payment_method WHERE type = 'cc'";
							$cc_type_result = mysql_query($cc_type_query);
							while ($row = mysql_fetch_assoc($cc_type_result)) {
								echo '<option value="'.$row['mid'].'">'.stripslashes($row['name']).'</option>';
							}
							?>
						</select>

						<label class="payment">Credit Card Number:</label>
						<input type="text" name="number" id="payby_card_number" value="<?php echo $payby_card['number']?>">

						<label class="payment">Expiration Date:</label>
						<input type="text" name="expiration_month" id="payby_card_expiration_month" value="<?php echo $payby_card['expiration_month']?>" size="2" maxlength="2">/<input type="text" name="expiration_year" id="payby_card_expiration_year" value="<?php echo $payby_card['expiration_year']?>" size="4" maxlength="4">

						<label class="payment">Card Security Code:</label>
						<input type="text" name="code" id="payby_card_code"bl value="<?php echo $payby_card['code']?>" size="5">

						<label class="payment">Card Holder Name:</label>
						<input type="text" name="name" id="payby_card_name" value="<?php echo $payby_card['name']?>">

						<label class="payment">Card Billing Address:</label>
						<input type="text" name="address" id="payby_card_address" value="<?php echo $payby_card['address']?>">

						<label class="payment">City:</label>
						<input type="text" name="city" id="payby_card_city" value="<?php echo $payby_card['city']?>">

						<label class="payment">State:</label>
						<input type="text" name="state" id="payby_card_state" value="<?php echo $payby_card['state']?>">

						<label class="payment">Zip:</label>
						<input type="text" name="zip" id="payby_card_zip" value="<?php echo $payby_card['zip']?>">

						<label class="payment">Digital Signature:</label>
						<input type="text" name="signature" id="payby_card_signature" value="<?php echo $payby_card['signature']?>">
					</div>
				</div>

				<h3><input type="radio" name="payment_method" value="2" id="cb_payment_method_2" onclick="checkboxToggle(2)"><label for="cb_payment_method_2">ACH</label></h3>
				<div id="body_payment_method_2" class="payment_method" style="display: none;">
					<p>
						By selecting payment by ACH, I agree to allow 944 Media LLC to retrieve payment from my bank account on a monthly basis as is outlined in the AUTO-PAY Terms. 
						I understand that my bank account will automatically be debited on the 15th of each month prior to the ad running. I also understand that payment is considered auto-pay 
						each month for the length of the contract unless I notify 944 Media LLC in writing with a change in preference 30 days in advance.
					</p>

					<?php if ($has_existing_ach) : ?>
						<select name="ach_choice" id="ach_choice" onchange="newACH();">
							<?php 
							foreach ($has_existing_ach as $id => $value) {
								?>
								<option value="<?php echo $id?>">Use ACH Details on File (Account #<?php echo $value?>)</option>
								<?php 
							}
							?>
							<option value="0">Enter New ACH Details Below:</option>
						</select>
						<p/>
					<?php endif; ?>

					<div id="new_ach" style="display: <?php echo ($has_existing_ach) ? 'none' : 'block'?>;">
						<div id="check_image" style="float: right">
							<img src="/images/aba_routing.gif" width="440" height="250" />
						</div>
					
						<label class="payment">Account Number:</label>
						<input type="text" name="account" id="payby_ach_account" value="<?php echo $payby_ach['account']?>">

						<label class="payment">Routing Number (9 digits):</label>
						<input type="text" name="routing" id="payby_ach_routing" value="<?php echo $payby_ach['routing']?>">

						<label class="payment">Type of Account (checking or savings):</label>
						<select name="type_cs" id="payby_ach_type_cs">
							<option value="0">-- Choose One --</option>
							<option value="1">Checking</option>
							<option value="2">Savings</option>
						</select>

						<label class="payment">Type of Account (business or personal):</label>
						<select name="type_bp" id="payby_ach_type_bp">
							<option value="0">-- Choose One --</option>
							<option value="1">Business</option>
							<option value="2">Personal</option>
						</select>

						<label class="payment">Bank Name:</label>
						<input type="text" name="bank_name" id="payby_ach_bank_name" value="<?php echo $payby_ach['bank_name']?>">

						<label class="payment">Name on Account:</label>
						<input type="text" name="account_name" id="payby_ach_account_name" value="<?php echo $payby_ach['account_name']?>">
					</div>
				</div>
				<div class="cleaner"></div>

				<h3><input type="radio" name="payment_method" value="3" id="cb_payment_method_3" onclick="checkboxToggle(3)"><label for="cb_payment_method_3">Check</label></h3>
				<div id="body_payment_method_3" class="payment_method" style="display: none;">
					<p>
						By selecting payment by check, I agree to ensure that my payment is received prior to my ad going to print on the 1st day of each month. 
						Customers paying by Check must provide an alternate <b>back-up form of payment</b> as a guarantee. Should the Check NOT arrive 3 days prior to the 1st day of each month, 
						I understand that 944 Media LLC will charge my alternate payment guarantee (unless previous arrangements have been made with 944 Media’s Account Receivable Dept.)</p>
					<p>
						Checks can be mailed to:
					</p>

					<?php if ($ct['associated_company'] == 2) { ?>
						<p style="font-weight: bold;">
							Six Degrees Media, LLC<br/>
							Dept 1084<br/>
							PO Box 29338<br/>
							Phoenix, AZ  85038-9338<br/>
					<?php } else {?>
						<p style="font-weight: bold;">
							944 Media, LLC<br/>
							Dept 2082<br/>
							PO Box 29675<br/>
							Phoenix, AZ  85038-9675<br/>
						</p>
					<?php } ?>
					
					<p>
						You may also send payment via ACH to:
					</p>
					
					<p style="font-weight: bold;">
						Bank Name: Chase Bank<br/>
						Account Name: 944 Media LLC<br/>
						Account Number: 894224385<br/>
						Routing or ABA Number: 322271627
					</p>
				</div>

				<hr/>
				<p style="font-weight: bold;">
					Personal Guarantee - the Guarantor/Advertiser <b><?php echo $myuser['test']?></b> has selected one of the payment options above and guarantees prompt payment of all sums due. The Guarantor consents to 944 
					that they may obtain payment through one of the payment options selected above. The Guarantor further agrees that in the event of payment default, 944 shall have the right to pursue all legal 
					remedies again Guarantor.
				</p>

				<p style="font-weight: bold;">
					Guarantor/Advertiser Digital Signature: 
					<input type="text" name="payment_signature" id="payment_signature" value="<?php echo $last_order['payment_signature']?>">

					SSN/Tax ID Number: 
					<input type="text" name="payment_tax_id" id="payment_tax_id" value="<?php echo $last_order['payment_tax_id']?>">
				</p>

				<div class="cleaner"></div>
				<a href="javascript:saveForm(1);" class="save_button">Save and Move On To Next Step &gt;</a>
				
			</div>

			<div id="orders_form_billing" class="orders_form_subsection" style="display: none;">
				<h2>Billing Details</h2>
				
				<p>
					Standard payment terms are <b>PRE-PAYMENT</b> unless granted extended terms by our Corporate Office. To apply for extended terms, please ask your 944 Representative for a credit application
					and fax the credit application to our Corporate Office at 866-825-8145.
				</p>
				
				<h3>
					1. Payment Terms
				</h3>
				
				<p>
					<?php echo get_terms($myuser['company_payment'])?>
					<input type="hidden" name="billing_terms" id="billing_terms" value="<?php echo $myuser['company_payment']?>">
				</p>
				
				<h3>
					2. Confirm Billing Contact Address:
					<select name="billing_address_choice" id="billing_address_choice" onchange="billingAddress();">
						<option value="0">-- Choose One --</option>
						<option value="1" <?php echo ($last_order['billing_address_choice'] == 1) ? 'selected' : ''?>>Advertiser address as noted above is the correct billing contact address.</option>
						<option value="2" <?php echo ($last_order['billing_address_choice'] == 2) ? 'selected' : ''?>>Media Agency address as noted above is the correct billing contact address.</option>
						<option value="3" <?php echo ($last_order['billing_address_choice'] == 3) ? 'selected' : ''?>>Address entered below is the correct billing contact address:</option>
					</select>
				</h3>

				<div id="billing_other" style="display: <?php echo ($last_order['billing_address_choice'] == 3) ? 'block' : 'none' ?>;">
					<div class="cleaner"></div>
					<label class="billing">Company Name</label>
					<input type="text" name="billing_other_company" id="billing_other_company" value="<?php echo $billing_other['company']?>">
					
					<label class="billing">Contact</label>
					<input type="text" name="billing_other_contact" id="billing_other_contact" value="<?php echo $billing_other['contact']?>">

					<label class="billing">Address</label>
					<input type="text" name="billing_other_address" id="billing_other_address" value="<?php echo $billing_other['address']?>">

					<label class="billing">City</label>
					<input type="text" name="billing_other_city" id="billing_other_city" value="<?php echo $billing_other['city']?>">

					<label class="billing">State</label>
					<input type="text" name="billing_other_state" id="billing_other_state" value="<?php echo $billing_other['state']?>">

					<label class="billing">Zip</label>
					<input type="text" name="billing_other_zip" id="billing_other_zip" value="<?php echo $billing_other['zip']?>">
				</div>

				<h3>
					3. Event and/or marketing service included in this agreement?
				</h3>

				<input type="hidden" name="billing_event" id="billing_event" value="<?php echo $event_included?>">

				<?php 
				if ($event_included) {
				?>
					<p>
						Value: $<?php echo number_format($event_value, 2)?>
					</p>
					
					<p>
						In the event of early termination of this agreement, any event/marketing expenses incurred will be due to 944 at non-discounted rate.
					</p>
					
					<p>
						Advertiser Initials <input type="text" name="billing_event_initials" id="billing_event_initials"> 
						<br/>
						Date <input type="text" name="billing_event_initials_date" id="billing_event_initials_date" value="<?php echo date('m/d/Y');?>"> 
					</p>
				<?php 
				}
				else {
					echo '<p>No</p>';
				}
				?>

				<h3>
					4. Receive Electronic Tearsheets and Invoices
				</h3>
				
				Email Address
				<input type="text" name="billing_email" id="billing_email" value="<?php echo stripslashes($myuser['contact_email'])?>"> 
				<br/>
				Do you require a printed copy?  
				<select name="billing_printed" id="billing_printed">
					<option value="0" <?php echo ($last_order['billing_printed'] == 0) ? 'selected' : ''?>>No</option>
					<option value="1" <?php echo ($last_order['billing_printed'] == 1 && $last_order['id'] > 1081) ? 'selected' : ''?>>Yes</option>
				</select>
				
				<h3>
					5. Purchase Orders
				</h3>
				
				If a PO is required, enter the PO # here and provide a copy to your 944 Representative: 
				<input type="text" name="billing_po" id="billing_po">

				<div class="cleaner"></div>
				<a href="javascript:saveForm(2);" class="save_button">Save and Move On To Next Step &gt;</a>			
			</div>

<!-- Trade Section -->
			<div id="orders_form_trade" class="orders_form_subsection" style="display: none;">
				<h2>Trade</h2>

				<p>
					As trade is included as part of this agreement, you must agree to the following terms and conditions:
				</p>

				<input type="checkbox" name="trade_cb_1" id="trade_cb_1"> Trade/barter must be delivered upfront before 944 provides services (ad, event, marketing, etc.).
				<br/>
				<input type="checkbox" name="trade_cb_2" id="trade_cb_2"> Trade needs to be provided in gift cards or certificates, versus on account.
				<br/>
				<input type="checkbox" name="trade_cb_3" id="trade_cb_3"> Trade must clearly state that there are no expiration or black-out dates.
				<br/>
				<input type="checkbox" name="trade_cb_4" id="trade_cb_4"> The total sum of the account trade must be noted in the first month of the Agreement.
				<br/>
				<input type="checkbox" name="trade_cb_5" id="trade_cb_5"> In the event the Advertiser fails to issue trade in full as agreed, 944 will bill for the amount owed pursuant to this Agreement.
				<br/>
				<input type="checkbox" name="trade_cb_6" id="trade_cb_6"> Trade must be mailed to our Corporate address below or provided to the 944 Representative at the time of signing the Agreement (<b>$<?php echo number_format(get_order_total_barter($_GET['oid']), 2)?> total</b>):
				<blockquote>
					<b>944 Media, LLC</b><br/>
					Attn: Trade Accounting<br/>
					627 La Peer Drive<br/>
					West Hollywood, CA  90069
				</blockquote>

				<div class="cleaner"></div>
				<a href="javascript:saveForm(3);" class="save_button">Save and Move On To Next Step &gt;</a>
			</div>


			<div id="orders_form_terms" class="orders_form_subsection" style="display: none;">
				<h2>944 Media, LLC - Terms and Conditions</h2>

				<ol>
					<li>
						Invoices for published advertising and/or services are payable in advance of print until credit is established. In the event Advertiser fails to make payments as agreed, Advertiser waives his rights to any and all discounts to which he may have been entitled and any short rate or service charges must be paid immediately. Publisher's acceptance of payments by Advertiser for billed accounts shall not be construed as a waiver of Publisher's right to collect additional sums due, including sums due as a result of "short-rating" the Advertiser upon Advertiser's non performance of this Agreement. Any account outstanding will be assessed a finance charge if payment is not received in accordance with terms. Late accounts will initially be assessed a late charge at 5.0% of the amount due and thereafter a 1.5% monthly finance charge not to exceed 18% per annum. If any action must be instituted for collection or for breach of any of the terms of this contract, Advertiser and/or Agency promise to pay collection costs, reasonable attorney's fees and court costs.
					</li>
					
					<li>
						Any art work or other services required by Advertiser and/or Agency will be charged two-hundred fifty dollars an hour ($250/hour), unless other arrangements have been made. Upon request, the Publisher will endeavor to show the Advertiser a proof of the display ad in advance of publication.
					</li>
					
					<li>
						A late fee penalty of three hundred dollars ($300) will be assessed for any artwork and/or copy received after the closing date for contracts in affect at the closing 
						date, unless other arrangements have been made. 
					</li>
					
					<li>
						CANCELLATION POLICY - Any advertising contract may be canceled via written notice up to 30 days before the space reservation closing date of issues. Please ask 
						you Account Executive for deadline/closing dates of issues. Any discounts given, but not fulfilled, will be nullified, and will result in a short-rate charge which shall be 
						due and payable immediately. The short-rate is the readjustment of the rate on past and subsequent insertions to conform to the actual space used at current rates. 
						Cover positions are not cancelable. There will be additional reasonable charges for cancellation if Publisher had assumed costs for design, or if there is value added 
						to the contract such as inclusion in events, promotions, or other such items.   
					</li>	
					
					<li>
						The applicable insertion order, together with 944 MEDIA, LLC's ("Publisher") then current rate card and the Terms and conditions, which are hereby incorporated herein, should be referred to 
						collectively as "the Agreement."  
					</li>
					
					<li>
						The Advertiser and/or its Agency, jointly and severally, represent that any advertising submitted complies with all applicable laws and regulations and does not violate the rights of, and is 
						not harmful to, any person, corporation or other entity and is true and accurate. The Advertiser and/or its Agency, each agrees jointly and severally to indemnify and save harmless Publisher, 
						and its employees and representatives, officers, agents, shareholders, and attorney's against all liability, loss, damage, and expense of any nature, including attorneys' fees arising out of any 
						claims for libel, invasion of privacy, copyright or trademark infringement and/or any claims or suit that may arise out of the copying, printing, publishing, distribution or transmission of such 
						advertisement or out of the performance of this agreement.  
					</li>
					
					<li>
						Advertiser and/or its Agency agree to give notice in writing immediately upon a change in status, if the Advertiser should cease to have any such rights in the advertising submitted. Advertiser 
						assumes sole responsibility for the protection of its copyright in any writing, pictorial illustration, design, map, photograph or combination thereof included in its advertising.
					</li>
					
					<li>
						A trademark or trade name caption is to be published with the understanding that the people claiming to be authorized to use the marks are in fact so authorized. Unless the Publisher is 
						otherwise directed in writing by the owner of the trademark or trade name to the contrary, Publisher will continue to assume those claiming to be authorized are in fact so authorized.
					</li>
					
					<li>
						In the event an order is placed by an Agency on behalf of the Advertiser, such Agency warrants and represents that it has full right and authority to place such order on behalf of the Advertiser 
						and that all legal obligations arising out of the placement of the advertisement will be binding on both the Advertiser and/or the Agency.
					</li>
					
					<li>
						Orders for advertising containing restrictions or specifying positions, facings, editorial adjacencies or other requirements may be accepted and inserted but such restrictions or specifications 
						will be treated as requests, not guaranteed, and shall be a Publisher's sole discretion.
					</li>
					
					<li>
						Advertisements that simulate editorial content must be clearly defined and labeled "ADVERTISEMENT' and Publisher may, in its discretion, so label such copy.
					</li>
					
					<li>
						Publisher reserves the right, at its absolute discretion and at any time, to reject or delete any advertising or other copy or materials, whether or not the same has already been acknowledged 
						and/or previously published, including but not limited to for reasons relating to the contents of the advertisement or any technology associated with the advertisement. The rejection of copy by 
						Publisher shall require Advertiser and/or Agency to supply new copy acceptable to Publisher.
					</li>
					
					<li>
						When change of copy is not received by the closing date, copy run in previous issues may be inserted.  
					</li>
					
					<li>
						If errors occur in advertisements produced by Publisher, Advertiser must notify publisher in writing within 15 days following initial publication and absent such notice, Publisher assumes no 
						liability. Publisher's sole liability for any error shall be limited to the actual cost incurred to print the space occupies by the erroneous advertisement. Such amount shall be extended as a credit 
						as the parties agree it would be impracticable and extremely difficult to determine actual damages for erroneous advertisements, and the foregoing is an agreement for liquidated damages. 
						Advertiser shall be allowed to use credit for such actual cost to offset cost incurred for advertisements run in next issue. No credit is allowed and Publisher assumes no liability for any errors 
						contained in Advertiser's proof, or errors of Publisher that do not materially affect the value of the advertisement.  
					</li>
					
					<li>
						The Publisher is not liable for failure to publish or circulate any part of any issues because of act of God, strikes, work stoppages, and national emergencies, other circumstances beyond the 
						control of the Publisher or the publication or other events caused by force majeure. 
					</li>
					
					<li>
						Rates are subject to change upon 30 days written notice from Publisher. The Advertiser and/or Agency agree to be bound by such rates but upon giving 30 days written notice to Publisher, they 
						may elect not to place further advertisements after the effective date of the increase. If no space is used after the effective date of the increase, no short rate will be charged.  
					</li>
					
					<li>
						Publisher reserves the right to hold Advertiser and its agency jointly, severally, and personally liable for such moneys as are due and payable to the publisher under this agreement. The 
						Advertiser authorizes the publisher to tender bills to the Agency and by doing so will not impair or limit the joint and several liabilities of the Advertiser and Agency. Payment by the Advertiser 
						to the Agency shall not discharge the Advertiser's liability to the Publisher. The rights of Publisher shall in no way be affected by any dispute or claim between the Advertiser and the Agency.  
					</li>
					
					<li>
						Publisher in its sole and absolute discretion shall be entitled to offset any amounts due and payable to Advertiser and/or any of its affiliates, against amount due and payable to Publisher under 
						the terms of this Agreement.  
					</li>
					
					<li>
						All contracts with any part of the purchase price payable in trade, exchange advertising, or barter of any type are subject to review and approval. If approved, Publisher will, from time to time, 
						send Advertiser a statement of account listing the ending balance on the prior statement and the new ending balance. Advertiser must notify Publisher of any disagreement with the new ending 
						balance in writing within 45 days of the date of the statement. Advertiser promises that failure to so notify Publisher constitutes acceptance of the statement.  
					</li>
					
					<li>
						Advertiser and/or Agency recognize that the copyright in any advertisements created by Publisher is owned by Publisher. The advertisement may not be used by the Advertiser or third parties 
						without Publisher's prior written consent. As to all other advertisements, Advertiser and/or Agency agree that Publisher has the non-exclusive right, for the full term of the copyright, by itself 
						or through third parties, to republish and re-use any advertisements submitted hereunder in any form in which the advertisements may be published or used (in any media now in existence or 
						hereafter developed) in whole or in any part, whether or not combined with material of others.  
					</li>
					
					<li>
						Unless expressly agreed to in writing by Publisher, no other terms or conditions to contracts, orders, copy, instruction, or otherwise will be binding on Publisher. This contract contains the 
						entire understanding between the parties and shall bind the original parties and their successors. Advertiser and/or Agency shall not assign this contract without prior written consent of the 
						Publisher.  
					</li>
					
					<li>
						All issues relating to advertising will be governed by the laws of the State of Arizona applicable to the performance of this contract. Any action brought by Advertiser and/or Agency against 
						Publisher relating to advertising must be brought in the state or federal courts in Maricopa county, Arizona and the parties hereby consent to the jurisdiction of such courts.  
					</li>
					
					<li>
						Failure by Publisher to enforce any provision of this Agreement shall not be considered a waiver of such provision.  
					</li>
					
					<li>
						Advertiser and/or Agency specifically represent and warrant that they are each sophisticated and knowledgeable in the areas governed by the terms of this Agreement and that they have been 
						given the opportunity to review the terms of this Agreement with legal counsel, as desired. 
					</li>
				</ol>

				<hr/>
				
				<p style="font-weight: bold;">
					By signing this document you are representing that you have the authority to commit the Advertiser to this Agreement and 944 MEDIA, LLC is relying on that representation.
				</p>
				
				<label class="terms">Authorized Digital Signature</label>
				<input type="text" name="terms_signature" id="terms_signature" value="">
				<!-- <input type="text" name="terms_signature" id="terms_signature" value="<?php echo $last_order['terms_signature']?>"> -->

				<label class="terms">Title</label>
				<input type="text" name="terms_title" id="terms_title" value="<?php echo $last_order['terms_title']?>">
				
				<label class="terms">Date</label>
				<input type="text" name="terms_date" id="terms_date" value="<?php echo date('m/d/Y');?>">

				<label class="terms">Notes</label>
				<textarea name="notes" id="notes" style="width: 300px; height: 100px;"><?php echo $notes?></textarea>

				<div class="cleaner"></div>
				<a href="javascript:saveForm(4);" class="save_button">Save and Mark IO Fully Approved &gt;</a>
			</div>
			
			<div id="orders_form_approved" class="orders_form_subsection" style="display: none;">
			</div>
		</div>
		<?php 
	endif; // end $order['orders_forms_id'] == 0
	
	?>

	<script type="text/javascript" charset="utf-8">
		$(document).ready(function() {
			$('#payby_card_code').focus(function () {
				$('#security_code').fadeIn();
			});

			$('#payby_card_code').blur(function () {
				$('#security_code').fadeOut();
			});
			
			<?php if ($orders_probability >= 95) {?>
				loadForm('approved');
			<?php } else {?>
				loadForm('instructions');
			<?php } ?>
		});
	</script>	

	<?php 

endif; // end if $_GET['oid'] is passed


// No oid in the URL, display the table of past IO's

if (!$_GET['oid']) :
	?>
	<table cellpadding="4" cellspacing="0" border="0" class = "activity_box" width="100%">
		<tr class = "row_title">
	        <td>Order Number</td>
			<td>Created</td>
			<td>Ad Total</td>
			<td>Service Total</td>
			<td align="center">Status</td>
		</tr>
	<?php 
	$ios_query = "SELECT orders.*,

				(SELECT IFNULL(SUM(oa.net), 0) AS adsales FROM orders AS o LEFT JOIN orders_adsales AS oa ON o.OID = oa.OID WHERE o.oid = orders.OID AND (oa.`kill` = '0' OR oa.kill_keep_invoice = 1)) AS ad_total_net,

				(SELECT IFNULL(SUM(order_total + order_barter), 0) AS services FROM orders AS o LEFT JOIN orders_services AS os ON o.OID = os.OID WHERE o.oid = orders.oid AND os.`kill` = '0') AS services_total_net,
				
				DATE_FORMAT(orders.created_date, '%M %e, %Y') AS formatted_io_date 
				
				FROM 944x_944media.orders 
					LEFT JOIN orders_adsales ON orders_adsales.OID = orders.OID 
					LEFT JOIN orders_services ON orders_services.OID = orders.OID 
				
				WHERE 
					orders.CID = '".$myuser['CID']."' 
					AND orders.probability IN (90, 95, 98, 100) 
					AND orders.kill_rep_id = 0 
				
				GROUP BY orders.OID 
				
				ORDER BY OID DESC";

	echo "<!-- ios_query:\n$ios_query\n-->";

	$ios_result = mysql_query($ios_query);
	while ($row = mysql_fetch_assoc($ios_result)) {
		?>
		<tr onMouseOver="this.bgColor='#EEEEEE';" onMouseOut="this.bgColor='white';" onClick="window.location='?oid=<?php echo $row['OID']?>'" style="cursor: hand;">
			<td>
				<a href="?oid=<?php echo $row['OID']?>"><?php echo $row['OID']?></a>
			</td>
			<td>
				<?php echo $row['formatted_io_date']?>
			</td>
			
			<td>
				$<?php echo number_format($row['ad_total_net'], 2)?>
			</td>
			
			<td>
				$<?php echo number_format($row['services_total_net'], 2)?>
			</td>
			
			<td align="center" nowrap>
				<?php 
				switch ($row['probability']) {
					case '90':
						echo 'Action Required';
						break;

					case '95':
						echo 'Pending';
						break;

					case '98':
						echo 'Approved';
						break;

					case '100':
						echo 'Approved';
						break;
					
					default:
						break;
				}
				?>
			</td>
		</tr>
		<?php 
	}
	echo '</table>';
endif;
?>

<div id="test"></div>
