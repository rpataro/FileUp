		</td>
		<td valign="top" width="240" class = "content_right">
			<?php include $_SERVER['DOCUMENT_ROOT']."/templates/links.php";?>
			<b>Contact Your Representative</b>
			<br>
			<br>
			<?php $rep = mysql_fetch_assoc(mysql_query("select r.* from company as c inner join users as r on r.userid = c.company_primary_rep where c.CID ='".$myuser['CID']."'"));?>
			<div style = "line-height:13px;">
				<?php echo $rep['fname']." ".$rep['lname'];?><br>
				<a href = "mailto:<?php echo $rep['email'];?>"><?php echo $rep['email'];?></a><br>
				<?php echo ($rep['phone_work']?$rep['phone_work']." ".($rep['phone_work_ext']?" x".$rep['phone_work_ext']:""):"");?><br>
			</div>		

			<p style="margin-top: 30px;"/>
	    	<b>Contact Accounts Receivable</b>
			<br><br>
	    	<a href = "mailto:<?php echo 'receivables@944.com';?>"><?php echo 'receivables@944.com';?></a><br>
	    	<!-- 888.PICK944 x2634 -->
		
			<p style="margin-top: 30px;" />
			<b>Contact Production Department</b>
			<br><br>
			<a href = "mailto:production@944.com">production@944.com</a><br>
			<!-- 888.PICK944 x2635 -->
	    </td>
	</tr>
		
</table>
</body>
</html>
<?php 
echo "<!-- Time To Render: ".((microtime()-$site_start) / 1)." seconds -->\n";
echo "<!-- Current Memory Usage: ".memory_get_usage()." bytes -->\n";
echo "<!-- Peak Memory Usage: ".memory_get_peak_usage()." bytes -->\n";
echo "<!-- Billing Contact ID: ".$myuser['BIID']." --->\n";
echo "<!-- Your ID: ".$myuser['IID']." --->\n";
echo "<!-- CID: ".$myuser['CID']." --->\n";



?>
