<?php if ($path[1] || 1 == 1) {

$query = "select SUM(ifnull(c.net-c.barter, 0)) - SUM(ifnull(f.payments, 0))+ SUM(ifnull(order_total,0)) - SUM(ifnull(g.payments, 0))
from orders a
inner join company b ON a.CID =b.CID
left join orders_adsales c ON a.OID =c.OID AND `kill` ='0'
LEFT join invoices e ON c.OAID =e.OTID AND e.OT =1
left join orders_services d ON a.OID =d.OID
LEFT join  (SELECT SUM(case when method IN(94, 95) THEN payments*-1 ELSE payments end) as payments
                                ,IVID FROM payments
                                GROUP BY IVID) f ON e.IVID =f.IVID
LEFT  join invoices h ON d.OSID =h.OTID AND h.OT =2
LEFT join  (SELECT SUM(case when method IN(94, 95) THEN payments*-1 ELSE payments end) as payments
                                ,IVID FROM payments
                                GROUP BY IVID) g ON h.IVID =g.IVID
where probability ='100'
AND a.cid='".$myuser['CID']."'
AND (e.IVID is not null OR h.IVID  IS NOT NULL)
GROUP BY a.CID";

list ($owed) = mysql_fetch_row(mysql_query($query));

?>

<div style = "margin-left:0px;line-height:13px;">
<br>
 <!-- <b>Account Balance</b>: <a href = "/invoices/">$<?php echo number_format(($owed*1),2);?></a><br><br><br> -->
 
	<div class = "icon"><a href = "/"><img src = "/images/icons/house.gif" border=0 align="left"> Home </a></div>
	<div class = "icon"><a href = "/artwork/"><img border=0 src = "/images/icons/picture.gif" align="left"> Submit Artwork</a></div>
	<div class = "icon"><a href = "/io/"><img border=0 width=16 height=16 src = "/images/icons/money_add.gif" align="left"> Insertion Orders</a></div>
	<?php if (($path[1]!="invoices" || 1 == 1) && ($myuser['IID']==$myuser['BIID'])) { ?><div class = "icon"><a href = "/invoices/"><img border=0 src = "/images/icons/money.gif" align="left"> View/Pay an Invoice</a></div><?php } ?>  
	<div class = "icon"><a href = "/history/"><img border=0 src = "/images/icons/magnifier.gif" align="left">Ad History</a></div>
	<div class = "icon"><a href = "/statement/"><img border=0 src = "/images/icons/time.gif" align="left">Payment Statement</a></div>
	<div class = "icon"><a href = "/password/"><img border=0 src = "/images/icons/lock_edit.gif" align="left"> Change Password</a></div>
	<div class = "icon"><a href = "/address/"><img border=0 src = "/images/icons/book_addresses.gif" align="left"> Change Contact Info</a></div>

	<?php /* if ($path[1]!="order") { ?><div class = "icon"><a href = "/order/"><img border=0 src = "/images/icons/add.gif" align="left"> Place an Order</a></div><?php } */ ?>
	
	<div class = "icon"><a href = "/?change_company=1"><img border=0 src = "/images/icons/layers.gif" align="left"> Switch Accounts</a></div>	
	<div class = "icon"><a href = "/feedback/"><img border=0 src = "/images/icons/help.gif" align="left"> Feedback/Help</a></div>

</div>
<br>
<br>
<?php } ?>	
