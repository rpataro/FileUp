<div class = "section_title">Change Password</div>
<?php if ($success=="true") {
	print "Password Changed";
} else { ?>

	<form method="POST">
	<p style = "color:#990000"><?php echo $error;?></p>
	<table class = "activity_box" cellpadding="4" cellspacing="0" border="0">
	<tr>
		<td>Old Password</td>
		<td><input type="password" name = "old"></td>
	</tr>
	<tr>
		<td>New Password</td>
		<td><input type="password" name = "new"></td>
	</tr>
	<tr>
		<td>Confirm</td>
		<td><input type="password" name = "confirm"></td>
	</tr>
	</table>
	<input type="submit" value = "Change Password">
	</form>
<?php } ?>