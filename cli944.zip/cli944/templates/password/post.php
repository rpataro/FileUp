<?php 
if (($_POST['new']=="")||($_POST['new']!=$_POST['confirm'])) {
	$error="Passwords do not match";
} else {
	$contact = mysql_fetch_assoc(mysql_query("select * from contacts where IID='".$myuser['IID']."' and password = md5('".$_POST['old']."')"));
	if ($contact['IID']!="") {
		mysql_query("update contacts set password = md5('".$_POST['new']."') where IID='".$contact['IID']."'");
		$success = "true";
	} else {
		$error = "Old Password is incorrect";
	}
}