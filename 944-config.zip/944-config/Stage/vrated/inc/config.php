<?php
  $_SERVER['SUBSCRIPTION_DOC_ROOT'] = '/var/www/html/vrated';
  $processing_gateway = 'https://stage-secure.vrated.com/base/index.php';
?>