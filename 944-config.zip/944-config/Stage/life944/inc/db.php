<?php
$db = mysql_connect('stage-private-db.944.com',"admin","hautemag");
mysql_select_db("944web",$db);
?>