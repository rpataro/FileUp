<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

$reminder_query = "SELECT *, jt.TID as ticket_number, jp.id AS proof_id, DATEDIFF(NOW(), jp.sent_datetime) AS days_since_sent, DATEDIFF(NOW(), jp.reminder_sent) AS days_since_reminder, u.email AS sent_to_email FROM job_tickets AS jt LEFT JOIN orders_services AS os ON os.OSID = jt.OTID LEFT JOIN job_proofs AS jp ON jp.tid = jt.TID LEFT JOIN users AS u ON u.userid = jt.awaiting WHERE jt.last_status IN (8, 11, 51, 55, 67) AND os.order_done = '0' AND jt.awaiting != 0 GROUP BY jt.TID";

$reminder_result = mysql_query($reminder_query);
while ($row = mysql_fetch_assoc($reminder_result)) {
	$url = 'https://944.myjuggernaut.com/production/jobtickets/jobjacket/?id='.$row['ticket_number'];
	$link = '<a href="'.$url.'">'.$url.'</a>';


	$title = "Awaiting Your Response: ".stripslashes($row['ticket_name']);
	$body = "<p>It looks like your response is still needed for the following ticket: ".stripslashes($row['ticket_name']);
	$body .= "</p><p>It's important that the job tickets are kept up to date, and that they're closed when completed. An email will be sent to you every day until you follow up; after one week, your manager will be notified.</p>";
	$body .= "<p>Please visit the following URLs and take the appropriate action immediately to help make this process work smoothly:</p>";
	$body .= "<p>Job Jacket: ".$link."</p>";
	$body .= "<p><br>Thank you.</p>";
	$to_email = $row['sent_to_email'];
//	$to_email .= ', emmanuel@944.com';

	// Add a check so that if it's been more than 7 days since the original proof request was sent (jp.sent_datetime), 
	// and reminders have been sent (jp.reminder_sent), notify the manager

	send_email('juggernaut@944.com', 'Juggernaut', $to_email, $title, $body);

	// $update_query = "UPDATE job_proofs SET reminder_sent = DATE(NOW()) WHERE id = '".$row['proof_id']."'";
	// echo $update_query;
	// $update_result = mysql_query($update_query);
	
	echo "Done.";
}

?>
