<?php
// [EJC 2009-02-19]
// Send an email to HR automatically to notify of any changes to the list of users who can login

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
include($_SERVER['DOCUMENT_ROOT'].'/includes/functions.php');
include($_SERVER['DOCUMENT_ROOT'].'/includes/functions-only.php');
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");

$body = '<p>Users with login enabled in Juggernaut:</p>';
$users_query = "SELECT * FROM 944x_944media.users WHERE login = '1' ORDER BY fname, lname";
$users_result = mysql_query($users_query);
while ($row = mysql_fetch_assoc($users_result)) {
	include($_SERVER['DOCUMENT_ROOT']."/cdata/944/users/".$row['userid']."/user_permissions.php");
	$body .= '<a href="https://944.myjuggernaut.com/administration/empconfig/edit/?userid='.$row['userid'].'">'.$row['fname'].' '.$row['lname'].'</a><br>';
}

echo $body;

send_email('juggernaut@944.com', 'Juggernaut', 'hr@944.com', 'Report: Users with login enabled', $body);
echo "email sent!";
?>
