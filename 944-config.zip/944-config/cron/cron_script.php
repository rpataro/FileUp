<?php

require_once("../public_html/includes/database.php");
require_once("../public_html/includes/phpmailer.php");

//send_email("beaufrusetta@944.com", "Beau Frusetta", "beau.frusetta@gmail.com", "Testing Subject", "Test Body");

function send_email($from_email, $from_name, $to_email, $subject, $body, $html='true', $cc='', $files='') {
	$mail = new PHPMailer();
	$mail->From = $from_email;
	$mail->AddAddress($to_email);
	if ($cc) {
		$mail->AddCC($cc);
	}
	$mail->IsHTML($html);
	$mail->FromName = $from_name;
	$mail->Subject = $subject;
	$mail->Body = $body;

	if (is_array($files)) {
		foreach ($files as $key => $file) {
			$mail->AddAttachment($file);
		}
	}

	if (!$mail->Send()) {
		return true;
	}
	else {
		return false;
	}
}


$reports = array(

  "31" => "issue_snapshot",

  "1" => "sales_activity_report",

 

  "3" => "ad_sales_split_detail_report",

  "4" => "annual_issue_sales_report",

  "5" => "issue_comparison_report",

  "6" => "premium_position_avalability_report",

  "33" => "premium_position_missing_money",

  "7" => "contract_expirations_report",

  "8" => "daily_sales_report",

  "9" => "production_report",

  "10" => "review_billing_report",

  "11" => "payments_received",

  "12" => "aging_report",

  "13" => "service_sales_report",

  "14" => "publication_metrics",

  "15" => "missing_ads",

  "16" => "open_pages",

  //"17" => "superbowl",

  "18" => "new_client_report",

  "19" => "ad_arrival_stats",

  //"20" => "metrics_backup", 

   /// "21" => "commission_report"

  ///"21" => "future_activity",

  "22" => "annual_paid_commission_report",

  "23" => "commission_paid_detail_report",

  "24" => "commission_issue_detail_report", 

  "25" => "commission_allocation_report",



  "27" => "commission_override_report", 


  "29" => "market_segments",

  "30" => "premium_position_missing_money",

  "32" => "commission_service_detail_report",

  "34" => "annual_over_90_commissions",

 "35" => "annual_over_90_commissions_detail",

  "36" => "sales_by_range", 

  "37" => "annaul_paid_commission_new_policy", 

  "38" => "commission_paid_detail_report_new_policy", 

  "39" => "commission_issue_detail_report_new_policy", 

  "40" => "commission_quarterly_paid_detail", 

  "41" => "sales_bandwith_report", 

  "42" => "muti_market_advertisers", 

  "43" => "trade_usage", 

  "44" => "trade_usage_summary", 

  "45" => "commission_reduction_report", 

  "46" => "pulled_by_range",

  "47" => "met_sales_goal",

  "48" => "sales_segments",

  "49" => "year_over_year",   
  
  "50" => "actual_to_rate",

  "51" => "annual_client_spend", 

  "52" => "annual_quarter_sales"  ,

  "53" => "ad_fractionals" ,

  "54" => "rep_activity",
  
  "55" => "bandwidth_by_pub", 
  
  "56" => "commission_feb2009", 

  "57" => "commission_feb2009_detail" , 

  "58" => "944_picks", 

  "59" => "artwork_aging" 
);



$reports_desc = array(

  "1" => array("url" => "/reports/?rid=1","desc" => "View sales repsí activity by office"),

 

  "3" => array("url" => "/reports/?rid=3","desc" => "View split commissions for an issue by publication, office or rep"),

  "4" => array("url" => "/reports/?rid=4","desc" => "View annual sales by publication or office"),

  "5" => array("url" => "/reports/?rid=5","desc" => "Compare 2 issues of a publication"),

  "6" => array("url" => "/reports/?rid=6","desc" => "View premium position availability by year"),

  "7" => array("url" => "/reports/?rid=7","desc" => "View all contracts set to expire in a month by publication or rep"),

  "8" => array("url" => "/reports/?rid=8","desc" => "View up-to-date sales for an issue"),

  "9" => array("url" => "/production/reports/","desc" => "View all placement detail by publication by month "),

  "10" => array("url" => "/reports/?rid=10","desc" => "Verify correct billing information for an issue"),

  "11" => array("url" => "/reports/?rid=11","desc" => "View incoming payments and applicable commissions"),

  "12" => array("url" => "/reports/?rid=12","desc" => "View all outstanding invoices by publication, rep, or office "),

  "13" => array("url" => "/reports/?rid=13","desc" => "View all event sponsorship and service sales closed"),

  "14" => array("url" => "/reports/?rid=14","desc" => "View sales, page, and circ totals vs goal"),

  "15" => array("url" => "/production/missingads/","desc" => "View a list of all outstanding ads for any issue"),

  "16" => array("url" => "/reports/?rid=16","desc" => "View detail about available space in any future issue"),

  "17" => array("url" => "/reports/?rid=17","desc" => "Superbowl Event Summay including ticket & sponsorship sales"),

  "18" => array("url" => "/reports/?rid=18","desc" => "Classifies clients into new vs. existing for any issue"),

  "19" => array("url" => "/reports/?rid=19","desc" => "Displays % of ads that have arrived for any issue"),

  "21" => array("url" => "/reports/?rid=21","desc" => "Search for future callbacks or meetings"), 

  "22" => array("url" => "/reports/?rid=22","desc" => "View annual commissions paid"),

  "23" => array("url" => "/reports/?rid=23","desc" => "View paid commission detail by paid date"),

  "24" => array("url" => "/reports/?rid=24","desc" => "View commissionable, paid, and potential commission detail by issue"),

  "25" => array("url" => "/reports/?rid=25","desc" => "View sales allocation for current commission period"),

  "27" => array("url" => "/reports/?rid=27","desc" => "View commission overrides"),

  "28" => array("url" => "/reports/?rid=28","desc" => ""),

  "29" => array("url" => "/reports/?rid=29","desc" => "Market Segmentation Penetration Summary"),

  "31" => array("url" => "/reports/?rid=31","desc" => "Issue Snapshot Report"), 

  "32" => array("url" => "/reports/?rid=32","desc" => "View commisson paid for services"),

  "33" => array("url" => "/reports/?rid=33","desc" => "Available potential revenue based on premium positions"),

  "34" => array("url" => "/reports/?rid=34","desc" => "View ineligible commissions"),

  "35" => array("url" => "/reports/?rid=35","desc" => "View ineligible commission detail"),

  "36" => array("url" => "/reports/?rid=36","desc" => "View contract sales by date"),

  "37" => array("url" => "/reports/?rid=37","desc" => "View summary of paid commissions by year"),

  "38" => array("url" => "/reports/?rid=38","desc" => "View detail of paid commissions by year"),

  "39" => array("url" => "/reports/?rid=39","desc" => "View detail of paid commissions by year"),

  "40" => array("url" => "/reports/?rid=40","desc" => "View detail of quarterly comissions paid for meeting quota"),

  "41" => array("url" => "/reports/?rid=41","desc" => "View reps starting sales and weekly progess by issue"),

  "42" => array("url" => "/reports/?rid=42","desc" => "View multi market advertiser sales report"),

  "43" => array("url" => "/reports/?rid=43","desc" => "View trade usage detail"),

  "44" => array("url" => "/reports/?rid=44","desc" => "View trade usage summary data"),

  "45" => array("url" => "/reports/?rid=45","desc" => "View detail of commission reductions due to refund, nsf etc."),

  "46" => array("url" => "/reports/?rid=46","desc" => "View pulled contract sales by range"),

  "47" => array("url" => "/reports/?rid=47","desc" => "View sales goal to actual by rep"),

  "48" => array("url" => "/reports/?rid=48","desc" => "View sales by segment"),

  "49" => array("url" => "/reports/?rid=49","desc" => "View year over year & year to date comparisons"),

  "50" => array("url" => "/reports/?rid=50","desc" => "View actual sales to rate card"),

  "51" => array("url" => "/reports/?rid=51","desc" => "Annualized Spend by Client per Issue"),
  "52" => array("url" => "/reports/?rid=52","desc" => "Annualized sales by quarter"),
  "53" => array("url" => "/reports/?rid=53","desc" => "Ad Fractionals by Issue"),
  "54" => array("url" => "/reports/?rid=54","desc" => "Rep Activity Summary"),
  "55" => array("url" => "/reports/?rid=55","desc" => "Sales Bandwidth by Publication"), 
  "56" => array("url" => "/reports/?rid=56","desc" => "Rep Commissions (Feb 2009+)"), 
  "57" => array("url" => "/reports/?rid=57","desc" => "Rep Commissions (Feb 2009+) - Detail"),   
  "58" => array("url" => "/reports/?rid=58","desc" => "944 Picks by Market"), 
  "59" => array("url" => "/reports/?rid=59","desc" => "Artwork Aging")
  
);

echo "\n";
echo "INSERT INTO 944x_944media.reports (id, name, description, filename, category) \n VALUES ";
foreach ($reports as $key => $file) {
	$title_arr = explode("_",$file);
	$title = "";
	foreach($title_arr as $name) {
		$title .= ucwords($name)." ";
	}
	echo "(".$key.", '".trim($title)."', '".$reports_desc[$key]["desc"]."', '".$file.".php', 'sales'),\n";
}

?>