<?php

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");

//$month = date("n");
$month = 10;
$year = date("Y");
$userid = 1163;

## Get user records
$users_sql = "SELECT * FROM users WHERE userid = $userid";
$users_query = mysql_query($users_sql);
$users = array();

while ($row = mysql_fetch_object($users_query)) {
	$users[$row->userid] = $row;
}

## Clear table
mysql_query("DELETE FROM 944x_944media.commissions WHERE report_month = $month AND report_year = $year AND user_id = $userid");

include($_SERVER['DOCUMENT_ROOT']."/templates/reports/commission_query_all_reps_new.php");
$query = mysql_query($detail_sql);

if (mysql_error()) {
	echo mysql_error();
}

## Will be used to clear out exisiting information
$current_user_id = 0;

echo "Processing commissions for ".$users[$userid]->fname." ".$users[$userid]->lname." for $month/$year...\n";

while($row = mysql_fetch_object($query)) {

	## If the user_id value has changed, make sure to clear out data for that user so no duplicates pop up
	if ($row->user_id != $current_user_id) {
		$current_user_id = $row->user_id;
		$sql = "DELETE FROM commissions WHERE user_id = ".$current_user_id." AND report_month = ".$month." AND report_year = ".$year;
		mysql_query($sql);
	}
	
	#Set Default User Object
	$user = $users[$current_user_id];

	## Setup default commission variables on the row object
	$row->commission = 0;
	$row->commission_percent = 0;

	## Create issue month/year values to use when getting goals/sales information
	$row->issue_month = date("m",strtotime($row->iss_report_date));
	$row->issue_year = date("Y",strtotime($row->iss_report_date));

	## Get goals/sales info by rep for the individual sales month
	$goals = common_GetSalesGoals($row->issue_month,$row->issue_year,$userid);
	$sales = common_GetSales($row->issue_month,$row->issue_year,$userid);

	## Setup default goals/sales variables on the row object
	$row->total_goal = $goals[$row->user_id]->sales_goal;
	$row->total_sales = $sales[$row->user_id]->total_sales;
	
	## Check for blank goals/sales - set to 0
	if ($row->total_goal == "") { $row->total_goal = 0; }
	if ($row->total_sales == "") { $row->total_sales = 0; }
	
	## Determine Commission Calculation
	switch ($user->commission_plan) {
		
		case 0: ## No Commission Plan
		
			$row->commission = 0;
			$row->commission_percent = 0;
		
			break;
			
		case 1: ## Standard 944 (Plan-2/Plan-3) 
		
			switch ($row->plan) {
				
				case "Plan-2":

					## Calculate Addtional Percent
					$additional_percent = 0;
					if ($goals[$row->user_id]->sales_goal > 0) { 
						if ($sales[$row->user_id]->total_sales >= $goals[$row->user_id]->sales_goal) { 
							$additional_percent = 0.04;
						}
					}
			
					if ($row->rate_card > 0) { 
						if ($row->sold_split < $row->rate_card) { 
							if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
								$row->commission = $row->payment_split * (0.04 + $additional_percent);
								$row->commission_percent = (0.04 + $additional_percent);
							} else {
								$row->commission = 0;
								$row->commission_percent = 0;
							}
						} else {
							$row->commission = $row->payment_split * (0.04 + $additional_percent);
							$row->commission_percent = (0.04 + $additional_percent);
						}
					} else {
						$row->commission = 0;
						$row->commission_percent = 0;
					}
			
					if ($additional_percent > 0) { 
						$row->plan = $row->plan."+";
					}
			
					break;
					
				case "Plan-3":
			
					## Sexy Selling Calculations
					$sexy_defs = array(125,127,129,131,133,135,137);
			
					switch ($row->color_id) { 
						case 1: $base_commission = 0.15; break;
						case 2: $base_commission = 0.20; break;
						case 3: $base_commission = 0.10; break;
					}
			
					if ($row->rate_card > 0) { 
						if ($row->color_id != 3) { 
			
							if (!in_array($row->def_id, $sexy_defs)) { 
								## Sales Rep sold less than 
								if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
									$commission_percent = $base_commission * ($row->sold_split / $row->rate_card);
								} else {
									$commission_percent = 0;
								}
								
								## Sales Rep sold at or over rate card
								if ($row->sold_split >= $row->rate_card) { $commission_percent = $base_commission; }
								
								## June 2009 Sales Promos
								if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
									
									## "All Aboard"
									if ($row->def_id == 155 || $row->def_id == 157) {
										$commission_percent = 0.075;
									}
									
									## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
									if ($row->def_id >= 159 && $row->def_id == 219) {
										$commission_percent = 0.15;
									}
			
									$row->plan = $row->plan."-PROMO";
								}
								
							} else {
								## Sexy Selling Ratecards - Flat 10%
								$commission_percent = 0.10;
								$row->plan = $row->plan."-SS";
							}
			
						} else {
							## June 2009 Sales Promos
							if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
								
								## "All Aboard"
								if ($row->def_id == 155 || $row->def_id == 157) {
									$commission_percent = 0.075;
								}
								
								## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
								if ($row->def_id >= 159 && $row->def_id == 219) {
									$commission_percent = 0.15;
								}
		
								$row->plan = $row->plan."-PROMO";
							} else {
								$commission_percent = $base_commission;
							}
						}
					} else {
						$commission_percent = 0;
					}
			
					## Calculate commission
					$row->commission = $row->payment_split * $commission_percent;
					$row->commission_percent = $commission_percent;
			
					break;
				
			}
		
			break;
			
		case 2: ## Standard 944 (Plan 3 Only)
		
			## Sexy Selling Calculations
			$sexy_defs = array(125,127,129,131,133,135,137);
	
			switch ($row->color_id) { 
				case 1: $base_commission = 0.15; break;
				case 2: $base_commission = 0.20; break;
				case 3: $base_commission = 0.10; break;
			}
	
			if ($row->rate_card > 0) { 
				if ($row->color_id != 3) { 
	
					if (!in_array($row->def_id, $sexy_defs)) { 
						## Sales Rep sold less than 
						if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
							$commission_percent = $base_commission * ($row->sold_split / $row->rate_card);
						} else {
							$commission_percent = 0;
						}
						
						## Sales Rep sold at or over rate card
						if ($row->sold_split >= $row->rate_card) { $commission_percent = $base_commission; }
						
						## June 2009 Sales Promos
						if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
							
							## "All Aboard"
							if ($row->def_id == 155 || $row->def_id == 157) {
								$commission_percent = 0.075;
							}
							
							## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
							if ($row->def_id >= 159 && $row->def_id == 219) {
								$commission_percent = 0.15;
							}
	
							$row->plan = $row->plan."-PROMO";
						}
						
					} else {
						## Sexy Selling Ratecards - Flat 10%
						$commission_percent = 0.10;
						$row->plan = $row->plan."-SS";
					}
	
				} else {
					## June 2009 Sales Promos
					if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
						
						## "All Aboard"
						if ($row->def_id == 155 || $row->def_id == 157) {
							$commission_percent = 0.075;
						}
						
						## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
						if ($row->def_id >= 159 && $row->def_id == 219) {
							$commission_percent = 0.15;
						}

						$row->plan = $row->plan."-PROMO";
					} else {
						$commission_percent = $base_commission;
					}
				}
			} else {
				$commission_percent = 0;
			}
			
			if ($row->plan == 'Plan-2') { $row->plan = 'Plan-3'; }
	
			## Calculate commission
			$row->commission = $row->payment_split * $commission_percent;
			$row->commission_percent = $commission_percent;
		
			break;
			
		case 3: ## Out of Market
		
			## Get issue market 
			$issue_market = mysql_fetch_object(mysql_query("SELECT nightsite_locale FROM issues i INNER JOIN pubs p ON i.pubid = p.id WHERE i.id = ".$row->iss_id));
			$user_market = mysql_fetch_object(mysql_query("SELECT locale FROM offices WHERE office_id = ".$user->office_id));
			
			if ($issue_market->nightsite_locale != $user_market->locale) { 
				
				switch ($row->plan) {
					
					case "Plan-2":
	
						## Calculate Addtional Percent
						$additional_percent = 0;
						if ($goals[$row->user_id]->sales_goal > 0) { 
							if ($sales[$row->user_id]->total_sales >= $goals[$row->user_id]->sales_goal) { 
								$additional_percent = 0.04;
							}
						}
				
						if ($row->rate_card > 0) { 
							if ($row->sold_split < $row->rate_card) { 
								if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
									$row->commission = $row->payment_split * (0.04 + $additional_percent);
									$row->commission_percent = (0.04 + $additional_percent);
								} else {
									$row->commission = 0;
									$row->commission_percent = 0;
								}
							} else {
								$row->commission = $row->payment_split * (0.04 + $additional_percent);
								$row->commission_percent = (0.04 + $additional_percent);
							}
						} else {
							$row->commission = 0;
							$row->commission_percent = 0;
						}
				
						if ($additional_percent > 0) { 
							$row->plan = $row->plan."+";
						}
				
						break;
						
					case "Plan-3":
				
						## Sexy Selling Calculations
						$sexy_defs = array(125,127,129,131,133,135,137);
				
						switch ($row->color_id) { 
							case 1: $base_commission = 0.15; break;
							case 2: $base_commission = 0.20; break;
							case 3: $base_commission = 0.10; break;
						}
				
						if ($row->rate_card > 0) { 
							if ($row->color_id != 3) { 
				
								if (!in_array($row->def_id, $sexy_defs)) { 
									## Sales Rep sold less than 
									if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
										$commission_percent = $base_commission * ($row->sold_split / $row->rate_card);
									} else {
										$commission_percent = 0;
									}
									
									## Sales Rep sold at or over rate card
									if ($row->sold_split >= $row->rate_card) { $commission_percent = $base_commission; }
									
									## June 2009 Sales Promos
									if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
										
										## "All Aboard"
										if ($row->def_id == 155 || $row->def_id == 157) {
											$commission_percent = 0.075;
										}
										
										## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
										if ($row->def_id >= 159 && $row->def_id == 219) {
											$commission_percent = 0.15;
										}
				
										$row->plan = $row->plan."-PROMO";
									}
									
								} else {
									## Sexy Selling Ratecards - Flat 10%
									$commission_percent = 0.10;
									$row->plan = $row->plan."-SS";
								}
				
							} else {
								## June 2009 Sales Promos
								if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
									
									## "All Aboard"
									if ($row->def_id == 155 || $row->def_id == 157) {
										$commission_percent = 0.075;
									}
									
									## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
									if ($row->def_id >= 159 && $row->def_id == 219) {
										$commission_percent = 0.15;
									}
			
									$row->plan = $row->plan."-PROMO";
								} else {
									$commission_percent = $base_commission;
								}
							}
						} else {
							$commission_percent = 0;
						}
				
						## Calculate commission
						$row->commission = $row->payment_split * $commission_percent;
						$row->commission_percent = $commission_percent;
				
						break;
				}
				
			} else {
				$row->commission = 0;
				$row->commission_percent = 0;
			}
		
			break;
			
		case 4: ## Out of Market (No National)
		
			## Get issue market 
			$issue_market = mysql_fetch_object(mysql_query("SELECT nightsite_locale FROM issues i INNER JOIN pubs p ON i.pubid = p.id WHERE i.id = ".$row->iss_id));
			$user_market = mysql_fetch_object(mysql_query("SELECT locale FROM offices WHERE office_id = ".$user->office_id));
			
			if ($issue_market->nightsite_locale != $user_market->locale && $issue_market->nightsite_locale != 0) { 
				
				switch ($row->plan) {
					
					case "Plan-2":
	
						## Calculate Addtional Percent
						$additional_percent = 0;
						if ($goals[$row->user_id]->sales_goal > 0) { 
							if ($sales[$row->user_id]->total_sales >= $goals[$row->user_id]->sales_goal) { 
								$additional_percent = 0.04;
							}
						}
				
						if ($row->rate_card > 0) { 
							if ($row->sold_split < $row->rate_card) { 
								if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
									$row->commission = $row->payment_split * (0.04 + $additional_percent);
									$row->commission_percent = (0.04 + $additional_percent);
								} else {
									$row->commission = 0;
									$row->commission_percent = 0;
								}
							} else {
								$row->commission = $row->payment_split * (0.04 + $additional_percent);
								$row->commission_percent = (0.04 + $additional_percent);
							}
						} else {
							$row->commission = 0;
							$row->commission_percent = 0;
						}
				
						if ($additional_percent > 0) { 
							$row->plan = $row->plan."+";
						}
				
						break;
						
					case "Plan-3":
				
						## Sexy Selling Calculations
						$sexy_defs = array(125,127,129,131,133,135,137);
				
						switch ($row->color_id) { 
							case 1: $base_commission = 0.15; break;
							case 2: $base_commission = 0.20; break;
							case 3: $base_commission = 0.10; break;
						}
				
						if ($row->rate_card > 0) { 
							if ($row->color_id != 3) { 
				
								if (!in_array($row->def_id, $sexy_defs)) { 
									## Sales Rep sold less than 
									if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
										$commission_percent = $base_commission * ($row->sold_split / $row->rate_card);
									} else {
										$commission_percent = 0;
									}
									
									## Sales Rep sold at or over rate card
									if ($row->sold_split >= $row->rate_card) { $commission_percent = $base_commission; }
									
									## June 2009 Sales Promos
									if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
										
										## "All Aboard"
										if ($row->def_id == 155 || $row->def_id == 157) {
											$commission_percent = 0.075;
										}
										
										## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
										if ($row->def_id >= 159 && $row->def_id == 219) {
											$commission_percent = 0.15;
										}
				
										$row->plan = $row->plan."-PROMO";
									}
									
								} else {
									## Sexy Selling Ratecards - Flat 10%
									$commission_percent = 0.10;
									$row->plan = $row->plan."-SS";
								}
				
							} else {
								## June 2009 Sales Promos
								if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
									
									## "All Aboard"
									if ($row->def_id == 155 || $row->def_id == 157) {
										$commission_percent = 0.075;
									}
									
									## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
									if ($row->def_id >= 159 && $row->def_id == 219) {
										$commission_percent = 0.15;
									}
			
									$row->plan = $row->plan."-PROMO";
								} else {
									$commission_percent = $base_commission;
								}
							}
						} else {
							$commission_percent = 0;
						}
				
						## Calculate commission
						$row->commission = $row->payment_split * $commission_percent;
						$row->commission_percent = $commission_percent;
				
						break;
				}
				
			} else {
				$row->commission = 0;
				$row->commission_percent = 0;
			}
		
			break;
			
		case 5: ## Flat
			
			$base_commission = $user->commission_percent/100;
	
			## Sexy Selling Calculations
			$sexy_defs = array(125,127,129,131,133,135,137);
	
			if ($row->rate_card > 0) { 
				if ($row->color_id != 3) { 
	
					if (!in_array($row->def_id, $sexy_defs)) { 
						## Sales Rep sold less than 
						if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
							$commission_percent = $base_commission;
						} else {
							$commission_percent = 0;
						}
						
						## Sales Rep sold at or over rate card
						if ($row->sold_split >= $row->rate_card) { $commission_percent = $base_commission; }
						
						## June 2009 Sales Promos
						if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
							
							## "All Aboard"
							if ($row->def_id == 155 || $row->def_id == 157) {
								$commission_percent = 0.075;
							}
							
							## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
							if ($row->def_id >= 159 && $row->def_id == 219) {
								$commission_percent = 0.15;
							}
	
							$row->plan = $row->plan."-PROMO";
						}
						
					} else {
						## Sexy Selling Ratecards - Flat 10%
						$commission_percent = 0.10;
						$row->plan = $row->plan."-SS";
					}
	
				} else {
					
					## June 2009 Sales Promos
					if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
						
						## "All Aboard"
						if ($row->def_id == 155 || $row->def_id == 157) {
							$commission_percent = 0.075;
						}
						
						## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
						if ($row->def_id >= 159 && $row->def_id == 219) {
							$commission_percent = 0.15;
						}

						$row->plan = $row->plan."-PROMO";
					} else {
						$commission_percent = $base_commission;
					}
					
				}
			} else {
				$commission_percent = 0;
			}
	
			## Calculate commission
			$row->commission = $row->payment_split * $commission_percent;
			$row->commission_percent = $commission_percent;
		
			break;
			
		case 6: ## Ad Sales Only (Print/Web)
		
			switch ($row->plan) {
				
				case "Plan-2":

					## Calculate Addtional Percent
					$additional_percent = 0;
					if ($goals[$row->user_id]->sales_goal > 0) { 
						if ($sales[$row->user_id]->total_sales >= $goals[$row->user_id]->sales_goal) { 
							$additional_percent = 0.04;
						}
					}
			
					if ($row->rate_card > 0) { 
						if ($row->sold_split < $row->rate_card) { 
							if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
								$row->commission = $row->payment_split * (0.04 + $additional_percent);
								$row->commission_percent = (0.04 + $additional_percent);
							} else {
								$row->commission = 0;
								$row->commission_percent = 0;
							}
						} else {
							$row->commission = $row->payment_split * (0.04 + $additional_percent);
							$row->commission_percent = (0.04 + $additional_percent);
						}
					} else {
						$row->commission = 0;
						$row->commission_percent = 0;
					}
			
					if ($additional_percent > 0) { 
						$row->plan = $row->plan."+";
					}
			
					break;
					
				case "Plan-3":
			
					## Sexy Selling Calculations
					$sexy_defs = array(125,127,129,131,133,135,137);
			
					switch ($row->color_id) { 
						case 1: $base_commission = 0.15; break;
						case 2: $base_commission = 0.20; break;
						case 3: $base_commission = 0.10; break;
					}
			
					if ($row->rate_card > 0) { 
						if ($row->color_id != 3) { 
			
							if (!in_array($row->def_id, $sexy_defs)) { 
								## Sales Rep sold less than 
								if (($row->sold_split / $row->rate_card) < 1 && ($row->sold_split / $row->rate_card) >= .5) { 
									$commission_percent = $base_commission * ($row->sold_split / $row->rate_card);
								} else {
									$commission_percent = 0;
								}
								
								## Sales Rep sold at or over rate card
								if ($row->sold_split >= $row->rate_card) { $commission_percent = $base_commission; }
								
								## June 2009 Sales Promos
								if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
									
									## "All Aboard"
									if ($row->def_id == 155 || $row->def_id == 157) {
										$commission_percent = 0.075;
									}
									
									## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
									if ($row->def_id >= 159 && $row->def_id == 219) {
										$commission_percent = 0.15;
									}
			
									$row->plan = $row->plan."-PROMO";
								}
								
							} else {
								## Sexy Selling Ratecards - Flat 10%
								$commission_percent = 0.10;
								$row->plan = $row->plan."-SS";
							}
			
						} else {
							## June 2009 Sales Promos
							if ($row->def_id >= 155 && $row->def_id <= 219 && $row->sold_split >= $row->rate_card) {
								
								## "All Aboard"
								if ($row->def_id == 155 || $row->def_id == 157) {
									$commission_percent = 0.075;
								}
								
								## "Goodie Bag", "Mix & Match", "Roger Rabbit", "Let it Ride", "Kool Kids", "Fake to Front", "5.5 Degrees", "Shabby Chic"
								if ($row->def_id >= 159 && $row->def_id == 219) {
									$commission_percent = 0.15;
								}
		
								$row->plan = $row->plan."-PROMO";
							} else {
								$commission_percent = $base_commission;
							}
						}
					} else {
						$commission_percent = 0;
					}
			
					## Calculate commission
					$row->commission = $row->payment_split * $commission_percent;
					$row->commission_percent = $commission_percent;
			
					break;
				
			}
		
			break;
		
	}

	## Insert row into commissions table
	$sql  = "INSERT INTO commissions (user_id, company_id, invoice_id, issue, ad_size, split, rate_split, sold_split, invoice_date, invoice_duedate, ";
	$sql .= "payments, eligible_date, plan, commission_percent, commission, total_sales, total_goal, report_month, report_year) ";
	$sql .= "VALUES (".$row->user_id.", ".$row->CID.", ".$row->IVID.", '".$row->iss_name."', '".$row->ad_size."', ".$row->split.", ".$row->rate_card.", ";
	$sql .= $row->sold_split.", '".$row->invoice_date."', '".$row->invoice_duedate."', ".$row->payment_split.", '".$row->eligible_date."', '".$row->plan."' ,";
	$sql .= $row->commission_percent.", ".$row->commission.", ".$row->total_sales.", ".$row->total_goal.", $month, $year)";
	mysql_query($sql);

}

echo "Done-zo\n";

?>
