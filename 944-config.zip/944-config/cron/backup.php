#!/usr/bin/php
<?php
// require_once("/san/com944x/www/includes/phpmailer.php");

if ($argv[1] == "juggernaut") {
	$site = "Juggernaut";
	$site_filename = "juggernaut";
	$path = "/san/com944x";
}
elseif ($argv[1] == "client") {
	$site = "Client";
	$site_filename = "client";
	$path = "/san/cli944";
}
elseif ($argv[1] == "proofcenter") {
	$options = '-o -name "*.swf"';
	$site = "Proof Center";
	$site_filename = "proofcenter";
	$path = "/san/proof944";
}
elseif ($argv[1] == "databases") {
	$options = "";
	$type = "databases";
	$path = "/san/life944";
}
else {
	$site = "944com";
	$site_filename = "944com";
	$path = "/san/life944";
}

if ($argv[2] == "full") {
	$options = "";
	$type = "full";
}
elseif ($argv[2] == "daily") {
	$required_parameter = "-mtime 0";
	// $options .= " -mtime 0";
	$type = "daily";
}

$to = "emmanuel@944.com";
// $to = "emmanuel@944.com";
$now = date('Y-m-d');
$year = date('Y');
$month = date('m');

if ($type == "databases") {
	$dbs["juggernaut"]["db"] = "944x_944media";
	$dbs["944com"]["db"] = "944com";
	$dbs["944web"]["db"] = "944web";
	$mysql = 'mysqldump -h db.944.com -u admin --password="hautemag"';

	foreach ($dbs as $name => $db) {
		$filename = "db-backup-".$name."-".$now.".gz";
		exec("mkdir ".$path."/backups/".$year);
		exec("mkdir ".$path."/backups/".$year."/".$month);
		$backup_file = $path."/backups/".$year."/".$month."/".$filename;
		$db_name = $db["db"];
		// $command = $mysql.' '.$db_name.' | gzip > '.$backup_file;
		exec($mysql.' '.$db_name.' | gzip > '.$backup_file);
		$message = ucfirst($name)." DB Backup - ".$now;
// DB files are too big to email..
		// send_mail($message, $filename, $to, $path);
		// echo "mail sent";
	}

}
else {
	$filename = "php-backup-".$site_filename."-".$type."-".$now.".zip";
	exec("mkdir ".$path."/backups/".$year);
	exec("mkdir ".$path."/backups/".$year."/".$month);
	$backup_file = $path."/backups/".$year."/".$month."/".$filename;
	// echo 'cd '.$path.'/www; find ./ '.$required_parameter.' -name "*.php*" '.$options.' -o -path "./data" -prune -o -path "./cdata" -prune', $files;
	// exit;
	$exec_command = 'cd '.$path.'/www; find ./ '.$required_parameter.' -name "*.php*" -o -name "*.css" -o -name "*.htm*" '.$options.' -o -path "./data" -prune -o -path "./cdata" -prune';
	exec($exec_command, $files);
	foreach ($files as $index => $file) {
		$file = str_replace("./", $path."/www/", $file);
		// $file_list .= $file.' ';
	// Had to execute zip within the loop as there were too many filenames otherwise, and xargs wasn't working for some reason
		echo exec('zip '.$backup_file.' "'.$file.'"');
	}
	// exec('cd '.$path.'/backups; zip '.$backup_file.' '.$file_list);
	$message = $site." ".ucfirst($type)." PHP Backup - ".$now;

	// Don't email notifications for proofcenter backups since they're too big.
	if ($site != 'Proof Center') {
// Emails aren't really needed anymore with Git running, and all auto-copying to the local backup server at the Phx office
//		send_mail($message, $filename, $to, $path);
	}
}

echo "*** done processing automated backup ***";

function send_mail($message, $filename, $to, $path) {
	global $year;
	global $month;
	$mail_command = '(echo "'.$message.'"; /usr/bin/uuencode '.$filename.' '.$filename.') | /bin/mail '.$to.' -s "'.$message.'"';
	exec('cd '.$path.'/backups/'.$year.'/'.$month.'; '.$mail_command);
}

?>

