<?php 

##
## Notification System
##

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");
require_once("/var/www/html/life944/public_html/inc/functions-shared.php");

$seconds = 86400;
$current_issue_date = common_getCurrentIssueDate(true);
$prod_schedule = mysql_fetch_object(mysql_query("SELECT * FROM production_schedule WHERE issue_date = '".date("Y-m-d", $current_issue_date)."'"));
$print_day_unix = strtotime($prod_schedule->print_date);
$artwork_day_unix = strtotime($prod_schedule->artwork_date);
$print_day_unix_prior7 = strtotime("-7 Days", $print_day_unix);
$closing_day = strtotime($prod_schedule->closing_date);

$monday_print_week = $print_day_unix;
while (date("D",$monday_print_week) != 'Mon') {
	$monday_print_week = strtotime("-1 Day", $monday_print_week);
}

## Previous Production Schedule
$prev_prod_schedule = mysql_fetch_object(mysql_query("SELECT * FROM production_schedule WHERE issue_date = '".date("Y-m-d", strtotime("-1 month", $current_issue_date))."'"));
$day_after_print = strtotime("+1 day", strtotime($prod_schedule->print_date));

$today_unix = strtotime(date("Y-m-d"));
//$today_unix = strtotime('2009-12-09');

$today1_unix = $today_unix + $seconds;
$today7_unix = $today_unix + ($seconds * 7);

$day_num = date("j", $today_unix);
$month_num = date("n", $today_unix);
$year_num = date("Y", $today_unix);

$all_employees = array();

## Grab the notification groups
$city_publishers = array();
$query = mysql_query("SELECT users.* FROM users INNER JOIN notification_group_list ON users.userid = notification_group_list.userid WHERE notification_group_list.groupid = 1");

while ($row = mysql_fetch_object($query)) {
	$city_publishers[] = $row;
	$all_employees[] = $row;
}

$city_directors = array();
$query = mysql_query("SELECT users.*, offices.full_office_name FROM users LEFT JOIN offices ON offices.office_id = users.office_id INNER JOIN notification_group_list ON users.userid = notification_group_list.userid WHERE notification_group_list.groupid = 2");

while ($row = mysql_fetch_object($query)) {
	$city_directors[] = $row;
	$all_employees[] = $row;
}

$sales = array();
$query = mysql_query("SELECT users.* FROM users INNER JOIN notification_group_list ON users.userid = notification_group_list.userid WHERE notification_group_list.groupid = 3");

while ($row = mysql_fetch_object($query)) {
	$sales[] = $row;
	$all_employees[] = $row;
}

$management = array();
$query = mysql_query("SELECT users.* FROM users INNER JOIN notification_group_list ON users.userid = notification_group_list.userid WHERE notification_group_list.groupid = 4");

while ($row = mysql_fetch_object($query)) {
	$management[] = $row;
	$all_employees[] = $row;
}

$editors = array();
$query = mysql_query("SELECT users.* FROM users INNER JOIN notification_group_list ON users.userid = notification_group_list.userid WHERE notification_group_list.groupid = 5");

while ($row = mysql_fetch_object($query)) {
	$editors[] = $row;
	$all_employees[] = $row;
}

##
## Accounts Receivable (Day 1 & Day 16)
##
if ($day_num == 1 || $day_num == 16) {
	
	foreach ($city_publishers as $user) { 
		$report_link = 'https://944.myjuggernaut.com/reports/?rid=12&amp;associated_company=1&amp;pub=&amp;date='.$month_num.'%2F'.$day_num.'%2F'.$year_num.'&amp;office_id='.$user->office_id.'&amp;userid=&amp;aid=&amp;cash=0';
		$subject = "Accounts Receivable Notification";
		$message  = 'Attached is your schedule of account receivables, please make sure to follow up with each of your ';
		$message .= 'accounts to get any information necessary to ensure prompt payment of the outstanding balance.<br><br>';
		$message .= 'If you need any assistance, please feel free to contact Accounts Receivable (<a href="mailto:receivables@944.com">receivables@944.com</a>).<br><br>';
		$message .= '<a href="'.$report_link.'">View A/R Report</a>';
		
		emailNotification($user->userid,$subject,$message);
	}
	
	foreach ($city_directors as $user) { 
		$report_link = 'https://944.myjuggernaut.com/reports/?rid=12&amp;associated_company=1&amp;pub=&amp;date='.$month_num.'%2F'.$day_num.'%2F'.$year_num.'&amp;office_id='.$user->office_id.'&amp;userid=&amp;aid=&amp;cash=0';
		$subject = "Accounts Receivable Notification";
		$message  = 'Attached is your schedule of account receivables, please make sure to follow up with each of your ';
		$message .= 'accounts to get any information necessary to ensure prompt payment of the outstanding balance.<br><br>';
		$message .= 'If you need any assistance, please feel free to contact Accounts Receivable (<a href="mailto:receivables@944.com">receivables@944.com</a>).<br><br>';
		$message .= '<a href="'.$report_link.'">View A/R Report</a>';
		
		emailNotification($user->userid,$subject,$message);
	}
	
	foreach ($sales as $user) { 
		$report_link = 'https://944.myjuggernaut.com/reports/?rid=12&amp;associated_company=1&amp;pub=&amp;date='.$month_num.'%2F'.$day_num.'%2F'.$year_num.'&amp;office_id='.$user->office_id.'&amp;userid=&amp;aid=&amp;cash=0';
		$subject = "Accounts Receivable Notification";
		$message  = 'Attached is your schedule of account receivables, please make sure to follow up with each of your ';
		$message .= 'accounts to get any information necessary to ensure prompt payment of the outstanding balance.<br><br>';
		$message .= 'If you need any assistance, please feel free to contact Accounts Receivable (<a href="mailto:receivables@944.com">receivables@944.com</a>).<br><br>';
		$message .= '<a href="'.$report_link.'">View A/R Report</a>';
		
		emailNotification($user->userid,$subject,$message);
	}
	
}

##
## Distribution Updates 
##
if ($day_num == 12 || $day_num == 18) {

	foreach ($city_directors as $user) { 	
		$subject = "Distribution Changes Notification";
		
		$message  = 'It is that time of the month again and we want to make sure that our magazines get out to all the ';
		$message .= 'right people in '.$user->full_office_name.', so we need you to submit your updates for distribution into Juggernaut.<br><br>';
		$message .= '<a href="#">Distribution Change Instructions</a><br><br>';
		$message .= 'If you have any further questions regarding this matter, please contact Devon Dick (<a href="mailto:devon@944.com">devon@944.com</a>).';
		
		emailNotification($user->userid,$subject,$message);
		
		if ($day_num == 18) {
			$jugger_message  = "<p>It is that time of the month again and we want to make sure that our magazines get out to all the ";
			$jugger_message .= "right people in $user->full_office_name, so we need you to submit your updates for distribution into Juggernaut.<br><a href=\"#\">Distribution Change Instructions</a></p>";
			juggerNotification($user->userid,$jugger_message);
		}
	}
	
}

##
## Upcoming PTO
## 
$sql = "
	SELECT users.userid, users.manager_id, vacation_date 
	FROM vacation_schedule 
		 INNER JOIN users ON vacation_schedule.userid = users.userid 
	WHERE DATE_SUB(vacation_schedule.vacation_date, INTERVAL 7 DAY) = '$year_num-$month_num-$day_num' 
		  AND vacation_schedule.manager_approved != '0000-00-00' 
		  AND vacation_schedule.hr_approved != '0000-00-00' 
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) {
	$user = mysql_fetch_object(mysql_query("SELECT * FROM users WHERE userid = ".$row->userid));
	$subject = "Upcoming PTO Notification";
	$message  = "Just wanted to give you a heads up that ".$user->fname." ".$user->lname." is scheduled for ";
	$message .= "PTO on ".date("m/d/Y", strtotime($row->vacation_date)).". Please make sure that the adequate ";
	$message .= "measures have been taken to insure that all work product has been completed prior to their departure.";
	
	emailNotification($row->manager_id,$subject,$message);
}

$sql = "
	SELECT users.userid, users.manager_id, vacation_date 
	FROM vacation_schedule 
		 INNER JOIN users ON vacation_schedule.userid = users.userid 
	WHERE DATE_SUB(vacation_schedule.vacation_date, INTERVAL 1 DAY) = '$year_num-$month_num-$day_num' 
		  AND vacation_schedule.manager_approved != '0000-00-00' 
		  AND vacation_schedule.hr_approved != '0000-00-00' 
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) {
	$user = mysql_fetch_object(mysql_query("SELECT * FROM users WHERE userid = ".$row->userid));
	$subject = "Upcoming PTO Notification";
	$message  = "Just wanted to give you a heads up that ".$user->fname." ".$user->lname." is scheduled for ";
	$message .= "PTO on ".date("m/d/Y", strtotime($row->vacation_date)).". Please make sure that the adequate ";
	$message .= "measures have been taken to insure that all work product has been completed prior to their departure.";
	emailNotification($row->manager_id,$subject,$message);
}

## 
## Birthday's 
##
$sql = "
	SELECT userid, 
		   CONCAT(fname, ' ', lname) AS 'name', 
		   dob, 
		   DATE_FORMAT(dob, '%m') AS 'birth_month', 
		   DATE_FORMAT(dob, '%d') AS 'birth_day', 
		   manager_id 
	FROM users 
	WHERE login = 1 
		  AND date_term = '0000-00-00' 
		  AND dob != '0000-00-00'
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) {
	if ($row->birth_month >= $month_num) { $birthday_year = date("Y"); } else { $birthday_year = date("Y")+1; }
	$birthday_unix = strtotime($birthday_year."-".$row->birth_month."-".$row->birth_day." 00:00:00");
	
	if ($birthday_unix == $today7_unix || $birthday_unix == $today1_unix) {
	
		$subject = "Upcoming Birthday Notification";
		$message  = "A reminder that ".$row->name." is having a birthday on ".date("m/d/Y", $birthday_unix).". ";
		$message .= "Please make sure to do something to acknowledge them on this special day.";
		
		emailNotification($row->manager_id,$subject,$message);
		
	}
}

##
## Anniversary's
##
$sql = "
	SELECT userid, 
		   CONCAT(fname, ' ', lname) AS 'name', 
		   date_hire, 
		   DATE_FORMAT(date_hire, '%m') AS 'anniv_month', 
		   DATE_FORMAT(date_hire, '%d') AS 'anniv_day', 
		   manager_id 
	FROM users 
	WHERE login = 1 
		  AND date_term = '0000-00-00' 
		  AND date_hire != '0000-00-00'
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) {
	if ($row->anniv_month >= $month_num) { $anniv_year = date("Y"); } else { $anniv_year = date("Y")+1; }
	$anniv_unix = strtotime($anniv_year."-".$row->anniv_month."-".$row->anniv_day." 00:00:00");
	
	if ($anniv_unix == $today7_unix || $anniv_unix == $today1_unix) {
	
		$subject = "Upcoming Anniversary Notification";		
		$message  = "A reminder that ".$row->name." is having an anniversary on ".date("m/d/Y", $anniv_unix).". ";
		$message .= "Please make sure to do something to acknowledge them on this special day.";
		
#		emailNotification($row->manager_id,$subject,$message);
		
	}
}

##
## Publisher Meeting
##
if (date("N", $today_unix) == 1) {
	
	foreach ($city_publishers as $user) { 
	
		$subject = "Publisher's Meeting Today";
		$message = "You have a publisher call this morning - call into 712.432.1549 access code: 778081# @ 8:30 am PST";
		
		emailNotification($user->userid,$subject,$message);
	}
	
}

## 
## Sales Meeting
##
if (date("N", $today_unix) == 1) {
	
	foreach ($sales as $user) { 
	
		$subject = "Sales Meeting Today";
		$message = "You have a general sales call today - call into 712.432.1690 access code 1009119# @ 9:30 am PST";
		
		emailNotification($user->userid,$subject,$message);
	}
	
}

## 
## SMS Codes & URL's in books
## 
if ($day_num == 20) {
	
	foreach ($city_directors as $user) {
	
		$issue = mysql_fetch_object(mysql_query("SELECT * FROM issues WHERE pubid = 1 AND iss_report_date = '".date("Y-m-d", $current_issue_date)."'"));
	
		$subject  = 'SMS/URL List Notification';
		$message  = "You have still not submitted your list of SMS codes and custom URL's to be programmed for the ".$issue->iss_name." ";
		$message .= "Issue. Please make sure these codes are submitted in a work order in Juggernaut.<br><br>";
		$message .= "<a href=\"https://944.myjuggernaut.com/home/filestructure/details/?FSID=355\">SMS/URL Work Order Instruction</a><br><br>";
		$message .= "If you need assistance in meeting this deadline, please contact Dee Ann David (<a href=\"mailto:dee@944.com\">dee@944.com</a>).";
		
		emailNotification($user->userid,$subject,$message);
		
		$sms_message  = "Please make sure your list of SMS codes and custom URL's are submitted for this issue in a work order ";
		$sms_message .= "in Juggernaut.";
		
		smsNotification($user->userid,$sms_message);
	
	}
	
}

## 
## Editorial (<= 5 Stories Due) 
##
if ($day_num == 2 || $day_num == 3 || $day_num == 4) {

	foreach ($editors as $user) {
		
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		$issue = mysql_fetch_object(mysql_query("SELECT issues.* FROM issues INNER JOIN pubs ON issues.pubid = pubs.id WHERE issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' AND pubs.nightsite_locale = ".$office->locale." AND online = 0"));
		
		$sql = "
			SELECT COUNT(*) AS 'row_count' 
			FROM (
				SELECT j.TID, oe.*, order_stat.status_def_name as status_def_name, pagenum, personnel_fname, personnel_lname, 
					   order_stat.status_def_color as status_def_color, concat_ws(' ',u.fname, u.lname) as assigned_name, order_stat.SDEFID
				FROM orders_editorial AS oe
					 INNER JOIN job_tickets AS j ON oe.editorialID =j.OTID
					 LEFT JOIN personnel p on oe.writerID = p.personnelID
					 LEFT JOIN (SELECT rsvItemID, mp.pagenum -1 AS pagenum, mbn.status AS pStatus
								FROM magbuilder_book_sections mbn
									 LEFT JOIN magbuilder_pages mp ON mp.id = mbn.pageID
								WHERE mbn.type = '3'
								GROUP BY rsvItemID) mpages on mpages.rsvItemID = oe.editorialID
					 LEFT JOIN (SELECT a.SDEFID, a.OTID, b.status_def_name, status_def_color
								FROM order_status a
									 INNER JOIN status_def b ON a.SDEFID = b.SDEFID
									 INNER JOIN(SELECT MAX( OSID ) OSID, OTID
												FROM order_status AS os
												WHERE os.OT = '3'
												GROUP BY OTID) status ON status.OSID =a.OSID) order_stat ON oe.editorialid = order_stat.OTID
					 LEFT JOIN users AS u ON oe.assigned=u.userid 
				WHERE j.OT='3' 
					  AND oe.issueID = ".$issue->id."  
					  AND oe.dead = 0 
					  AND oe.hidden = 0 
					  AND order_stat.SDEFID IN (15,18,47)) inner_table 
		";
		$row = mysql_fetch_object(mysql_query($sql));
		
		if ($row->row_count < 5) {
		
			$outstanding = (5 - $row->row_count);
			$due_in = (5 - $day_num);
			
			if ($outstanding > 1) { 
				$message = "You still have $outstanding stories outstanding for $office->full_office_name. ";
				$sms_message = $message;
				$jugger_message = $message;
			} else {
				$message  = "You still have $outstanding story outstanding for $office->full_office_name. ";
				$sms_message = $message;
				$jugger_message = "<p>".$message;
			}
			
			if ($due_in > 1) {
				$message .= "These are due in $due_in days. ";
			} else {
				$message .= "This is due in $due_in day. ";
			}
			
			$subject  = "Editorial Due (5 Stories) Notification";
			$message .= "Please make sure this information is uploaded by the 5th of the month.<br><br>";
			$message .= "<a href=\"https://944.myjuggernaut.com/home/filestructure/details/?FSID=168\">Editorial Upload Link</a><br><br>";
			$message .= "If you need assistance in meeting this deadline, please contact Dan Mitchell (dan@944.com).";
			
			emailNotification($user->userid,$subject,$message);
			
			if ($day_num == 3) {
				$sms_message .= "Please make sure this information is uploaded by the 5th of the month.";
				smsNotification($user->userid,$sms_message);
			}
			
			if ($day_num == 4) {
				$sms_message .= "Please make sure this information is uploaded by the 5th of the month.";
				smsNotification($user->userid,$sms_message);
				
				$jugger_message .= "Please make sure this information is uploaded by the 5th of the month.</p>";
				juggerNotification($user->userid,$jugger_message,6);
			}
		}
		
	}

}

## 
## Editorial (> 5 <= 10 Stories Due) 
##
if ($day_num == 7 || $day_num == 8 || $day_num == 9) {

	foreach ($editors as $user) {
		
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		$issue = mysql_fetch_object(mysql_query("SELECT issues.* FROM issues INNER JOIN pubs ON issues.pubid = pubs.id WHERE issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' AND pubs.nightsite_locale = ".$office->locale." AND online = 0"));
		
		$sql = "
			SELECT COUNT(*) AS 'row_count' 
			FROM (
				SELECT j.TID, oe.*, order_stat.status_def_name as status_def_name, pagenum, personnel_fname, personnel_lname, 
					   order_stat.status_def_color as status_def_color, concat_ws(' ',u.fname, u.lname) as assigned_name, order_stat.SDEFID
				FROM orders_editorial AS oe
					 INNER JOIN job_tickets AS j ON oe.editorialID =j.OTID
					 LEFT JOIN personnel p on oe.writerID = p.personnelID
					 LEFT JOIN (SELECT rsvItemID, mp.pagenum -1 AS pagenum, mbn.status AS pStatus
								FROM magbuilder_book_sections mbn
									 LEFT JOIN magbuilder_pages mp ON mp.id = mbn.pageID
								WHERE mbn.type = '3'
								GROUP BY rsvItemID) mpages on mpages.rsvItemID = oe.editorialID
					 LEFT JOIN (SELECT a.SDEFID, a.OTID, b.status_def_name, status_def_color
								FROM order_status a
									 INNER JOIN status_def b ON a.SDEFID = b.SDEFID
									 INNER JOIN(SELECT MAX( OSID ) OSID, OTID
												FROM order_status AS os
												WHERE os.OT = '3'
												GROUP BY OTID) status ON status.OSID =a.OSID) order_stat ON oe.editorialid = order_stat.OTID
					 LEFT JOIN users AS u ON oe.assigned=u.userid 
				WHERE j.OT='3' 
					  AND oe.issueID = ".$issue->id."  
					  AND oe.dead = 0 
					  AND oe.hidden = 0 
					  AND order_stat.SDEFID IN (15,18,47)) inner_table 
		";
		$row = mysql_fetch_object(mysql_query($sql));
		
		if ($row->row_count < 10) {
		
			$outstanding = (10 - $row->row_count);
			$due_in = (10 - $day_num);
			
			if ($outstanding > 1) { 
				$message = "You still have $outstanding stories outstanding for $office->full_office_name. ";
				$sms_message = $message;
				$jugger_message = $message;
			} else {
				$message  = "You still have $outstanding story outstanding for $office->full_office_name. ";
				$sms_message = $message;
				$jugger_message = "<p>".$message;
			}
			
			if ($due_in > 1) {
				$message .= "These are due in $due_in days. ";
			} else {
				$message .= "This is due in $due_in day. ";
			}
			
			$subject  = "Editorial Due (10 Stories) Notification";
			$message .= "Please make sure this information is uploaded by the 10th of the month.<br><br>";
			$message .= "<a href=\"https://944.myjuggernaut.com/home/filestructure/details/?FSID=168\">Editorial Upload Link</a><br><br>";
			$message .= "If you need assistance in meeting this deadline, please contact Dan Mitchell (dan@944.com).";
			
			emailNotification($user->userid,$subject,$message);
			
			if ($day_num == 8) {
				$sms_message .= "Please make sure this information is uploaded by the 10th of the month.";
				smsNotification($user->userid,$sms_message);
			}
			
			if ($day_num == 9) {
				$sms_message .= "Please make sure this information is uploaded by the 10th of the month.";
				smsNotification($user->userid,$sms_message);
				
				$jugger_message .= "Please make sure this information is uploaded by the 10th of the month.</p>";
				juggerNotification($user->userid,$jugger_message,6);
			}
		}
		
	}

}

## 
## Editorial (> 10 <= 15 Stories Due)
##
if ($day_num == 12 || $day_num == 13 || $day_num == 14) {

	foreach ($editors as $user) {
		
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		$issue = mysql_fetch_object(mysql_query("SELECT issues.* FROM issues INNER JOIN pubs ON issues.pubid = pubs.id WHERE issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' AND pubs.nightsite_locale = ".$office->locale." AND online = 0"));
		
		$sql = "
			SELECT COUNT(*) AS 'row_count' 
			FROM (
				SELECT j.TID, oe.*, order_stat.status_def_name as status_def_name, pagenum, personnel_fname, personnel_lname, 
					   order_stat.status_def_color as status_def_color, concat_ws(' ',u.fname, u.lname) as assigned_name, order_stat.SDEFID
				FROM orders_editorial AS oe
					 INNER JOIN job_tickets AS j ON oe.editorialID =j.OTID
					 LEFT JOIN personnel p on oe.writerID = p.personnelID
					 LEFT JOIN (SELECT rsvItemID, mp.pagenum -1 AS pagenum, mbn.status AS pStatus
								FROM magbuilder_book_sections mbn
									 LEFT JOIN magbuilder_pages mp ON mp.id = mbn.pageID
								WHERE mbn.type = '3'
								GROUP BY rsvItemID) mpages on mpages.rsvItemID = oe.editorialID
					 LEFT JOIN (SELECT a.SDEFID, a.OTID, b.status_def_name, status_def_color
								FROM order_status a
									 INNER JOIN status_def b ON a.SDEFID = b.SDEFID
									 INNER JOIN(SELECT MAX( OSID ) OSID, OTID
												FROM order_status AS os
												WHERE os.OT = '3'
												GROUP BY OTID) status ON status.OSID =a.OSID) order_stat ON oe.editorialid = order_stat.OTID
					 LEFT JOIN users AS u ON oe.assigned=u.userid 
				WHERE j.OT='3' 
					  AND oe.issueID = ".$issue->id."  
					  AND oe.dead = 0 
					  AND oe.hidden = 0 
					  AND order_stat.SDEFID IN (15,18,47)) inner_table 
		";
		$row = mysql_fetch_object(mysql_query($sql));
		
		if ($row->row_count < 15) {
		
			$outstanding = (15 - $row->row_count);
			$due_in = (15 - $day_num);
			
			if ($outstanding > 1) { 
				$message = "You still have $outstanding stories outstanding for $office->full_office_name. ";
				$sms_message = $message;
				$jugger_message = $message;
			} else {
				$message  = "You still have $outstanding story outstanding for $office->full_office_name. ";
				$sms_message = $message;
				$jugger_message = "<p>".$message;
			}
			
			if ($due_in > 1) {
				$message .= "These are due in $due_in days. ";
			} else {
				$message .= "This is due in $due_in day. ";
			}
			
			$subject  = "Editorial Due (15 Stories) Notification";
			$message .= "Please make sure this information is uploaded by the 15th of the month.<br><br>";
			$message .= "<a href=\"https://944.myjuggernaut.com/home/filestructure/details/?FSID=168\">Editorial Upload Link</a><br><br>";
			$message .= "If you need assistance in meeting this deadline, please contact Dan Mitchell (dan@944.com).";
			
			emailNotification($user->userid,$subject,$message);
			
			if ($day_num == 13) {
				$sms_message .= "Please make sure this information is uploaded by the 15th of the month.";
				smsNotification($user->userid,$sms_message);
			}
			
			if ($day_num == 14) {
				$sms_message .= "Please make sure this information is uploaded by the 15th of the month.";
				smsNotification($user->userid,$sms_message);
				
				$jugger_message .= "Please make sure this information is uploaded by the 15th of the month.</p>";
				juggerNotification($user->userid,$jugger_message,6);
			}
		}
		
	}

}

## 
## Picture Pages (<= 5 PP Due) 
##

## 
## Picture Pages (> 5 <= 10 PP Due) 
##

## 
## Picture Pages (> 10 <= 15 PP Due)
##

##
## Online Galleries (5 Galleries Due)
##
if ($day_num == 7 || $day_num == 14 || $day_num == 21 || $day_num == 28) {

	switch ($day_num) {
		case 7: $total_due = 5; break;
		case 14: $total_due = 10; break;
		case 21: $total_due = 15; break;
		case 28: $total_due = 20; break;
	}

	foreach ($editors as $user) {
		
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		
		$sql = "
			SELECT COUNT(*) AS 'row_count' 
			FROM 944web.nightsites 
			WHERE MONTH(944web.nightsites.date) = ".$month_num." 
				  AND YEAR(944web.nightsites.date) = ".$year_num."  
				  AND locale = ".$office->locale."  
				  AND active = 1
		";
		$row = mysql_fetch_object(mysql_query($sql));
		
		$total_remaining = $total_due - $row->row_count;
		if ($total_remaining < 0) { $total_remaining = 0; }
		
		if ($total_remaining > 0) { 
			if ($total_remaining == 1) { $gallery_text = "gallery"; $gallery_text2 = "this is"; } else { $gallery_text = "galleries"; $gallery_text2 = "these are"; }
			
			$subject  = "Online Galleries Due Notification";
			$message  = "Please log in to the administration center (https://944.com/_admin) and upload $total_remaining more ";
			$message .= "$gallery_text, as $gallery_text2 due today.<br><br>";
			$message .= "<a href=\"https://944.myjuggernaut.com/home/filestructure/details/?FSID=768\">Administation Center Upload Instructions</a><br><br>";
			
			emailNotification($user->userid,$subject,$message);
			
			$sms_message  = "Please log in to the administration center and upload $total_remaining more ";
			$sms_message .= "$gallery_text, as $gallery_text2 due today.";
			smsNotification($user->userid,$sms_message);
		}
	
	}

}

##
## Missing Ads
##

$artwork_day7 = strtotime("-7 days", $artwork_day_unix);
$artwork_day3 = strtotime("-3 days", $artwork_day_unix);
$artwork_day2 = strtotime("-2 days", $artwork_day_unix);
$artwork_day1 = strtotime("-1 day", $artwork_day_unix);

if ($today_unix == $day_after_print || $today_unix == $artwork_day7 || $today_unix == $artwork_day3 
	|| $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
	
	$pubs_sql = "
		SELECT 944web.locales.LID, 
			   944web.locales.name, 
			   SUM(artwork_in) AS 'artwork_in', 
			   SUM(artwork_out) AS 'artwork_out', 
			   SUM((artwork_in + artwork_out)) AS 'total_artwork' 
		FROM (
			SELECT pubs.id, 
				   SUM(CASE status.SDEFID WHEN 21 THEN 1 WHEN 76 THEN 1 ELSE 0 END) AS 'artwork_in', 
				   SUM(CASE status.SDEFID WHEN 21 THEN 0 WHEN 76 THEN 0 ELSE 1 END) AS 'artwork_out', 
				   SUM(CASE status.SDEFID WHEN 21 THEN CASE WHEN status.create_date <= issues.iss_artwork_date THEN 1 ELSE 0 END 
										  WHEN 76 THEN CASE WHEN status.create_date <= issues.iss_artwork_date THEN 1 ELSE 0 END 
									  	  ELSE 0 END) AS 'artwork_on_time'
			FROM orders_adsales 
				 INNER JOIN orders ON orders.OID = orders_adsales.OID
				 INNER JOIN company ON company.CID = orders.CID
				 INNER JOIN issues ON issues.id = orders_adsales.issueid 
				 INNER JOIN pubs ON pubs.id = issues.pubid 
				 INNER JOIN users ON users.userid = company.company_primary_rep 
				 LEFT JOIN (SELECT OTID, create_date, SDEFID
							FROM (SELECT job_tickets.OTID, max.create_date, status_def.status_def_name, status_def.SDEFID 
								  FROM job_tickets 
								 	   INNER JOIN order_status ON job_tickets.TID = order_status.OTID 
									   INNER JOIN (SELECT OTID, MAX(orderstatus_created_date) AS 'create_date' FROM order_status GROUP BY OTID) max 
										     ON order_status.OTID = max.OTID AND order_status.orderstatus_created_date = max.create_date
									   INNER JOIN status_def ON order_status.SDEFID = status_def.SDEFID) a  
							GROUP BY OTID, create_date, SDEFID) status ON orders_adsales.OAID = status.OTID 
			WHERE orders_adsales.kill = '0' 
			      AND orders.probability = 100 
			      AND issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' 
			      AND company.company_name NOT LIKE '944 WO%' 
			      AND pubs.isreport = 1 
			GROUP BY pubs.id ) numbers 
			INNER JOIN pubs ON numbers.id = pubs.id 
			INNER JOIN 944web.locales ON pubs.nightsite_locale = 944web.locales.LID 
		GROUP BY 944web.locales.LID, 944web.locales.name 
	";
	$pubs_query = mysql_query($pubs_sql);
	
	$pubs_artwork = array();
	while ($row = mysql_fetch_object($pubs_query)) {
		$pubs_artwork[$row->LID] = $row;
	}
	
	$reps_sql = "
		SELECT numbers.userid,
		  	   CONCAT(users.fname,' ',users.lname) AS 'rep_name', 
			   artwork_in, 
			   artwork_out, 
			   (artwork_in + artwork_out) AS 'total_artwork', 
			   (artwork_in / (artwork_in + artwork_out))*100 AS 'percent_in', 
			   (artwork_out / (artwork_in + artwork_out))*100 AS 'percent_out', 
			   (artwork_on_time / (artwork_in + artwork_out))*100 AS 'percent_on_time', 
			   users.associated_company 
		FROM (
			SELECT users.userid, 
				   SUM(CASE status.SDEFID WHEN 21 THEN 1 WHEN 76 THEN 1 ELSE 0 END) AS 'artwork_in', 
				   SUM(CASE status.SDEFID WHEN 21 THEN 0 WHEN 76 THEN 0 ELSE 1 END) AS 'artwork_out', 
				   SUM(CASE status.SDEFID WHEN 21 THEN CASE WHEN status.create_date <= issues.iss_artwork_date THEN 1 ELSE 0 END 
										  WHEN 76 THEN CASE WHEN status.create_date <= issues.iss_artwork_date THEN 1 ELSE 0 END 
									  	  ELSE 0 END) AS 'artwork_on_time'
			FROM orders_adsales 
				 INNER JOIN orders ON orders.OID = orders_adsales.OID
				 INNER JOIN company ON company.CID = orders.CID
				 INNER JOIN issues ON issues.id = orders_adsales.issueid 
				 INNER JOIN pubs ON pubs.id = issues.pubid 
				 INNER JOIN users ON users.userid = company.company_primary_rep 
				 LEFT JOIN (SELECT OTID, create_date, SDEFID
							FROM (SELECT job_tickets.OTID, max.create_date, status_def.status_def_name, status_def.SDEFID 
								  FROM job_tickets 
								 	   INNER JOIN order_status ON job_tickets.TID = order_status.OTID 
									   INNER JOIN (SELECT OTID, MAX(orderstatus_created_date) AS 'create_date' FROM order_status GROUP BY OTID) max 
										     ON order_status.OTID = max.OTID AND order_status.orderstatus_created_date = max.create_date
									   INNER JOIN status_def ON order_status.SDEFID = status_def.SDEFID) a  
							GROUP BY OTID, create_date, SDEFID) status ON orders_adsales.OAID = status.OTID 
			WHERE orders_adsales.kill = '0' 
			      AND orders.probability = 100 
			      AND issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' 
			      AND company.company_name NOT LIKE '944 WO%' 
			      AND pubs.isreport = 1 
			GROUP BY users.userid ) numbers 
			INNER JOIN users ON numbers.userid = users.userid
		ORDER BY rep_name 
	";
	$reps_query = mysql_query($reps_sql);
	
	$reps_artwork = array();
	while ($row = mysql_fetch_object($reps_query)) {
		$reps_artwork[$row->userid] = $row;
	}	
	foreach ($sales as $user) { 
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		
		if ($reps_artwork[$user->userid]->artwork_out > 0) {
			if ($reps_artwork[$user->userid]->artwork_out == 1) { $piece_text = "piece"; } else { $piece_text = "pieces"; }
			$subject  = 'Missing Ads Notification';
			$message  = 'You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
			$message .= 'Please make sure these files are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.<br><br>';
			$message .= '<a href="https://944.myjuggernaut.com/home/filestructure/details/?FSID=769">Artwork Upload Instructions</a><br><br>';
			$message .= 'If you need assistance in meeting this deadline, please contact Star Padilla (<a href="mailto:starpadilla@944.com">starpadilla@944.com</a>).';
			
			emailNotification($user->userid,$subject,$message);
			
			if ($today_unix == $day_after_print || $today_unix == $artwork_day3 || $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
				$sms_message  = 'You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
				$sms_message .= 'Please make sure these are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.';
				smsNotification($user->userid,$sms_message);
			}
			
			if ($today_unix == $day_after_print || $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
				$jugger_message  = '<p>You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
				$jugger_message .= 'Please make sure these are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.</p>';
				juggerNotification($user->userid,$jugger_message,6);
			}
		}
	}
	
	foreach ($city_directors as $user) { 
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		
		if ($pubs_artwork[$office->locale]->artwork_out > 0) {
			if ($reps_artwork[$user->userid]->artwork_out == 1) { $piece_text = "piece"; } else { $piece_text = "pieces"; }
			$subject  = 'Missing Ads Notification';
			$message  = 'You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
			$message .= 'Please make sure these files are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.<br><br>';
			$message .= '<a href="#">Artwork Upload Instructions</a><br><br>';
			$message .= 'If you need assistance in meeting this deadline, please contact Star Padilla (<a href="mailto:starpadilla@944.com">starpadilla@944.com</a>).';
			
			emailNotification($user->userid,$subject,$message);
			
			if ($today_unix == $day_after_print || $today_unix == $artwork_day3 || $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
				$sms_message  = 'You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
				$sms_message .= 'Please make sure these are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.';
				smsNotification($user->userid,$sms_message);
			}
			
			if ($today_unix == $day_after_print || $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
				$jugger_message  = '<p>You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
				$jugger_message .= 'Please make sure these are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.</p>';
				juggerNotification($user->userid,$jugger_message,6);
			}
		}
	}
	
	foreach ($city_publishers as $user) { 
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		
		if ($pubs_artwork[$office->locale]->artwork_out > 0) {
			if ($reps_artwork[$user->userid]->artwork_out == 1) { $piece_text = "piece"; } else { $piece_text = "pieces"; }
			$subject  = 'Missing Ads Notification';
			$message  = 'You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
			$message .= 'Please make sure these files are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.<br><br>';
			$message .= '<a href="#">Artwork Upload Instructions</a><br><br>';
			$message .= 'If you need assistance in meeting this deadline, please contact Star Padilla (<a href="mailto:starpadilla@944.com">starpadilla@944.com</a>).';
			
			emailNotification($user->userid,$subject,$message);
			
			if ($today_unix == $day_after_print || $today_unix == $artwork_day3 || $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
				$sms_message  = 'You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
				$sms_message .= 'Please make sure these are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.';
				smsNotification($user->userid,$sms_message);
			}
			
			if ($today_unix == $day_after_print || $today_unix == $artwork_day2 || $today_unix == $artwork_day1) {
				$jugger_message  = '<p>You still have '.$reps_artwork[$user->userid]->artwork_out.' '.$piece_text.' of artwork outstanding. ';
				$jugger_message .= 'Please make sure these are uploaded by '.date("m/d/Y", strtotime($prod_schedule->artwork_date)).'.</p>';
				juggerNotification($user->userid,$jugger_message,6);
			}
		}
	}
	
}

##
## Pagination
##
if ($today_unix == $monday_print_week) {

	foreach ($city_directors as $user) { 
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		$issue = mysql_fetch_object(mysql_query("SELECT issues.* FROM issues INNER JOIN pubs ON issues.pubid = pubs.id WHERE issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' AND pubs.nightsite_locale = ".$office->locale." AND online = 0"));
		
		$sql = "
			SELECT COUNT(magbuilder_book_sections.id) AS 'row_count'
			FROM magbuilder_pages 
				 INNER JOIN magbuilder_book_sections ON magbuilder_pages.id = magbuilder_book_sections.pageID 
			WHERE magbuilder_pages.bookID = ".$issue->id." 
				  AND magbuilder_book_sections.status != 'Confirmed'
	  			  AND magbuilder_book_sections.status != 'Placed'
		";
		$row = mysql_fetch_object(mysql_query($sql));
		
		if ($row->row_count > 0) {
			
			$subject  = 'Pagination Notification';
			$message  = 'You still have not paginated your magazine. This is DUE IN IMMEDIATELY. Please make sure this process has ';
			$message .= 'been completed by End Of Day (6 PM PST).<br><br>';
			$message .= 'If you need assistance in meeting this deadline, please contact Production (<a href="mailto:production@944.com">production@944.com</a>).';
			
			emailNotification($user->userid,$subject,$message);
			
			$sms_message  = 'You still have not paginated your magazine. This is DUE IN IMMEDIATELY. Please make sure this process has ';
			$sms_message .= 'been completed by End Of Day (6 PM PST).';
			
			smsNotification($user->userid,$sms_message);
			
			$jugger_message  = '<p>You still have not paginated your magazine. This is DUE IN IMMEDIATELY. Please make sure this process has ';
			$jugger_message .= 'been completed by End Of Day (6 PM PST).</p>';
			
			juggerNotification($user->userid,$jugger_message,6);
			
		}
	}
	
	foreach ($city_publishers as $user) { 
		$office = mysql_fetch_object(mysql_query("SELECT * FROM offices WHERE office_id = ".$user->office_id));
		$issue = mysql_fetch_object(mysql_query("SELECT issues.* FROM issues INNER JOIN pubs ON issues.pubid = pubs.id WHERE issues.iss_report_date = '".date("Y-m-d", $current_issue_date)."' AND pubs.nightsite_locale = ".$office->locale." AND online = 0"));
		
		$sql = "
			SELECT COUNT(magbuilder_book_sections.id) AS 'row_count'
			FROM magbuilder_pages 
				 INNER JOIN magbuilder_book_sections ON magbuilder_pages.id = magbuilder_book_sections.pageID 
			WHERE magbuilder_pages.bookID = ".$issue->id." 
				  AND magbuilder_book_sections.status != 'Confirmed'
	  			  AND magbuilder_book_sections.status != 'Placed'
		";
		$row = mysql_fetch_object(mysql_query($sql));
		
		if ($row->row_count > 0) {
			
			$subject  = 'Pagination Notification';
			$message  = 'You still have not paginated your magazine. This is DUE IN IMMEDIATELY. Please make sure this process has ';
			$message .= 'been completed by End Of Day (6 PM PST).<br><br>';
			$message .= 'If you need assistance in meeting this deadline, please contact Production (<a href="mailto:production@944.com">production@944.com</a>).';
			
			emailNotification($user->userid,$subject,$message);
			
			$sms_message  = 'You still have not paginated your magazine. This is DUE IN IMMEDIATELY. Please make sure this process has ';
			$sms_message .= 'been completed by End Of Day (6 PM PST).';
			
			smsNotification($user->userid,$sms_message);
			
			$jugger_message  = '<p>You still have not paginated your magazine. This is DUE IN IMMEDIATELY. Please make sure this process has ';
			$jugger_message .= 'been completed by End Of Day (6 PM PST).</p>';
			
			juggerNotification($user->userid,$jugger_message,6);
			
		}
	}

}

##
## House Ads
## 
if ($today_unix == $print_day_unix_prior7) {
	
	foreach ($city_directors as $user) { 
		
		$subject  = 'Filler/House Ads Notification';
		$message  = 'If you have any pages that have not been sold, comped or traded, you need to have a back up plan ';
		$message .= 'for what should be placed on this inventory. A back up plan is DUE IMMEDIATELY. Please make sure ';
		$message .= 'these files are uploaded.<br><br>';
		$message .= '<a href="#">Artwork Upload Instructions</a><br><br>';
		$message .= 'If you need assistance in meeting this deadline, please contact Star Padilla (<a href="mailto:starpadilla@944.com">starpadilla@944.com</a>).';
		
		emailNotification($user->userid,$subject,$message);
		
		$jugger_message  = '<p>If you have any pages that have not been sold, comped or traded, you need to have a back up plan ';
		$jugger_message .= 'for what should be placed on this inventory. A back up plan is DUE IMMEDIATELY. Please make sure ';
		$jugger_message .= 'these files are uploaded.<br>';
		$jugger_message .= '<a href="#">Artwork Upload Instructions</a></p>';
		
		juggerNotification($user->userid,$jugger_message,6);
		
	}
	
	foreach ($city_publishers as $user) { 
	
		$subject  = 'Filler/House Ads Notification';
		$message  = 'If you have any pages that have not been sold, comped or traded, you need to have a back up plan ';
		$message .= 'for what should be placed on this inventory. A back up plan is DUE IMMEDIATELY. Please make sure ';
		$message .= 'these files are uploaded.<br><br>';
		$message .= '<a href="#">Artwork Upload Instructions</a><br><br>';
		$message .= 'If you need assistance in meeting this deadline, please contact Star Padilla (<a href="mailto:starpadilla@944.com">starpadilla@944.com</a>).';
		
		emailNotification($user->userid,$subject,$message);
		
		$jugger_message  = '<p>If you have any pages that have not been sold, comped or traded, you need to have a back up plan ';
		$jugger_message .= 'for what should be placed on this inventory. A back up plan is DUE IMMEDIATELY. Please make sure ';
		$jugger_message .= 'these files are uploaded.<br>';
		$jugger_message .= '<a href="#">Artwork Upload Instructions</a></p>';
	
	}
	
}

## 
## Book Closing
## 
if ($today_unix == strtotime("-3 days", $closing_day) || $today_unix == strtotime("-2 days", $closing_day) || $today_unix == strtotime("-1 day", $closing_day)) {
	
	foreach ($all_employees as $user) { 
		$subject  = 'Book Closing Notification';
		$message  = 'Our books are closing this week. Please make sure that you have completed all your necessary ';
		$message .= 'responsibilities to assist in getting the books to press.';
			
		emailNotification($user->userid,$subject,$message);
		
		$sms_message  = 'Our books are closing this week. Please make sure that you have completed all your necessary ';
		$sms_message .= 'responsibilities to assist in getting the books to press.';
			
		smsNotification($user->userid,$sms_message);
	}
	
}

## 
## Function: emailNotification()
##
function emailNotification($userid,$subject,$message) {
	$real_userid = $userid;
	// $userid = 939;
	// $userid = 721;
	$user = mysql_fetch_object(mysql_query("SELECT * FROM users WHERE userid = $userid"));
	
	send_email("juggernaut@944.com", "Juggernaut", $user->email, $subject, $message);
	
	/*
	echo "Email: ".$user->email."\n";
	echo "Subject: $subject\n";
	echo "Message: $message\n\n";
	*/
	
	recordNotification(1,$real_userid,$subject,$message);
	
	return(true);
}

## 
## Function: juggerNotification()
##
function juggerNotification($userid,$message,$type=6) {
	$real_userid = $userid;
	// $userid = 939;
	// $userid = 721;
	$user = mysql_fetch_object(mysql_query("SELECT * FROM users WHERE userid = $userid"));
	
	$sql  = "INSERT INTO ic_notifications (userid, message, type, created) ";
	$sql .= "VALUES ($userid,'$message',$type,UNIX_TIMESTAMP())";
	$query = mysql_query($sql);
	
	/*
	echo "Jugger User: ".$user->email."\n";
	echo "Jugger Message: $message \n\n";
	*/
	
	recordNotification(2,$real_userid,'Juggernaut Notification',$message);
	
	return(true);
}

##
## Function: smsNotification()
##
function smsNotification($userid,$message) {
	$real_userid = $userid;
	// $userid = 939;
	// $userid = 721;
	$user = mysql_fetch_object(mysql_query("SELECT * FROM users WHERE userid = $userid AND allow_sms = 1"));

	if ($user->allow_sms == 1) {
		send_sms($user->phone_mobile,$message);
	}
	else {
		$message = 'User disabled SMS, would have sent: '.$message;
	}
	
	recordNotification(3,$real_userid,'SMS Message',$message);
	
	return(true);
} 

## 
## Function: recordNotification()
## 
function recordNotification($type,$userid,$title,$message) {
	$type = mysql_real_escape_string($type);
	$message = mysql_real_escape_string($message);
	
	$sql  = "INSERT INTO notification_messages (type,userid,title,message,notified) ";
	$sql .= "VALUES ($type,$userid,'$title','$message',UNIX_TIMESTAMP())";
	$query = mysql_query($sql);
	
	return(true);
}

?>
