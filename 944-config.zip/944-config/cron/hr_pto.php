#!/usr/bin/php -q
<?php
// Call with a parameter of either 'periodic' or 'attendance' to run the corresponding action, ie:
// php -q /var/www/html/com944x/cron/hr_pto.php periodic

// *** TO REMOVE:
// echo "Temporarily Disabled!";
// exit;


require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
include($_SERVER['DOCUMENT_ROOT']."/data/locales.php");
$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/templates/hr/pto/functions.php");

// Any time assign is called check to make sure periodic and attendance are only run once that day
if ($argv[1]) {
	$request = $argv[1];
}
else {
	echo "ERROR: Must be called with a parameter of either periodic or attendance! Exiting..";
	exit;
}

$duplicate_query = "SELECT request, time_run FROM vacation_run_log WHERE request = '".$request."' AND DATE(time_run) = DATE(now())";
$duplicate_result = mysql_query($duplicate_query);
$duplicate = mysql_fetch_assoc($duplicate_result);
// if ($duplicate) {
// 	echo "ERROR: ".$request." has already been run today at ".$duplicate['time_run'];
// 	// exit;
// }
// else {
// 	$run_insert = 1;
// }


// Insert request into vacation_run_log if run_insert is needed
if ($run_insert) {
	$insert_query = "INSERT INTO vacation_run_log SET ip = 'server cronjob', request = '".$request."', parameters = '".$request."'";
	mysql_query($insert_query);
	$vacation_run_log_id = mysql_insert_id();
}

echo "Proceeding with automated tasks..<br>";

// Only process payroll pto additions on 1st or 16th of the month; set to run daily at 5am via Windows Task Scheduler
if (date('d') == 1 || date('d') == 16) {
	$payroll_date = 1;
}

// Only process for employees who have been hired for one year or more (except for special cases); on their 90 day anniversary they get a full 80 hours assigned and no accrual until after 1 year (80 hours handled by the other periodic query). Set to run daily at 3am.
// Entire formula changed as of 2009-02-01, everyone accrues at 2.00 from now on
if ($request == 'periodic' && $payroll_date && date('Y-m-d') >= '2009-02-01') {
	$payroll_query = "SELECT userid, lname, DATEDIFF(now(), date_hire) AS days_hired FROM users WHERE emptype != '2' AND emptype != '3' AND emptype != '4' AND emptype != '6' AND date_hire != '0000-00-00' AND dead = '0' AND date_term = '0000-00-0000' AND date_hire IS NOT NULL AND date_hire < '".date('Y-m-d')."'";
	// echo $payroll_query;
	$payroll_result = mysql_query($payroll_query);
	while ($row = mysql_fetch_assoc($payroll_result)) {
		$years_hired = floor($row["days_hired"] / 365);

		// Changes from 2009-02-01 start
		if (true) {
			$accrual = '2.00';
		}
		// Changes from 2009-02-01 end

		// Set up special numbers for certain employees..

		// this used to be the start of the if, changed to elseif on 2009-02-01 to enable switching back to original system in the future
		elseif ($row["userid"] == 39 || $row["userid"] == 7 || $row["userid"] == 27 || $row["userid"] == 29 || $row["userid"] == 174 || $row["userid"] == 9 || $row["userid"] == 45 || $row["userid"] == 51 || $row["userid"] == 38 || $row["userid"] == 671 || $row["userid"] == 741 || $row["userid"] == 737) {
			$accrual = '3.34';
		}
		elseif ($row["userid"] == 180) {
			$accrual = '3.66';
		}
		elseif ($row["userid"] == 54 || $row["userid"] == 243) {
			$accrual = '5.00';
		}
// OLD system changes accrual rate after 3 years..
		elseif ($years_hired < 3) {
			$accrual = "1.67";
		}
		elseif ($years_hired >= 3) {
			$accrual = "3.34";
		}
// New system which Tim changed his mind about..
		// elseif ($years_hired == 0) {
		// 	$accrual = 0;
		// }
		// elseif ($years_hired == 1) {
		// 	$accrual = "3.34";
		// }
		// elseif ($years_hired >= 2 && $years_hired < 5) {
		// 	$accrual = "5.00";
		// }
		// elseif ($years_hired >= 5) {
		// 	$accrual = "6.67";
		// }
// New system which Tim changed his mind about..
		// else {
		// 	$accrual = 0;
		// }
		else {
			$accrual = '1.67';
		}

		if ($accrual) {
			// echo $row['userid'].' '.$accrual."\n";
			add_time($row["userid"], $accrual, "Periodic Increase", $years_hired, NULL, "pto");
		}
	}
}

// Add full PTO time for employees on their 90 day (and yearly per old system) anniversaries; set to run daily at 3am
// DISABLED as of 2009-02-01 per new rules [EJC]
if ($request == 'periodic' && date('Y-m-d') < '2009-02-01') {
	// Old code from when PTO was assigned in full on 90 day and yearly anniversaries
	$periodic_query = "SELECT userid, DATEDIFF(now(), date_hire) AS days_hired FROM users WHERE emptype != '2' AND emptype != '3' AND emptype != '4' AND emptype != '6' AND date_hire != '0000-00-00' AND date_term = '0000-00-0000' AND date_hire IS NOT NULL AND (DATEDIFF(now(), date_hire) = 90 OR (DAY(date_hire) = DAY(now()) AND MONTH(date_hire) = MONTH(now()) AND YEAR(date_hire) != YEAR(now())))";
// New code, disabled per Tim..
	// $periodic_query = "SELECT userid, DATEDIFF(now(), date_hire) AS days_hired, YEAR(now()) - YEAR(date_hire) AS years_hired FROM users WHERE emptype != '2' AND emptype != '3' AND emptype != '6' AND date_hire != '0000-00-00' AND date_term = '0000-00-0000' AND date_hire IS NOT NULL AND DATEDIFF(now(), date_hire) = 90";
	$periodic_result = mysql_query($periodic_query);
	while ($row = mysql_fetch_assoc($periodic_result)) {
		// Set up $years_hired
		$years_hired = floor($row["days_hired"] / 365);
		// New system is 80, old is 40..
		if ($row["days_hired"] == 90) {
			add_time($row["userid"], "48", "90 Day PTO Adjustment", $years_hired, NULL, "sick");
		}
		// Reinstated temporarily.. comment out all of the following to go back to periodic only (other than 90 day)
		// Removed yearly adjustments, now done in periodic increases..
		elseif ($years_hired >= 1) {
			add_time($row["userid"], "48", "Annual PTO Adjustment", $years_hired, NULL, "sick");
		}
		// elseif ($years_hired == 1 | $years_hired == 2) {
		// 	add_time($row["userid"], "48", "Annual PTO Adjustment", $years_hired);
		// }
		// elseif ($years_hired >= 3 && $years_hired <= 9) {
		// 	add_time($row["userid"], "80", "Annual PTO Adjustment", $years_hired);
		// }
		// elseif ($years_hired >= 10) {
		// 	add_time($row["userid"], "120", "Annual PTO Adjustment", $years_hired);
		// }			
	}
}


// Trim off all employees' extra PTO that's not allowed in the new system - ONLY RUN ONCE, on 2020-01-01; can remove afterwards; set to run daily at 3am
if ($request == 'periodic' && date('Y-m-d') == '2020-01-01') {
	$periodic_query = "SELECT userid, DATEDIFF(now(), date_hire) AS days_hired FROM users WHERE emptype != '2' AND emptype != '3' AND emptype != '4' AND emptype != '6' AND date_hire != '0000-00-00' AND date_term = '0000-00-0000' AND date_hire IS NOT NULL AND (DATEDIFF(now(), date_hire) > 90)";
	$periodic_result = mysql_query($periodic_query);
	while ($row = mysql_fetch_assoc($periodic_result)) {
		// Set up $years_hired
		$years_hired = floor($row["days_hired"] / 365);

		if ($years_hired == 0) {
			add_time($row["userid"], "0", "New PTO Policy Change", $years_hired);
		}
		elseif ($years_hired == 1) {
			add_time($row["userid"], "0", "New PTO Policy Change", $years_hired);
		}
		elseif ($years_hired >= 2 && $years_hired < 5) {
			add_time($row["userid"], "0", "New PTO Policy Change", $years_hired);
		}
		elseif ($years_hired >= 5) {
			add_time($row["userid"], "0", "New PTO Policy Change", $years_hired);
		}			
	}
}

// Deduct PTO if employee failed to log in to Juggernaut, needs to be run after 1pm (13:00 hours); set to run Monday-Friday at 3pm
// Includes check in month_days table to make sure the day wasn't a holiday
if ($request == 'attendance' && date('G') > 13 && date('N') >= 1 && date('N') <= 5) {
	$attendance_query = "SELECT userid, associated_company FROM users WHERE userid NOT IN (SELECT userid from user_logins where login_date = '".date('Y-m-d')."') AND date_term = '0000-00-00' AND dead != '1' AND emptype NOT IN (2, 3, 4, 5, 6) AND date_hire != '0000-00-00' AND date_hire <= '".date('Y-m-d')."' AND userid NOT IN (SELECT userid FROM vacation_schedule WHERE vacation_date = '".date('Y-m-d')."' AND hr_approved != '0000-00-00' AND hr_approved != '9999-12-31') AND '".date('Y-m-d')."' NOT IN (SELECT month_day FROM month_days WHERE type='holiday') AND userid NOT IN (28)";
	// echo $attendance_query;
	$attendance_result = mysql_query($attendance_query);
	while ($row = mysql_fetch_assoc($attendance_result)) {
		// No longer subtracts PTO hours per Tim [EJC 2008-11-06], just warns HR (taken care of in functions.php)
		// Added a check to disable this from showing up for all Six Degrees employees (associated_company = 2) until after 2009-04-01
		if (($row['associated_company'] == 2 && date('Y-m-d') >= '2009-04-01') || $row['associated_company'] == 1) {
			$insert_query = schedule_vacation_query($row['userid'], '', date('Y-m-d'), date('Y-m-d'), 0, 'Failed to login to Juggernaut', 'no_login', 'full', '', date('Y-m-d'), '', 'Automatic run for user not logging in', 8);
			mysql_query($insert_query);

			$vacation_id = mysql_insert_id();
			process_vacation_schedule($vacation_id);

			# Old version, which didn't track in Juggs properly
			// add_time($row["userid"], "-8", "Failed to login to Juggernaut", NULL, NULL, "pto");
		}
	}
}

// Deduct PTO if the person took off this day
$todays_pto_query = "SELECT * FROM vacation_schedule WHERE vacation_date <= DATE(NOW()) AND user_canceled = '0000-00-00' AND hr_canceled = '0000-00-00' AND hr_approved != '0000-00-00' AND hr_approved != '9999-12-31' AND manager_approved != '9999-12-31' AND deducted = '0000-00-00' ORDER BY vacation_date";
$todays_pto_result = mysql_query($todays_pto_query);
while ($row = mysql_fetch_assoc($todays_pto_result)) {
	process_vacation_schedule($row['id']);
}


?>
