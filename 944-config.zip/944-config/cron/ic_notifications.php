<?php

##
## Info Center Notifications
##

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");

##
## Clients assigned to inactive reps
##

$publisher_sql = "SELECT userid, offices.locale FROM users INNER JOIN offices ON users.userid = offices.o_publisher AND offices.office_id != 11";
$publisher_query = mysql_query($publisher_sql);

while ($publisher_row = mysql_fetch_object($publisher_query)) { 
	$sql = "
		SELECT COUNT(*) AS 'row_count' 
		FROM (SELECT CID, 
				     company_name, 
				     944web.locales.name AS 'market_name', 
				     assigned.userid AS 'assigned_userid', 
				     CONCAT(assigned.fname, ' ', assigned.lname) AS 'assigned_employee', 
				     publisher.userid AS 'publisher_userid', 
				     CONCAT(publisher.fname, ' ', publisher.lname) AS 'publisher', 
				     company_categories.name AS 'category' 
			  FROM company 
				   LEFT JOIN 944web.locales ON company.market = 944web.locales.LID 
				   INNER JOIN users AS assigned ON company.company_primary_rep = assigned.userid 
				   INNER JOIN offices ON 944web.locales.LID = offices.locale 
				   INNER JOIN users AS publisher ON offices.o_publisher = publisher.userid 
				   INNER JOIN company_categories ON company.CATID = company_categories.id 
			  WHERE company_primary_rep IN (SELECT userid FROM users WHERE date_term != '0000-00-00' AND login = 0) 
				    AND offices.office_id != 11 
				    AND company.dead = 0 
				    AND TRIM(company.company_name) != '' 
				    AND publisher.userid = ".$publisher_row->userid.") inner_table 
	";
	$query = mysql_query($sql);
	$data = mysql_fetch_object($query);
	
	if ($data->row_count>0) {
	
		mysql_query("DELETE FROM ic_notifications WHERE userid = ".$row->userid." AND type = 1");
	
		$message  = '<p>You have <strong>'.$data->row_count.' accounts</strong> in your market that are assigned to inactive reps.<br>';
		$message .= '<a href="/reports/?market='.$publisher_row->locale.'&rid=64&show=1">Resolve This Now</a>';
		$message = mysql_real_escape_string($message);
	
		$insert_sql = "INSERT INTO ic_notifications (userid, message, type, created) VALUES (".$publisher_row->userid.", '$message', 1, UNIX_TIMESTAMP())";
		$insert_query = mysql_query($insert_sql);
	}
}

##
## Clients not touched in 30 days
## 
$users_sql = "SELECT userid FROM users WHERE login = 1 AND date_term = '0000-00-00'";
$users_query = mysql_query($users_sql);

while ($users_row = mysql_fetch_object($users_query)) {
	
	$sql = "
	
		SELECT COUNT(*) AS 'row_count'
		FROM (SELECT company.CID, 
				     company.company_name, 
				     company_categories.name AS 'category', 
				     IFNULL(activity_note.last_note,'No Notes') AS 'last_note'
			  FROM company 
				   INNER JOIN company_categories ON company.CATID = company_categories.id 
				   LEFT JOIN (SELECT company.CID, MAX(activity.activity_created) AS 'last_note'
							  FROM activity 
								   INNER JOIN contacts ON activity.IID = contacts.IID
								   INNER JOIN company ON contacts.CID = company.CID 
							  WHERE activity.activity_type = 0 
								    AND company.company_primary_rep = ".$users_row->userid."  
							  GROUP BY company.CID) activity_note 
				   ON company.CID = activity_note.CID 
			  WHERE company.company_primary_rep = ".$users_row->userid." 
				    AND company.dead = 0 
				    AND DATEDIFF(NOW(), IFNULL(activity_note.last_note,'1969-12-31')) > 30) inner_table 
	
	";
	$query = mysql_query($sql);
	$data = mysql_fetch_object($query);
	
	if ($data->row_count > 0) {
		if ($data->row_count == 1) { $a_text = 'account'; } else { $a_text = 'accounts'; }
		
		mysql_query("DELETE FROM ic_notifications WHERE userid = ".$users_row->userid." AND type = 3");
	
		$message  = '<p>You have <strong>'.$data->row_count.' '.$a_text.'</strong> assigned to you without an updated note in over 30 days.<br>';
		$message .= '<a href="/reports/?rid=65">Resolve This Now</a>';
		$message = mysql_real_escape_string($message);
	
		$insert_sql = "INSERT INTO ic_notifications (userid, message, type, created) VALUES (".$users_row->userid.", '$message', 3, UNIX_TIMESTAMP())";
		$insert_query = mysql_query($insert_sql);
	}
	
}

##
## Expiring accounts
##
$sql = "
	SELECT userid, COUNT(*) AS 'row_count' 
	FROM (SELECT company.CID, 
			     company.company_name, 
			     issue_max.last_issue, 
			     users.userid, 
			     CONCAT(users.fname, ' ', users.lname) AS 'sales_rep', 
			     DATEDIFF(issue_max.last_issue, NOW()) AS 'days_to_expire' 
		  FROM company 
			   INNER JOIN users ON company.company_primary_rep = users.userid 
			   INNER JOIN (SELECT company.CID, MAX(issues.iss_report_date) AS 'last_issue' 
						   FROM orders_adsales 
							    INNER JOIN issues ON orders_adsales.issueid = issues.id 
							    INNER JOIN orders ON orders_adsales.OID = orders.OID 
							    INNER JOIN company ON orders.CID = company.CID 
						   GROUP BY company.CID 
						   HAVING MAX(issues.iss_report_date) >= '2009-11-01') issue_max ON company.CID = issue_max.CID 
		  WHERE DATEDIFF(issue_max.last_issue, NOW()) <= 90 
		  	    AND users.login = 1 
		  	    AND users.date_term = '0000-00-00') inner_table 
	GROUP BY userid 
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) { 
	if ($row->row_count > 0) {
		if ($row->row_count == 1) { $a_text = 'contract'; } else { $a_text = 'contracts'; }
		
		mysql_query("DELETE FROM ic_notifications WHERE userid = ".$row->userid." AND type = 2");
	
		$message  = '<p>You have <strong>'.$row->row_count.' '.$a_text.'</strong> that are expiring within 90 days.<br>';
		$message .= '<a href="/reports/?rid=66">Resolve This Now</a>';
		$message = mysql_real_escape_string($message);
	
		$insert_sql = "INSERT INTO ic_notifications (userid, message, type, created) VALUES (".$row->userid.", '$message', 2, UNIX_TIMESTAMP())";
		$insert_query = mysql_query($insert_sql);
	}
}

##
## Clients missing information 
##
$sql = "
	SELECT company_primary_rep AS 'userid', COUNT(*) AS 'row_count' 
	FROM (SELECT company.CID, 
			     company.company_name, 
			     contacts.IID, 
			     CONCAT(contacts.contact_firstname, ' ', contacts.contact_lastname) AS 'contact_name', 
			     contacts.contact_phone_office, 
			     contacts.contact_phone_cell, 
			     contacts.contact_phone_alt, 
			     contacts.contact_email, 
			     company.company_primary_rep 
		  FROM company 
			   INNER JOIN contacts ON company.CID = contacts.CID 
		  WHERE (TRIM(contacts.contact_phone_office) = '' 
			    OR TRIM(contacts.contact_phone_cell) = '' 
			    OR TRIM(contacts.contact_phone_alt) = '' 
			    OR TRIM(contacts.contact_email) = '') 
			    AND company.dead = 0) inner_table 
	GROUP BY company_primary_rep
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) { 
	if ($row->row_count > 0) {
		if ($row->row_count == 1) { $a_text = 'contact'; } else { $a_text = 'contacts'; }
		
		mysql_query("DELETE FROM ic_notifications WHERE userid = ".$row->userid." AND type = 4");
	
		$message  = '<p>You have <strong>'.$row->row_count.' '.$a_text.'</strong> that are missing important contact information (phone/email).<br>';
		$message .= '<a href="/reports/?rid=67">Resolve This Now</a>';
		$message = mysql_real_escape_string($message);
	
		$insert_sql = "INSERT INTO ic_notifications (userid, message, type, created) VALUES (".$row->userid.", '$message', 4, UNIX_TIMESTAMP())";
		$insert_query = mysql_query($insert_sql);
	}
}

##
## Tasks Due in 7 Days
##
$sql = "
	SELECT owner_userid AS 'userid', COUNT(task_id) AS 'row_count' 
	FROM tasks 
	WHERE dead = 0 
		 AND duedate BETWEEN DATE_FORMAT(NOW(),'%Y-%m-%d') AND DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 7 DAY),'%Y-%m-%d') 
		 AND parent_taskid = 0 
	GROUP BY owner_userid
";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) { 
	if ($row->row_count > 0) {
		if ($row->row_count == 1) { $a_text = 'task'; } else { $a_text = 'tasks'; }
		
		mysql_query("DELETE FROM ic_notifications WHERE userid = ".$row->userid." AND type = 5");
	
		$message  = '<p>You have <strong>'.$row->row_count.' '.$a_text.'</strong> due in the next 7 days.<br>';
		$message .= '<a href="/projects/">Resolve This Now</a>';
		$message = mysql_real_escape_string($message);
	
		$insert_sql = "INSERT INTO ic_notifications (userid, message, type, created) VALUES (".$row->userid.", '$message', 5, UNIX_TIMESTAMP())";
		$insert_query = mysql_query($insert_sql);
	}
}

?>