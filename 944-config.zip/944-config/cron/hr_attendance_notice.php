<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/phpmailer.php");

// Only run query Monday-Friday, and on non-holidays (all taken care of in the SQL query):
	$query = "SELECT userid, fname, lname, email, associated_company
				FROM users 
				WHERE login = '1' AND emptype = '1' AND dead = '0' AND date_term = '0000-00-00' AND 
					userid NOT IN (SELECT userid FROM user_logins WHERE login_date = DATE(now())) AND 
					DATE(now()) NOT IN (SELECT month_day FROM month_days WHERE type='holiday') AND 
					DATE(now()) NOT IN (SELECT vacation_date FROM vacation_schedule WHERE userid = users.userid AND hr_approved != '0000-00-00' AND user_canceled = '0000-00-00' AND hr_canceled = '0000-00-00') AND
					(DAYOFWEEK(now()) BETWEEN 2 AND 6)";
	$rs = mysql_query($query);

	while ($row = mysql_fetch_assoc($rs)) {
		// Added a check to disable this from showing up for all Six Degrees employees (associated_company = 2) until after 2009-04-01
		if (($row['associated_company'] == 2 && date('Y-m-d') >= '2009-04-01') || $row['associated_company'] == 1) {
			if($row['email'] != "") {
					$mail = new PHPMailer();
					$mail->From = "hr@944.com";
					$mail->AddAddress ($row['email']);
					$mail->AddCC("hr@944.com");
						// $mail->AddCC($rowSend['repemail']);		
					$mail->IsHTML(true);
					$mail->FromName = "944 HR";
					$mail->Subject = "Attendance - Are you present?";
					$mail->Body = "<p>".$row['fname']." ".$row['lname'].":</p> \n
		<p>You have not yet clocked in today, but do not have an approved day off.</p>
		<p><b>Logging in is not the same as clocking in!</b></p>
		<p>To clock in (or double check to make sure that you have already done so), please go to:</p>
		<p><a href=\"https://944.myjuggernaut.com/hr/clockin/\">944.myjuggernaut.com/hr/clockin/</a> and follow the instructions on the page.</p>
		\n
		Thank you,
		\n
		HR ";
					$mail->Send();
					echo "E-mail sent to ".$row['email']. " successfully for ".$row['fname']." ".$row['lname'].".<br>";
			}		
		}
	}

mysql_close();
?>
