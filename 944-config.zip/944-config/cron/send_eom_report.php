<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

$year_month = date('Y-m');
$eom_date = $year_month.'-01';
$eom_date_end = $year_month.'-05';
//$eom_date = '2009-07-01';
$output = '';
$title = 'Employee of the Month Report for '.$eom_date;

function eom_winners ($eom_date, $type='corp') {
	$winners_query = "SELECT CONCAT(u.fname, ' ', u.lname) AS full_name, count(emp_".$type."_id) AS votes FROM 944x_944media.eom_results AS eom LEFT JOIN 944x_944media.users AS u ON u.userid = eom.emp_".$type."_id WHERE eom_date = '".$eom_date."' GROUP BY emp_".$type."_id ORDER BY votes DESC, fname, lname";
	$winners_result = mysql_query($winners_query);
	$output .= '<h3>'.ucfirst($type).' Employee of the Month Results</h3>';

	$output .= '<table border=0 cellspacing=0 cellpadding=2>';
	$output .= '<tr>';
	$output .= '<td><b>Votes</b></td>';
	$output .= '<td><b>Name</b></td>';
	while ($row = mysql_fetch_assoc($winners_result)) {
		$output .= '<tr>';
		$output .= '<td align="center">' .$row['votes']. '</td>';
		$output .= '<td>' .stripslashes($row['full_name']). '</td>';
		$output .= '</tr>';
	}
	$output .= '</table>';
	return $output;
}

$output .= '<h3>'.$title.'</h3>';

$output .= eom_winners($eom_date, 'corp');
$output .= eom_winners($eom_date, 'local');

$output .= '<h3>Detailed Results</h3>';

$details_query = "SELECT CONCAT(respondent.fname, ' ', respondent.lname) AS respondent_name, CONCAT(corp.fname, ' ', corp.lname) AS corp_name, CONCAT(local.fname, ' ', local.lname) AS local_name, eom.* FROM 944x_944media.eom_results AS eom LEFT JOIN 944x_944media.users AS respondent ON respondent.userid = eom.respondent_id LEFT JOIN 944x_944media.users AS corp ON corp.userid = eom.emp_corp_id LEFT JOIN 944x_944media.users AS local ON local.userid = eom.emp_local_id WHERE eom_date = '".$eom_date."' ORDER BY respondent.fname, respondent.lname";
$details_result = mysql_query($details_query);
while ($row = mysql_fetch_assoc($details_result)) {
	$output .= '<h4>'.$row['respondent_name'].'</h4>';
	$output .= 'Corp vote: '.$row['corp_name'].'<br>';
	$output .= '"' .stripslashes($row['emp_corp_why']). '"';
	$output .= '<br><br>';
	$output .= 'Local vote: '.$row['local_name'].'<br>';
	$output .= '"' .stripslashes($row['emp_local_why']). '"';
	$output .= '<br><br>';
}

$output .= '<h3>Employees Who Didn\'t Vote</h3>';

$didnt_vote_query = "SELECT CONCAT(fname, ' ', lname) AS full_name FROM 944x_944media.users WHERE date_hire != '0000-00-00' AND date_hire <= '".$eom_date_end."' AND (date_term = '0000-00-00' OR date_term >= '".$eom_date."') AND userid NOT IN (SELECT respondent_id FROM 944x_944media.eom_results WHERE eom_date = '".$eom_date."') AND dead = 0 AND emptype = '1' ORDER BY fname, lname";
$didnt_vote_result = mysql_query($didnt_vote_query);
while ($row = mysql_fetch_assoc($didnt_vote_result)) {
	$output .= stripslashes($row['full_name']).'<br>';
}

echo $output;
send_email('juggernaut@944.com', 'Juggernaut', 'hr@944.com,dee@944.com,marc@944.com,emmanuel@944.com', $title, $output);
//send_email('juggernaut@944.com', 'Juggernaut', 'emmanuel@944.com', $title, $output);

?>
