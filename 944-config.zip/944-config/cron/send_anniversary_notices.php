<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

// Changed to notify HR 3 days before the person's anniversary

// $anniversary_query = "SELECT *, YEAR(date_hire) AS start_year, DATEDIFF(NOW(), DATE(date_hire)) AS days_employed FROM 944x_944media.users WHERE ((MONTH(date_hire) = MONTH(now()) AND DAY(date_hire) = DAY(now()) AND YEAR(date_hire) != YEAR(now())) OR DATEDIFF(NOW(), DATE(date_hire)) = 90) AND login = '1' AND dead = '0' AND date_term = '0000-00-00'";

// $anniversary_query = "SELECT *, YEAR(date_hire) AS start_year, DATEDIFF(NOW(), DATE(date_hire)) AS days_employed FROM 944x_944media.users WHERE ((MONTH(DATE_SUB(date_hire, INTERVAL 3 DAY)) = MONTH(NOW()) AND DAY(DATE_SUB(date_hire, INTERVAL 3 DAY)) = DAY(NOW()) AND YEAR(DATE_SUB(date_hire, INTERVAL 3 DAY)) != YEAR(NOW())) OR DATEDIFF(NOW(), DATE(DATE_SUB(date_hire, INTERVAL 3 DAY))) = 90) AND login = '1' AND dead = '0' AND date_term = '0000-00-00'";

$anniversary_query = "SELECT u.fname, u.lname, u.email, u.date_hire, m.email AS manager_email, YEAR(u.date_hire) AS start_year, DATEDIFF(NOW(), DATE(u.date_hire)) AS days_employed FROM 944x_944media.users AS u LEFT JOIN 944x_944media.users AS m ON m.userid = u.manager_id WHERE ((MONTH(DATE_SUB(u.date_hire, INTERVAL 3 DAY)) = MONTH(NOW()) AND DAY(DATE_SUB(u.date_hire, INTERVAL 3 DAY)) = DAY(NOW()) AND YEAR(DATE_SUB(u.date_hire, INTERVAL 3 DAY)) != YEAR(NOW())) OR DATEDIFF(NOW(), DATE(DATE_SUB(u.date_hire, INTERVAL 3 DAY))) = 90) AND u.login = '1' AND u.dead = '0' AND u.emptype = '1' AND u.date_term = '0000-00-00'";

$anniversary_result = mysql_query($anniversary_query);
while ($row = mysql_fetch_assoc($anniversary_result)) {
	if ($row['days_employed'] > 90) {
		$period = date('Y') - $row['start_year'];
		$period_type = 'year';
		if ($period > 1) {
			$period_type .= 's';
		}
		$to_email = 'hr@944.com,marc@944.com,emmanuel@944.com,'.$row['manager_email'];
	}
	else {
		$period = $row['days_employed'] + 3;
		$period_type = 'days';
		$to_email = 'hr@944.com, emmanuel@944.com,'.$row['manager_email'];
	}
	$name = stripslashes($row['fname'])." ".stripslashes($row['lname']);
	$title = "Anniversary Notification: ".$name;
	$body = "Back on ".$row['date_hire'].", ".$period." ".$period_type." ago, <a href='mailto:".$row['email']."'>".$name."</a> started working at 944.";
	echo $body;
	send_email('juggernaut@944.com', 'Juggernaut', $to_email, $title, $body);
	// send_email('juggernaut@944.com', 'Juggernaut', 'emmanuel@944.com,', $title, $body);
}


// Also send day-of per HR's request

$anniversary_query = "SELECT u.*, m.email AS manager_email, YEAR(u.date_hire) AS start_year, DATEDIFF(NOW(), DATE(u.date_hire)) AS days_employed FROM 944x_944media.users AS u LEFT JOIN 944x_944media.users AS m ON m.userid = u.manager_id WHERE ((MONTH(u.date_hire) = MONTH(NOW()) AND DAY(u.date_hire) = DAY(NOW()) AND YEAR(u.date_hire) != YEAR(now())) OR DATEDIFF(NOW(), DATE(u.date_hire)) = 90) AND u.login = '1' AND u.dead = '0' AND u.emptype = '1' AND u.date_term = '0000-00-00'";

$anniversary_result = mysql_query($anniversary_query);
while ($row = mysql_fetch_assoc($anniversary_result)) {
	if ($row['days_employed'] > 90) {
		$period = date('Y') - $row['start_year'];
		$period_type = 'year';
		if ($period > 1) {
			$period_type .= 's';
		}
		$to_email = 'hr@944.com,marc@944.com,emmanuel@944.com,'.$row['manager_email'];
	}
	else {
		$period = $row['days_employed'];
		$period_type = 'days';
		$to_email = 'hr@944.com, emmanuel@944.com,'.$row['manager_email'];
	}
	$name = stripslashes($row['fname'])." ".stripslashes($row['lname']);
	$title = "Anniversary Notification: ".$name;
	$body = "Back on ".$row['date_hire'].", ".$period." ".$period_type." ago, <a href='mailto:".$row['email']."'>".$name."</a> started working at 944.";
	echo $body;
	send_email('juggernaut@944.com', 'Juggernaut', $to_email, $title, $body);
	// send_email('juggernaut@944.com', 'Juggernaut', 'emmanuel@944.com,', $title, $body);
}

?>
