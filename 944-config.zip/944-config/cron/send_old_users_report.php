<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

$bad_people = array();

$users_query = "SELECT userid FROM users WHERE emptype <= 4 AND login = '1' AND dead = '0'";
$users_result = mysql_query($users_query);
while ($row = mysql_fetch_object($users_result)) {
	$no_login_query = "SELECT DATEDIFF(NOW(), l.login_date) AS days_since_login, l.login_date AS last_login, u.userid, u.email, CONCAT(u.fname, ' ', u.lname) AS user_name, u.office_id, u.dept_id, u.title, u.positions_id, m.email AS manager_email, c.email AS city_director_email, o.full_office_name FROM users AS u LEFT JOIN user_logins AS l ON l.userid = u.userid LEFT JOIN users AS m ON m.userid = u.manager_id LEFT JOIN offices AS o ON o.office_id = u.office_id LEFT JOIN users AS c ON c.userid = o.o_contact WHERE u.userid = $row->userid ORDER BY l.login_date DESC LIMIT 1";
	$no_login_result = mysql_query($no_login_query);
	while ($data = mysql_fetch_object($no_login_result)) {
		if ($data->days_since_login > 10) {
			$email = $data->manager_email;
			
			if (!$email) {
				$email = $data->city_director_email;
			}
			
			$bad_people[$email][] = $data;

			# Notify HR if it's been more than 30 days
			if ($data->days_since_login >= 30) {
				$bad_people['hr@944.com'][] = $data;
			}
		}
	}
}

$title = "Inactive Juggernaut Account Notice";
foreach ($bad_people as $email => $people_array) {
	$output = "<p>The following users have not clocked in to Juggernaut for more than 10 days. Please review this list, and if they are no longer current employees or interns, please create an HR ticket to have their account closed out. Thank you!</p>\n\n";
	foreach ($people_array as $key => $details) {
		$output .= "$details->user_name ($details->email) - $details->title, $details->full_office_name Office - Last login on $details->last_login ($details->days_since_login days ago)<br/>\n";
	}
	send_email('juggernaut@944.com', 'Juggernaut', $email, $title, $output);
}

// echo $output;
// send_email('juggernaut@944.com', 'Juggernaut', 'hr@944.com,dee@944.com,marc@944.com,emmanuel@944.com', $title, $output);

?>
