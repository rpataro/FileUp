<?php

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");
include_once('/var/www/html/life944/public_html/inc/functions-shared.php');

$email_file = "/var/www/html/life944/public_html/inc/email_templates/important_reminder-2009-11-09.html";
$handle = fopen($email_file, "r");
$email_main = fread($handle, filesize($email_file));
fclose($handle);

// $issue_date = common_getCurrentIssueDate();
$issue_date = '2009-12-01';
$artwork_deadline = common_getArtworkDeadline($issue_date);

$artwork_sql = "
	SELECT company.CID,
	       orders_adsales.SizeID,
		   company.company_name, 
		   issues.iss_name, 
		   status.SDEFID, 
		   status.create_date, 
		   issues.iss_artwork_date, 
		   ad_size.ad_size_name 
	FROM orders_adsales 
		 INNER JOIN orders ON orders.OID = orders_adsales.OID
		 INNER JOIN company ON company.CID = orders.CID
		 INNER JOIN issues ON issues.id = orders_adsales.issueid 
		 INNER JOIN pubs ON pubs.id = issues.pubid 
		 INNER JOIN users ON users.userid = company.company_primary_rep 
		 INNER JOIN ad_size ON orders_adsales.SizeID = ad_size.sizeID 
		 LEFT JOIN (SELECT OTID, create_date, SDEFID
					FROM (SELECT job_tickets.OTID, max.create_date, status_def.status_def_name, status_def.SDEFID 
						  FROM job_tickets 
						 	   INNER JOIN order_status ON job_tickets.TID = order_status.OTID 
							   INNER JOIN (SELECT OTID, MAX(orderstatus_created_date) AS 'create_date' FROM order_status GROUP BY OTID) max 
								     ON order_status.OTID = max.OTID AND order_status.orderstatus_created_date = max.create_date
							   INNER JOIN status_def ON order_status.SDEFID = status_def.SDEFID) a  
					GROUP BY OTID, create_date, SDEFID) status ON orders_adsales.OAID = status.OTID 
	WHERE orders_adsales.kill = '0' 
	      AND orders.probability = 100 
	      AND (
				(YEAR(issues.iss_report_date) = '2009'
	      			AND MONTH(issues.iss_report_date) = '12')
				OR
				(YEAR(issues.iss_report_date) = '2010'
	      			AND MONTH(issues.iss_report_date) = '01'))
	      AND company.company_name NOT LIKE '944 WO%' 
	      AND pubs.isreport = 1 
		  AND pubs.online = 0 
		  AND company.company_name NOT LIKE '944%' 
	ORDER BY company.company_name
";
$artwork_query = mysql_query($artwork_sql);

$data = array();
while ($row = mysql_fetch_object($artwork_query)) {
	$data[$row->CID][] = $row;
}

$already_emailed = array();

foreach ($data as $cid => $cust) { 
	$contact = common_GetCompanyPrimaryRepAndContact($cid);

	$email_address = strtolower($contact['contact_email']);


	$artwork_list = "";
	$company_name = "";
	$issues = "";
	$pickup_text = "";
	$pickup_array = array();
	$x = 0;


	$email_text = $email_main;
	
	if ($email_address != "" && !(in_array($email_address, $already_emailed))) {
		// echo $email_address."\n";
		// $email_address = 'ejc@944.com';
		send_email("no-reply@944.com", "944 Magazine", $email_address, "Important Reminder From 944", $email_text);
	}
	
	$already_emailed[] = $email_address;
}


?>