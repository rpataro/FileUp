<?php

## Required server files
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");

function generate_ic_daily_sales_pubs($current_issue_date) {
	global $issue_next_month;
	global $issue_next_month_year;
	global $sql_reportdates;
	global $row_reportdates;
	$current_issue_date2 = date("Y-m-d",$current_issue_date);

	## Break up issue date
	$issue_month = date("m",$current_issue_date);
	$issue_year = date("Y",$current_issue_date);
	$issue_sales_start = $row_reportdates->begindaytosell;
	$issue_sales_end = $row_reportdates->lastdaytosell;

	## Determine service sale month/year
	if ($issue_month == 1) { $service_month = 12; $service_year = $issue_year - 1; } else { $service_month = $issue_month - 1; $service_year = $issue_year; }

	## Determine issue quarter
	if ($issue_month >= 1 && $issue_month <= 3) { $issue_quarter = "'".($issue_year - 1)."-12-01' AND '$issue_year-02-01' "; }
	if ($issue_month >= 4 && $issue_month <= 6) { $issue_quarter = "'$issue_year-03-01' AND '$issue_year-05-01' "; }
	if ($issue_month >= 7 && $issue_month <= 9) { $issue_quarter = "'$issue_year-06-01' AND '$issue_year-08-01' "; }
	if ($issue_month >= 10 && $issue_month <= 12) { $issue_quarter = "'$issue_year-09-01' AND '$issue_year-11-01' "; }

	echo "[".date("m/d/Y h:i:s")."] Processing data - Daily Sales by Pub...\n";
	include("/var/www/html/com944x/public_html/templates/home/infocenter/query_daily_sales_pub.php");	
}

## Input Requirements for Daily Sales
$sql_reportdates = "SELECT * FROM report_dates";
$row_reportdates = mysql_fetch_object(mysql_query($sql_reportdates));

## Get current issue date
$current_issue_date = common_getCurrentIssueDate(true);
$current_issue_date2 = date("Y-m-d",$current_issue_date);

## Create array of next three months, used in a few reports
$next_three_dates = array(
						$current_issue_date,
						common_getCurrentIssueDate(true, '+1 month'),
						common_getCurrentIssueDate(true, '+2 months')
					);

## Break up issue date
$issue_month = date("m",$current_issue_date);
$issue_year = date("Y",$current_issue_date);
$issue_sales_start = $row_reportdates->begindaytosell;
$issue_sales_end = $row_reportdates->lastdaytosell;

if ($month < 12) {
  $issue_next_month = $issue_month + 1;
  $issue_next_month_year = $issue_year; //Year when month incremented by 1, keep current year
}
else {
  $issue_next_month = 1;
  $issue_next_month_year = $issue_year + 1; //Year if month incremented by 1, increase year
}

## Determine service sale month/year
if ($issue_month == 1) { $service_month = 12; $service_year = $issue_year - 1; } else { $service_month = $issue_month - 1; $service_year = $issue_year; }

## Determine issue quarter
if ($issue_month >= 1 && $issue_month <= 3) { $issue_quarter = "'".($issue_year - 1)."-12-01' AND '$issue_year-02-01' "; }
if ($issue_month >= 4 && $issue_month <= 6) { $issue_quarter = "'$issue_year-03-01' AND '$issue_year-05-01' "; }
if ($issue_month >= 7 && $issue_month <= 9) { $issue_quarter = "'$issue_year-06-01' AND '$issue_year-08-01' "; }
if ($issue_month >= 10 && $issue_month <= 12) { $issue_quarter = "'$issue_year-09-01' AND '$issue_year-11-01' "; }

## Process data for Daily Sales by Rep
echo "[".date("m/d/Y h:i:s")."] Processing data - Daily Sales by Rep...\n";
include("/var/www/html/com944x/public_html/templates/home/infocenter/query_daily_sales_rep.php");

## Process data for Daily Sales by Pub
foreach ($next_three_dates as $key => $value) {
	generate_ic_daily_sales_pubs($value);
}
// exit;
## Process Market Daily Sales
echo "[".date("m/d/Y h:i:s")."] Processing data - Market Daily Sales...\n";

$sql = "SELECT * FROM 944web.locales WHERE active = 1";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) {
	$current = time()-(86400*6);
	while ($current <= time()) {
		$sql_delete = "DELETE FROM ic_market_daily_sales WHERE marketid = ".$row->LID." AND report_date = '".date("Y-m-d", $current)."'";
		$query_delete = mysql_query($sql_delete);
		
		$sales_total = common_getSalesTotal($row->LID,'market',date("Y-m-d", $current));
		$sql_insert = "INSERT INTO ic_market_daily_sales (marketid, ad_sales, report_date) VALUES (".$row->LID.", ".$sales_total.", '".date("Y-m-d", $current)."')";
		$query_insert = mysql_query($sql_insert);	
		
		$current += 86400;
	}
}

## Process Market Monthly Sales 
echo "[".date("m/d/Y h:i:s")."] Processing data - Market Monthly Sales...\n";

$sql = "SELECT * FROM 944web.locales WHERE active = 1";
$query = mysql_query($sql);

while ($row = mysql_fetch_object($query)) {

	$current = time()-((86400*29)*4);
	while ($current <= (time()+(86400*29))) {
		$sql_delete = "DELETE FROM ic_market_monthly_sales WHERE marketid = ".$row->LID." AND report_date = '".date("Y-m-01",$current)."'";
		$query_delete = mysql_query($sql_delete); 
		
		#Determine first/last day of each month
		$first_day = date("Y-m-01", strtotime("-1 month", strtotime(date("Y-m-d",$current))));
		$last_day = date("Y-m-d", strtotime("-1 day", strtotime(date("Y-m-01",$current))));
		
		$sales_total = common_getSalesTotal($row->LID,'market',$first_day,$last_day);
		
		$sql_insert = "INSERT INTO ic_market_monthly_sales (marketid, ad_sales, report_date) VALUES (".$row->LID.", ".$sales_total.", '".date("Y-m-01", $current)."')";
		$query_insert = mysql_query($sql_insert);
		
		$current += (86400*29);
	}

}

## Process Company Daily Sales
echo "[".date("m/d/Y h:i:s")."] Processing data - Company Daily Sales...\n";

$current = time()-(86400*6);
while ($current <= time()) {
	$sql_delete = "DELETE FROM ic_company_daily_sales WHERE report_date = '".date("Y-m-d", $current)."'";
	$query_delete = mysql_query($sql_delete);
	
	$sales_total = common_getSalesTotal(0,'company',date("Y-m-d", $current));
	$sql_insert = "INSERT INTO ic_company_daily_sales (ad_sales, report_date) VALUES (".$sales_total.", '".date("Y-m-d", $current)."')";
	$query_insert = mysql_query($sql_insert);	
	
	$current += 86400;
}

## Process Company Monthly Sales 
echo "[".date("m/d/Y h:i:s")."] Processing data - Company Monthly Sales...\n";

$current = time()-((86400*29)*4);
while ($current <= (time()+(86400*29))) {
	$sql_delete = "DELETE FROM ic_company_monthly_sales WHERE report_date = '".date("Y-m-01",$current)."'";
	$query_delete = mysql_query($sql_delete); 
	
	#Determine first/last day of each month
	$first_day = date("Y-m-01", strtotime("-1 month", strtotime(date("Y-m-d",$current))));
	$last_day = date("Y-m-d", strtotime("-1 day", strtotime(date("Y-m-01",$current))));
	
	$sales_total = common_getSalesTotal(0,'company',$first_day,$last_day);
	
	$sql_insert = "INSERT INTO ic_company_monthly_sales (ad_sales, report_date) VALUES (".$sales_total.", '".date("Y-m-01", $current)."')";
	$query_insert = mysql_query($sql_insert);
	
	$current += (86400*29);
}

##
## NEED TO MOVE
## 
function common_getSalesTotal($id=0,$scope='rep',$begin='0000-00-00',$end='0000-00-00') {
	
	## Check date values
	$date_where = "";
	if ($begin != '0000-00-00' && $end != '0000-00-00') {
		$date_where = "AND orders.sold_date BETWEEN '$begin 00:00:00' AND '$end 23:59:59' ";
	}
	
	if ($begin != '0000-00-00' && $end == '0000-00-00') { 
		$date_where = "AND orders.sold_date BETWEEN '$begin 00:00:00' AND '$begin 23:59:59' ";
	}
	
	## Check scope
	$total = 0;
	switch ($scope) {
		case "rep":
		case "company": 
			if ($scope == 'rep') { $scope_where = "AND users.userid = $id "; } else { $scope_where = ""; }
			$sql = " 
				SELECT ad.total_ad_sales, misc.total_misc_sales
				FROM (
					SELECT IFNULL(SUM((orders_adsales.net-orders_adsales.barter)*(orders_reps.order_pct/100)),0) AS 'total_ad_sales' 
					FROM orders_adsales 
						 INNER JOIN orders ON orders.OID = orders_adsales.OID
					 	 INNER JOIN orders_reps ON orders_reps.order_type_id = orders_adsales.OAID 
						 INNER JOIN company ON company.CID = orders.CID
						 INNER JOIN users ON users.userid = orders_reps.userid 
						 INNER JOIN issues ON issues.id = orders_adsales.issueid 
						 INNER JOIN pubs ON pubs.id = issues.pubid 
					WHERE orders_adsales.kill = '0' 
						  AND orders.probability = 100 
						  AND orders_reps.order_type = 1
						  AND company.company_name NOT LIKE '944 WO%' 
						  AND pubs.isreport = 1 
						  $date_where 
						  $scope_where ) ad, 
					 (
					SELECT IFNULL(SUM((orders_services.order_total)*(orders_reps.order_pct/100)),0) AS 'total_misc_sales' 
					FROM orders_services  
						 INNER JOIN orders ON orders.OID = orders_services.OID
					 	 INNER JOIN orders_reps ON orders_reps.order_type_id = orders_services.OSID 
						 INNER JOIN company ON company.CID = orders.CID
						 INNER JOIN users ON users.userid = orders_reps.userid 
					WHERE orders_services.kill = '0' 
						  AND orders.probability = 100 
						  AND orders_reps.order_type = 2 
						  AND company.company_name NOT LIKE '944 WO%' 
						  $date_where 
						  $scope_where ) misc
			";
			
			$query = mysql_query($sql);
			$row = mysql_fetch_object($query);
			$total = $row->total_ad_sales + $row->total_misc_sales;
			
			break;
			
		case "market":
			$scope_where = "AND pubs.nightsite_locale = $id ";
			$sql = " 
				SELECT ad.total_ad_sales 
				FROM (
					SELECT IFNULL(SUM((orders_adsales.net-orders_adsales.barter)*(orders_reps.order_pct/100)),0) AS 'total_ad_sales' 
					FROM orders_adsales 
						 INNER JOIN orders ON orders.OID = orders_adsales.OID
					 	 INNER JOIN orders_reps ON orders_reps.order_type_id = orders_adsales.OAID 
						 INNER JOIN company ON company.CID = orders.CID
						 INNER JOIN users ON users.userid = orders_reps.userid 
						 INNER JOIN issues ON issues.id = orders_adsales.issueid 
						 INNER JOIN pubs ON pubs.id = issues.pubid 
					WHERE orders_adsales.kill = '0' 
						  AND orders.probability = 100 
						  AND orders_reps.order_type = 1
						  AND company.company_name NOT LIKE '944 WO%' 
						  AND pubs.isreport = 1 
						  $date_where 
						  $scope_where ) ad 
			";
			
			$query = mysql_query($sql);
			$row = mysql_fetch_object($query);
			$total = $row->total_ad_sales;
			
			break;
	}
	
	return($total);

}

?>