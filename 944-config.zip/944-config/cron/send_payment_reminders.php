<?php

# Temporarily disable per Jeff/Jacque
if (date('Y-m-d') >= '2012-09-09') {
  exit;
}
exit;


require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");
include_once('/var/www/html/life944/public_html/inc/functions-shared.php');

$email_file = "/var/www/html/life944/public_html/inc/email_templates/template_payment_reminder.html";
$handle = fopen($email_file, "r");
$email_main = fread($handle, filesize($email_file));
fclose($handle);

$payments_sql = "
	SELECT company.CID, 
	  	   company.company_name, 
	       issues.iss_name, 
	  	   orders.sold_date, 
	  	   orders.OID, 
	       orders_adsales.OAID, 
	       ad_size.ad_size_name, 
		   invoices.IVID, 
		   invoices.invoice_date, 
		   invoices.invoice_duedate, 
		   (orders_adsales.net-orders_adsales.barter) AS 'invoice_total', 
		   IFNULL(payments.payments,0) AS 'invoice_payments', 
		   TIMESTAMPDIFF(DAY, invoices.invoice_duedate, NOW()) AS 'days_past_due'  
	FROM invoices 
		 INNER JOIN orders_adsales ON invoices.OTID = orders_adsales.OAID 
		 INNER JOIN issues ON orders_adsales.IssueID = issues.id 
		 INNER JOIN orders ON orders_adsales.OID = orders.OID 
		 INNER JOIN company ON orders.CID = company.CID 
		 INNER JOIN ad_size ON ad_size.sizeID = orders_adsales.SizeID 
		 LEFT JOIN (SELECT payments.IVID, SUM(payments.payments) AS 'payments' FROM payments GROUP BY payments.IVID) payments ON invoices.IVID = payments.IVID 
	WHERE invoices.OT = 1 
	    AND (orders_adsales.kill_keep_invoice = 1 OR orders_adsales.kill = '0')
		  AND (orders_adsales.net-orders_adsales.barter) - IFNULL(payments.payments,0) > 0 
		  AND invoices.invoice_duedate < DATE(NOW()) 
		  AND company.company_name NOT LIKE '944%' 
		  AND company.collections = 0 
		  AND company.write_off = 0 
	ORDER BY company.company_name 
";
$payments_query = mysql_query($payments_sql);

$data = array();
while ($row = mysql_fetch_object($payments_query)) {
	$data[$row->CID][] = $row;
}

$email_log = "";

foreach ($data as $cid => $cust) {
	
	$open_invoices = '<p style="line-height: 1.3em; margin-bottom: 15px;">'; 
	$open_list = '';
	$total_outstanding = 0;
	$email_text = $email_main;
	
	$company_name = "";
	$invoices = "";
	
	foreach ($cust as $invoice) {
		if ($open_list != '') { $open_list .= '<br><br>'; }
		$open_list .= 'Invoice #'.$invoice->IVID.' ($'.number_format($invoice->invoice_total,2).') | Due: '.date('m/d/Y', strtotime($invoice->invoice_duedate));
		$open_list .= ' | <a href="https://clients.944.com/pdf/?OT=1&OTID='.$invoice->OAID.'" style="color: #f99d1c;">View Invoice</a><br>'.$invoice->iss_name;
		$open_list .= ', '.$invoice->ad_size_name; 
		$total_outstanding += ($invoice->invoice_total - $invoice->invoice_payments);
		if ($company_name == "") { $company_name = stripslashes($invoice->company_name); } 
		if ($invoices != "") { $invoices .= ","; }
		$invoices .= $invoice->IVID;
	}
	
	$open_invoices .= $open_list.'<p>';
	
	$email_text = str_replace('INVOICE_LIST', $open_invoices, $email_text);
	$email_text = str_replace('INVOICE_OUTSTANDING', '$'.number_format($total_outstanding,2), $email_text);

	$contact = common_GetCompanyPrimaryRepAndBillingContact($cid);
	
	if ($contact['contact_phone_cell'] && $contact['allow_sms']) { 
		send_sms($contact['contact_phone_cell'], 'This is a 944 SMS reminder to notify you of a past due invoice. Please log into 944.com/paperless or contact receivables@944.com to submit payment, thank you.', 'payment_reminder');
	}

	// $email_address = common_GetBillingContactEmail($cid);
	$email_address = $contact['contact_email'];

	// if ($email_address == "") { $email_address = "renerodriguez@944.com"; } 

	if ($email_address != "" && $contact['allow_email']) {
		send_email("no-reply@944.com", "944 Magazine", $email_address, "944 Magazine | Payment Reminder", $email_text);	
		// send_email("no-reply@944.com", "944 Magazine", "ejc@944.com", "944 Magazine | Payment Reminder", $email_text);	
	}
	else {
		$missing_email_url = 'https://944.myjuggernaut.com/contacts/edit/?id='.$contact['IID'];
		$missing_email_link = '<a href="'.$missing_email_url.'">'.$missing_email_url."</a>";
		$missing_email_subject = "Unable to send payment reminders, missing email for $company_name (".stripslashes($contact['contact_firstname'])." ".stripslashes($contact['contact_lastname']).")";
		$missing_email_body = "<p>Unable to send payment reminders because Juggernaut is missing an email address for your contact. Please update immediately (and include a cell phone number) by clicking on this link:</p><p>".$missing_email_link."</p>";

		send_email("juggernaut@944.com", "Juggernaut", $contact['email'].', receivables@944.com', $missing_email_subject, $missing_email_body);
	}

	$company_link = '<a href="https://944.myjuggernaut.com/contacts/view/?cid='.$cid.'">'.$company_name.'</a>';
	$email_log .= "Client <b>$company_link</b> emailed about invoice(s): ($invoices) - sent to $email_address<br>";
}

send_email("no-reply@944.com", "944 Magazine", "ejc@944.com, receivables@944.com", "944 Magazine | Payment Reminders ".date("m/d/Y"), "All payment reminders have been sent out for ".date("m/d/Y").".<br><br>$email_log");
// send_email("no-reply@944.com", "944 Magazine", "ejc@944.com", "944 Magazine | Payment Reminders ".date("m/d/Y"), "All payment reminders have been sent out for ".date("m/d/Y").".<br><br>$email_log");

?>
