<?php
// [EJC 2009-02-19]
// Send an email to HR automatically to notify of any changes to the list of users who can clock in from anywhere

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
include($_SERVER['DOCUMENT_ROOT'].'/includes/functions.php');
include($_SERVER['DOCUMENT_ROOT'].'/includes/functions-only.php');
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");

$body = '<p>Users who can currently clock in from anywhere:</p>';
$users_query = "SELECT * FROM 944x_944media.users WHERE dead = '0' AND date_term = '0000-00-00' ORDER BY fname";
$users_result = mysql_query($users_query);
while ($row = mysql_fetch_assoc($users_result)) {
	include($_SERVER['DOCUMENT_ROOT']."/cdata/944/users/".$row['userid']."/user_permissions.php");
	if ($user_permissions[$row['userid']]['home']['clockinanywhere']['access']) {
		$body .= '<a href="https://944.myjuggernaut.com/administration/empconfig/permissions/?userid='.$row['userid'].'">'.$row['fname'].' '.$row['lname'].'</a><br/>';
	}
}

echo $body;

send_email('juggernaut@944.com', 'Juggernaut', 'hr@944.com,emmanuel@944.com', 'Report: Users who can currently clock in from anywhere', $body);

echo "email sent!";
?>
