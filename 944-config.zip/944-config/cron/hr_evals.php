#!/usr/bin/php -q
<?php
// Called every night at 5:30am to run 90-day and annual evaluations

// *** TO REMOVE:
// echo "Temporarily Disabled!";
// exit;

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
include($_SERVER['DOCUMENT_ROOT']."/data/locales.php");
$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/templates/hr/eval/functions.php");

// Only run M-F per Marc [EJC 2009-03-02]
if (date('w') >= 1 && date('w') <= 5) {
	// Nikki was getting multiple evals because she had a previously completed eval greater than 90 days old; no longer needed since the yearly eval checks are a different query
	// $query_90days = "SELECT DISTINCT DATEDIFF(now(), date_hire) AS days_since_hire, DATEDIFF(now(), request_date) AS days_since_eval, userid, users.manager_id, fname, lname, email, date_hire, max(request_date) AS last_eval FROM users LEFT JOIN hr_eval_requests ON userid = emp_id WHERE login = '1' AND users.dead = '0' AND emptype = '1' AND date_hire != '0000-00-00' AND (date_term = 'NULL' OR date_term = '0000-00-00') AND DATEDIFF(now(), date_hire) >= 90 AND DATEDIFF(now(), date_hire) < 170 AND (DATEDIFF(now(), request_date) IS NULL OR DATEDIFF(now(), request_date) > 90) GROUP BY userid";

	$query_90days = "SELECT DISTINCT DATEDIFF(now(), date_hire) AS days_since_hire, DATEDIFF(now(), request_date) AS days_since_eval, userid, users.manager_id, fname, lname, email, date_hire, max(request_date) AS last_eval FROM users LEFT JOIN hr_eval_requests ON userid = emp_id WHERE login = '1' AND users.dead = '0' AND emptype = '1' AND date_hire != '0000-00-00' AND (date_term = 'NULL' OR date_term = '0000-00-00') AND DATEDIFF(now(), date_hire) >= 90 AND DATEDIFF(now(), date_hire) < 170 AND DATEDIFF(now(), request_date) IS NULL GROUP BY userid";
	// AND (userid=461 OR userid=466 OR userid=473 OR userid=485)
	$result = mysql_query($query_90days);
	while ($row = mysql_fetch_assoc($result)) {
		assign_eval($row["userid"], "90days");
	}
	
}
else {
	echo 'Only runs on weekdays.';
}

// Only run annual evaluations if in the month of October
if (date('m') == '10' && date('d') <= '31') {
	$query_annual = "SELECT DISTINCT DATEDIFF(now(), date_hire) AS days_since_hire, DATEDIFF(now(), request_date) AS days_since_eval, userid, users.manager_id, fname, lname, email, date_hire, max(request_date) AS last_eval FROM users LEFT JOIN hr_eval_requests ON userid = emp_id WHERE login = '1' AND users.dead = '0' AND emptype = '1' AND date_hire != '0000-00-00' AND (date_term = 'NULL' OR date_term = '0000-00-00') AND DATEDIFF(now(), date_hire) > 180 AND (DATEDIFF(now(), request_date) IS NULL OR DATEDIFF(now(), request_date) > 90) GROUP BY userid";
//  AND (userid=33 OR userid=95 OR userid=21 OR userid=175)
	$result = mysql_query($query_annual);
	while ($row = mysql_fetch_assoc($result)) {
		// Don't send evals for Marc nor Jenn (leaving soon), nor any non-real employees..
		if ($row['userid'] != '238' && $row['userid'] != '28' && $row['userid'] != '226' && $row['userid'] != '56' && $row['userid'] != '97' && $row['userid'] != '171' && $row['userid'] != '405') {
			// assign_eval($row["userid"], "annual");
		}
	}
}

// Run the assign_evals one time on 2009-11-25
if (date('Y-m-d') == '2009-11-25') {
	$query_annual = "SELECT DISTINCT DATEDIFF(now(), date_hire) AS days_since_hire, DATEDIFF(now(), request_date) AS days_since_eval, userid, users.manager_id, fname, lname, email, date_hire, max(request_date) AS last_eval FROM users LEFT JOIN hr_eval_requests ON userid = emp_id WHERE login = '1' AND users.dead = '0' AND emptype = '1' AND date_hire != '0000-00-00' AND (date_term = 'NULL' OR date_term = '0000-00-00') AND date_hire <= '2009-08-15' GROUP BY userid";
//  AND (userid=33 OR userid=95 OR userid=21 OR userid=175)
	$result = mysql_query($query_annual);
	while ($row = mysql_fetch_assoc($result)) {
		// Don't send evals for Marc nor Jenn (leaving soon), nor any non-real employees..
		// if ($row['userid'] != '238' && $row['userid'] != '28' && $row['userid'] != '226' && $row['userid'] != '56' && $row['userid'] != '97' && $row['userid'] != '171' && $row['userid'] != '405') {
			assign_eval($row["userid"], "annual");
		// }
	}
}


?>
