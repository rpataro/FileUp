<?php
$httpd_root = '/var/www/html';

$_SERVER['COM944X_DOC_ROOT'] = $httpd_root.'/com944x/public_html';
$_SERVER['LIFE944_DOC_ROOT'] = $httpd_root.'/life944/public_html';
$_SERVER['ADMIN944_DOC_ROOT'] = $httpd_root.'/admin944/public_html';
$_SERVER['ALLSTAR_DOC_ROOT'] = $httpd_root.'/allstar/www';
$_SERVER['CLI944_DOC_ROOT'] = $httpd_root.'/cli944/public_html';
$_SERVER['HOTEL944_DOC_ROOT'] = $httpd_root.'/hotel944/www';
$_SERVER['PROOF944_DOC_ROOT'] = $httpd_root.'/proof944/public_html';
$_SERVER['LINKS944_DOC_ROOT'] = $httpd_root.'/links944/public_html';
$_SERVER['VENDORS_DOC_ROOT'] = $httpd_root.'/vendors/public_html';
?>