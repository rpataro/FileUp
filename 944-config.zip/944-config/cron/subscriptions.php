#!/usr/bin/php -q
<?php

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
include_once('/var/www/html/life944/public_html/inc/functions-shared.php');

$query = "SELECT locale, DATE(startdate) AS startdate, DATE(enddate) AS enddate FROM 944com.cart_subscriptions WHERE (DATE(startdate) = DATE(NOW()) OR DATE(enddate) = DATE(NOW())) AND 
`dead` != '1' AND status = 1";
$result = mysql_query($query);

while ($row = mysql_fetch_assoc($result)) {
	if ($row['startdate'] == date('Y-m-d')) {
		subscription_change($row['locale'], 1);
		echo "Added a new active sub to distribution for locale ".$row['locale'];
	}
	elseif ($row['enddate'] == date('Y-m-d')) {
		subscription_change($row['locale'], -1);
		echo "Removed an active sub to distribution for locale ".$row['locale'];
	}
}

?>
