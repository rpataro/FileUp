<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

// Only run Monday-Friday, on non-holidays.. use the get_work_days function
$today = date('Y-m-d');
if (!get_work_days($today, $today)) {
	echo "Not a work day, exiting now.";
	exit;
}

// Send later at 8pm PST during print week (last 5 days preceding print date)
$print_date_query = "SELECT DATEDIFF(iss_press_date, now()) AS days_before_print FROM 944x_944media.issues WHERE DATEDIFF(iss_press_date, now()) BETWEEN 0 and 5";
$print_date_result = mysql_query($print_date_query);
if (mysql_num_rows($print_date_result)) {
	$print_week = 1;
}

if ($print_week && date('G') < 19) {
	echo 'Print week, report delayed until 8pm PST';
	// exit;
}

$ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, "https://proofcenter.944.com/dailysales.php");
curl_setopt($ch, CURLOPT_URL, "https://944.myjuggernaut.com/templates/home/dailysales-cronjob.phpx");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$body = curl_exec($ch);
curl_close($ch);

$to = "dailysales@944.com";
//$to = "emmanuel@944.com";
$headers = "MIME-Version: 1.0 \r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1 \r\n";
$headers .= "From: Juggernaut <juggernaut@944.com> \r\n";

if (mail($to,"Daily Sales Report",$body,$headers)) {
    echo("<p>Message successfully sent...");
} else {
    echo "message did not deliver";
}
?>
