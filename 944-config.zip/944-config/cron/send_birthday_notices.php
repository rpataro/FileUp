<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

// $birthday_query = "SELECT u.fname, u.lname, u.email, YEAR(u.dob) AS dob_year, m.email AS manager_email FROM 944x_944media.users AS u LEFT JOIN 944x_944media.users AS m ON u.manager_id = m.userid WHERE MONTH(u.dob) = MONTH(now()) AND DAY(u.dob) = DAY(now()) AND u.login = '1' AND u.dead = '0' AND u.date_term = '0000-00-00'";
$birthday_query = "SELECT u.fname, u.lname, u.email, YEAR(u.dob) AS dob_year, DATE_FORMAT(u.dob, '%m-%d') AS dob_month_day, m.email AS manager_email FROM 944x_944media.users AS u LEFT JOIN 944x_944media.users AS m ON u.manager_id = m.userid 
	WHERE 
		(
			(MONTH(u.dob) = MONTH(now()) AND DAY(u.dob) = DAY(now())) 
			OR
			(MONTH(DATE(DATE_SUB(u.dob, INTERVAL 3 DAY))) = MONTH(DATE(DATE_SUB(now(), INTERVAL 3 DAY))) AND DAY(DATE(DATE_SUB(u.dob, INTERVAL 3 DAY))) = DAY(DATE(DATE_SUB(now(), INTERVAL 3 DAY)))) 
		) 
		AND u.login = '1' AND u.emptype IN (1, 2, 3) AND u.dead = '0' AND u.date_term = '0000-00-00'";

$birthday_result = mysql_query($birthday_query);
while ($row = mysql_fetch_assoc($birthday_result)) {
	$age = date('Y') - $row['dob_year'];
	$name = stripslashes($row['fname'])." ".stripslashes($row['lname']);
	$title = "Birthday Notification: ".$name;

	$days_text = ($row['dob_month_day'] == date('m-d')) ? 'This day' : 'In 3 days';
	
	$body = $days_text.", ".$age." years ago, <a href='mailto:".$row['email']."'>".$name."</a> was born, destined to lead 944 into the future. Why don't you send a happy birthday message? Or buy a cake for the office? Cakes are yummy.";

	$email_to = 'hr@944.com,emmanuel@944.com,'.$row['manager_email'];
	
	send_email('juggernaut@944.com', 'Juggernaut', $email_to, $title, $body);
}

?>
