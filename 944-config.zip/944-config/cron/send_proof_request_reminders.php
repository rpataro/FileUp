<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

$reminder_query = "SELECT *, jt.TID as ticket_number, jp.id AS proof_id, DATEDIFF(NOW(), jp.sent_datetime) AS days_since_sent, DATEDIFF(NOW(), jp.reminder_sent) AS days_since_reminder FROM job_tickets AS jt LEFT JOIN orders_services AS os ON os.OSID = jt.OTID LEFT JOIN job_proofs AS jp ON jp.tid = jt.TID where jt.last_status = 11 AND os.order_done = 1 AND jp.reply_datetime = '0000-00-00 00:00:00' AND DATEDIFF(NOW(), jp.sent_datetime) >= 3 AND (DATEDIFF(NOW(), jp.reminder_sent) IS NULL OR DATEDIFF(NOW(), jp.reminder_sent) >= 3) GROUP BY jt.TID";

$reminder_result = mysql_query($reminder_query);
while ($row = mysql_fetch_assoc($reminder_result)) {
	$url = 'https://944.myjuggernaut.com/production/jobtickets/jobjacket/?id='.$row['ticket_number'];
	$link = '<a href="'.$url.'">'.$url.'</a>';

	$url_proof = 'https://proofcenter.944.com/proof.php?id='.$row['proof_id'];
	$link_proof = '<a href="'.$url_proof.'">'.$url_proof.'</a>';

	$title = "Proof Request Reminder: ".stripslashes($row['ticket_name']);
	$body = "<p>It looks like you have not yet approved the proof request that you were sent for the following ticket: ".stripslashes($row['ticket_name']);
	$body .= "</p><p>It's important that the job tickets are kept up to date, and that they're closed when completed. An email will be sent to you every few days until you follow up; after one week, your manager will be notified.</p>";
	$body .= "<p>Please visit the following URLs and take the appropriate action immediately to help make this process work smoothly:</p>";
	$body .= "<p>Proof: ".$link_proof."</p>";
	$body .= "<p>Job Jacket: ".$link."</p>";
	$body .= "<p><br>Thank you.</p>";
	$to_email = $row['sent_to_email'];
	// $to_email = 'emmanuel@944.com';

	// Add a check so that if it's been more than 7 days since the original proof request was sent (jp.sent_datetime), 
	// and reminders have been sent (jp.reminder_sent), notify the manager

	send_email('juggernaut@944.com', 'Juggernaut', $to_email, $title, $body);

	$update_query = "UPDATE job_proofs SET reminder_sent = DATE(NOW()) WHERE id = '".$row['proof_id']."'";
	// echo $update_query;
	$update_result = mysql_query($update_query);
	
	echo "Done.";
}

?>
