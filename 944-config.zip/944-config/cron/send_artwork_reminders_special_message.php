<?php

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");
include_once('/var/www/html/life944/public_html/inc/functions-shared.php');

$email_file = "/var/www/html/life944/public_html/inc/email_templates/template_artwork_reminder.html";
$handle = fopen($email_file, "r");
$email_main = fread($handle, filesize($email_file));
fclose($handle);

$issue_date = common_getCurrentIssueDate();
$artwork_deadline = common_getArtworkDeadline($issue_date);
$days_to_deadline = ceil((strtotime($artwork_deadline) - time())/86400);

echo "Issue Date: $issue_date\n";
echo "Artwork Deadline: $artwork_deadline\n";
echo "Days to Deadline: $days_to_deadline\n";

if ($days_to_deadline == 1 || $days_to_deadline == 3 || $days_to_deadline == 7) { 
	$artwork_sql = "
		SELECT company.CID,
		       orders_adsales.SizeID,
			   company.company_name, 
			   issues.iss_name, 
			   status.SDEFID, 
			   status.create_date, 
			   issues.iss_artwork_date, 
			   ad_size.ad_size_name 
		FROM orders_adsales 
			 INNER JOIN orders ON orders.OID = orders_adsales.OID
			 INNER JOIN company ON company.CID = orders.CID
			 INNER JOIN issues ON issues.id = orders_adsales.issueid 
			 INNER JOIN pubs ON pubs.id = issues.pubid 
			 INNER JOIN users ON users.userid = company.company_primary_rep 
			 INNER JOIN ad_size ON orders_adsales.SizeID = ad_size.sizeID 
			 LEFT JOIN (SELECT OTID, create_date, SDEFID
						FROM (SELECT job_tickets.OTID, max.create_date, status_def.status_def_name, status_def.SDEFID 
							  FROM job_tickets 
							 	   INNER JOIN order_status ON job_tickets.TID = order_status.OTID 
								   INNER JOIN (SELECT OTID, MAX(orderstatus_created_date) AS 'create_date' FROM order_status GROUP BY OTID) max 
									     ON order_status.OTID = max.OTID AND order_status.orderstatus_created_date = max.create_date
								   INNER JOIN status_def ON order_status.SDEFID = status_def.SDEFID) a  
						GROUP BY OTID, create_date, SDEFID) status ON orders_adsales.OAID = status.OTID 
		WHERE orders_adsales.kill = '0' 
		      AND orders.probability = 100 
		      AND YEAR(issues.iss_report_date) = YEAR('$issue_date') 
		      AND MONTH(issues.iss_report_date) = MONTH('$issue_date') 
		      AND company.company_name NOT LIKE '944 WO%' 
		      AND pubs.isreport = 1 
			  AND (status.SDEFID NOT IN (21,45,76) OR status.SDEFID IS NULL)
			  AND pubs.online = 0 
			  AND company.company_name NOT LIKE '944%' 
		ORDER BY company.company_name 
	";
	$artwork_query = mysql_query($artwork_sql);
	
	$data = array();
	while ($row = mysql_fetch_object($artwork_query)) {
		$data[$row->CID][] = $row;
	}
	
	foreach ($data as $cid => $cust) { 
		// $contact_sql = "
		// 	SELECT contacts.contact_firstname, 
		// 		   contacts.contact_lastname, 
		// 		   contacts.contact_email, 
		// 		   users.fname, 
		// 		   users.lname, 
		// 		   users.email 
		// 	FROM contacts 
		// 		 INNER JOIN company ON contacts.CID = company.CID 
		// 		 INNER JOIN users ON company.company_primary_rep = users.userid 
		// 	WHERE contacts.CID = ".$cid."  
		// 		  AND contacts.primary_contact = '1'
		// ";
		// // echo $contact_sql."\n\n";
		// 
		// $contact_query = mysql_query($contact_sql);
		// $contact = mysql_fetch_object($contact_query);

		$contact = common_GetCompanyPrimaryRepAndArtworkContact($cid);
		//print_r($contact);

		$artwork_list = "";
		$company_name = "";
		$issues = "";
		$pickup_text = "";
		$pickup_array = array();
		$x = 0;

		foreach ($cust as $artwork) {
			if ($artwork_list != "") { $artwork_list .= '<br>'; }
			$artwork_list .= $artwork->iss_name.', '.$artwork->ad_size_name.' - <a href="https://944.com/paperless/" style="color: #f99d1c;">Upload Artwork Now</a>';

			$past_orders_query = "SELECT oa.OAID FROM orders AS o LEFT JOIN orders_adsales AS oa ON oa.OID = o.OID LEFT JOIN issues AS i ON i.id = oa.IssueID WHERE o.CID = '".$cid."' AND oa.SizeID = '".$artwork->SizeID."' AND i.iss_report_date <= '".$issue_date."' ORDER BY i.iss_report_date DESC LIMIT 9";
			$past_orders_result = mysql_query($past_orders_query);
			while ($past_order = mysql_fetch_assoc($past_orders_result)) {
				if ($mb_image = get_mb_image($past_order['OAID'])) {
					$pickup_array[] = $mb_image;
				}
			}

			if ($pickup_array) {
				$pickup_text = '<p style="line-height: 1.2em;"><b>Schedule a Pickup</b></p>';
				$pickup_text .= '<p style="line-height: 1.4em; margin-bottom: 15px;">If you\'d like to, you can schedule a "pickup" of a previously run advertisement. To do so, just click on any of your most recent ads below, or visit <a href="https://944.com/paperless/" style="color: #f99d1c;" title="944 | Paperless" target="_blank">944.com/paperless</a>, login using your email address and password, click the "Submit Artwork" link from the menu on the right, then select "Submit Pickup" for the orders that you want to use previous artwork.</p>';

				foreach ($pickup_array as $key => $pickup) {
					$x++;
					$pickup_text .= '<div style="width: 145px; margin: 10px; display: block; float: left;">';
					$pickup_text .= '<a href="https://www.944.com/paperless/"><img src="'.$pickup['small_url'].'" width="140" border="0"></a>';
					// $pickup_text .= '<a href="'.$pickup['large_url'].'"><img src="'.$pickup['small_url'].'" width="140" border="0"></a>';
					$pickup_text .= '<br>'.$pickup['issue'];
					$pickup_text .= '</div>';
					if (!($x % 3)) {
						$pickup_text .= '<div style="clear: both;"></div>';
					}
				}

				$pickup_text .= '<div style="clear: both;"></div>';

				// $pickup_text .= '<p style="line-height: 1.4em; margin-bottom: 15px;">If you\'d like to, you can schedule a "pickup" of a previously run advertisement. To do so, please visit <a href="https://944.com/paperless/" style="color: #f99d1c;" title="944 | Paperless" target="_blank">944.com/paperless</a>, login using your email address and password, click the "Submit Artwork" link from the menu on the right, then select "Submit Pickup" for the orders that you want to use previous artwork.</p>';			
			}

			if ($company_name == "") { $company_name = stripslashes($artwork->company_name); } 
			if ($issues != "") { $issues .= ", "; }
			$issues .= $artwork->iss_name.' ('.$artwork->ad_size_name.')';
		}
		
		if ($days_to_deadline > 1) { $artwork_days = $days_to_deadline.' days'; } else { $artwork_days = '24 hours'; }
		
		$email_text = $email_main;
		$email_text = str_replace('ARTWORK_REP', $contact['fname'].' '.$contact['lname'], $email_text);
		$email_text = str_replace('ARTWORK_EMAIL', $contact['email'], $email_text);
		$email_text = str_replace('ARTWORK_LIST', $artwork_list, $email_text);
		$email_text = str_replace('PICKUP_TEXT', $pickup_text, $email_text);
		$email_text = str_replace('ARTWORK_DAYS', $artwork_days, $email_text);
		
		$email_address = $contact['contact_email'];
		// if ($email_address == "") { $email_address = "starpadilla@944.com"; }

		// ** to remove:
		// $email_address = 'ejc@944.com';
		// echo $email_text.'<hr/>';

		$company_link = '<a href="https://944.myjuggernaut.com/contacts/view/?cid='.$cid.'">'.$company_name.'</a>';
		$email_log .= "<b>$company_link</b> emailed about outstanding artwork for issues: ($issues) - sent to $email_address<br><br>";

		if ($contact['contact_phone_cell'] && $contact['allow_sms']) { 
			send_sms($contact['contact_phone_cell'], 'This is the 944 SMS service reminding you that you have artwork due. Please log in to 944.com/paperless to submit your artwork, thanks!', 'artwork_reminder');
		}

		$email_text = '
		<p>
		Good afternoon,
		</p>

		<p>
		I hope January is off to a great start for you. So that you can plan accordingly, I wanted to let you know as early as possible that ad artwork for the 944 February Issue will be due January 15.
		</p>
		
		<p>
		As you already know, 944 has implemented our convenient paperless Client Center to simplify your artwork submission. If you are looking to run the same ad artwork (a PICKUP) from a previous issue, please log in and select that option.
		</p>
		
		<p>
		Go to: <a href="https://www.944.com/paperless">www.944.com/paperless</a><br>
		Client Login: Is the e-mail address you initially set up with your Sales Representative.<br>
		Password: Was e-mailed to you. If you do not have this, select the "Request/Reset Password Now" link.<br>
		The Client Center will then walk you through your artwork upload or there is an option to do a PICKUP from a previous issue.<br>
		</p>
		
		<p>
		Please feel free to reach out to me with any questions.
		</p>
		
		<p>
		Best regards,
		</p>
		
		<p>
		Star Padilla
		</p>';
		// $email_address = 'emmanuel@944.com';

		if ($email_address != "") {
			send_email("star@944.com", "944 Magazine", $email_address, "944 Magazine | Artwork Reminder", $email_text);
		}
		else {
			$missing_email_url = 'https://944.myjuggernaut.com/contacts/edit/?id='.$contact['IID'];
			$missing_email_link = '<a href="'.$missing_email_url.'">'.$missing_email_url."</a>";
			$missing_email_subject = "Unable to send artwork reminders, missing email for $company_name (".stripslashes($contact['contact_firstname'])." ".stripslashes($contact['contact_lastname']).")";
			$missing_email_body = "<p>Unable to send missing artwork reminders because Juggernaut is missing an email address for your contact. Please update immediately (and include a cell phone number if available) by clicking on this link:</p><p>".$missing_email_link."</p>";

			send_email("juggernaut@944.com", "Juggernaut", $contact['email'].', ejc@944.com', $missing_email_subject, $missing_email_body);
		}
	}
	
	send_email("no-reply@944.com", "944 Magazine", "ejc@944.com, ads@944.com", "944 Magazine | Artwork Reminders | ".date("m/d/Y"), "All artwork reminders have been sent out on ".date("m/d/Y").".<br><br>$email_log");
	// send_email("no-reply@944.com", "944 Magazine", "ejc@944.com", "944 Magazine | Artwork Reminders | ".date("m/d/Y"), "All artwork reminders have been sent out on ".date("m/d/Y").".<br><br>$email_log");
}
else {
	echo "Days to deadline needs to be 1, 3 or 7, it's currently $days_to_deadline; did not run.\n";
}

?>