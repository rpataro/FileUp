<?php

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");

$month = date("n");
// $month = 2;
$year = date("Y");

## Get user records
$users_sql = "SELECT * FROM users";
$users_query = mysql_query($users_sql);
$users = array();

while ($row = mysql_fetch_object($users_query)) {
	$users[$row->userid] = $row;
}


## Get commissions history

$commissions = array();
$comm_query = "SELECT * FROM commissions_history ORDER BY changed_date DESC";
$comm_result = mysql_query($comm_query);
while ($row = mysql_fetch_object($comm_result)) {
	$commissions[$row->userid][$row->changed_date] = $row;
}

## Pass a userid in order to update just one particular user
// $userid = 833;
if ($userid) {
	$user_sql = "AND user_id = '".$userid."'";
}

## Clear table
mysql_query("DELETE FROM 944x_944media.commissions WHERE report_month = $month AND report_year = $year $user_sql");
include($_SERVER['DOCUMENT_ROOT']."/templates/reports/commission_query_all_reps_new.php");
$query = mysql_query($detail_sql) or die(mysql_error());

## Will be used to clear out exisiting information
$current_user_id = 0;

echo "Processing commissions for $month/$year...\n";

while($row = mysql_fetch_object($query)) {
	// echo $row->user_id."\n";
	## If the user_id value has changed, make sure to clear out data for that user so no duplicates pop up
	if ($row->user_id != $current_user_id) {
		$current_user_id = $row->user_id;
		$sql = "DELETE FROM commissions WHERE user_id = ".$current_user_id." AND report_month = ".$month." AND report_year = ".$year;
		mysql_query($sql);
	}

	#Set Default User Object
	$user = $users[$current_user_id];
	
	# Check commissions history table to pull up right commission figures
	$old_plan_found = FALSE;

	$sold_date_timestamp = strtotime($row->sold_date);

	// echo "\nsold_date: $row->sold_date; sold_date_timestamp: $sold_date_timestamp\n";
	// print_r($commissions);
	// print_r($commissions[$current_user_id]);
	foreach ($commissions[$current_user_id] as $timestamp => $value) {
		// echo "\ntimestamp: $timestamp\n";
		if ($sold_date_timestamp <= $timestamp && !$old_plan_found && $timestamp > 0) {
			$old_plan_found = TRUE;
			$user->commission_plan = $value->plan;
			$user->commission_percent = $value->percent;
		}
	}

	$row = calculate_commissions($user, $row, 'to_pay');
	
	## Insert row into commissions table
	$sql  = "INSERT INTO commissions (user_id, company_id, invoice_id, issue, ad_size, ad_position, split, rate_split, sold_split, barter_total, barter_paid, invoice_date, invoice_duedate, ";
	$sql .= "payments, eligible_date, plan, commission_percent, commission, total_sales, total_goal, report_month, report_year) ";
	$sql .= "VALUES (".$row->user_id.", ".$row->CID.", ".$row->IVID.", '".$row->iss_name."', '".$row->ad_size."', '".$row->ad_position."', ".$row->split.", ".$row->rate_card.", ";
	$sql .= $row->sold_split.", '".$row->barter_total."', '".$row->barter_paid."', '".$row->invoice_date."', '".$row->invoice_duedate."', ".$row->payment_split.", '".$row->eligible_date."', '".$row->plan."' ,";
	$sql .= $row->commission_percent.", ".$row->commission.", ".$row->total_sales.", ".$row->total_goal.", $month, $year)";
	// echo "\n$sql\n";
	mysql_query($sql) or die(mysql_error());

}

echo "Done-zo\n";

?>
