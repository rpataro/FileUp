<?php

require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
// require_once($_SERVER['DOCUMENT_ROOT']."/includes/phpmailer.php");

    $sql = "SELECT company_name, concat( users.fname, ' ', users.lname ) AS rep_name, users.email, DATE_FORMAT(invoice_date,'%m/%d%/%y') as invoice_date, DATE_FORMAT(invoice_duedate,'%m/%d%/%y') as invoice_duedate, DATEDIFF( now( ) , invoice_duedate ) AS days_elapsed, orders_adsales.net - barter AS inv_cash, IFNULL(paid.cash_payments,0) AS paid_cash
              FROM invoices
              LEFT JOIN (

              SELECT IFNULL( sum( payments ) , 0 ) AS cash_payments, sum( barter_payments ) AS barter_payments, IVID
              FROM `payments`
              GROUP BY IVID
              ) AS paid ON paid.IVID = invoices.IVID
              JOIN orders_adsales ON orders_adsales.OAID = invoices.OTID
              JOIN orders ON orders_adsales.OID = orders.OID
              JOIN company ON company.CID = orders.CID
              JOIN users ON users.userid = company.company_primary_rep
              WHERE invoices.OT = '1'
              AND ( net - barter >  cash_payments OR cash_payments IS NULL )
              AND DATEDIFF( now( ) , invoice_duedate ) >=60
              AND DATEDIFF( now( ) , invoice_duedate ) <90
              AND (net - barter > 0)
              AND users.login='1'
              AND company.collections='0'
              ORDER BY users.fname, users.lname, company_name";
    $rs = mysql_query($sql);

    $to = "collections@944.com";
    $headers = "MIME-Version: 1.0 \r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1 \r\n";
    $headers .= "From: Juggernaut <juggernaut@944.com> \r\n";

    $body = "<font color=red>The following invoices are over 60 days past due.  At 90 days past due, these invoices will be non-commissionable.<br><br>";
    $body .= "<table border=1 cellspacing=0>";
    $body .= "<tr bgcolor='#AAAAAA'><td>Company</td><td>Rep</td><td>Invoice Date</td><td>Invoice Due Date</td><td>Invoice Amount</td><td>Amount Paid</td><td>Amount Due</td></tr>";
    while ($row = mysql_fetch_assoc($rs)) {
        if ($lastrep=="") { $lastrep = $row['email']; }
        if ($lastrep!=$row['email']) {
            echo "sending new one to: ".$lastrep;
            if (mail($to.",".$lastrep,"Past Due Invoices - Potential Commission Loss - ".$lastrep,$body,$headers)) {
               /// echo("<p>Message succesfully sent...");
            } else {
                echo "message did not deliver";
            }
            $body .= "</table>To: $lastrep";
            $body = "<font color=red>The following invoices are over 60 days past due.  At 90 days past due, these invoices will be non-commissionable.<br><br>";
            $body .= "<table border=1 cellspacing=0>";
            $body .= "<tr bgcolor='#AAAAAA'><td>Company</td><td>Rep</td><td>Invoice Date</td><td>Invoice Due Date</td><td>Invoice Amount</td><td>Amount Paid</td><td>Amount Due</td></tr>";
            $lastrep=$row['email'];
           }
        $body .= "<tr><td>".$row['company_name']."</td><td>".$row['rep_name']."</td><td>".$row['invoice_date']."</td><td>".$row['invoice_duedate']."</td><td>$".$row['inv_cash']."</td><td>$".$row['paid_cash']."</td><td>$".($row['inv_cash']-$row['paid_cash'])."</tr>";
    }

    //we do this to send the last rep
    $body .= "</table>";
    if (mail("$to, $lastrep","Past Due Invoices - Potential Commission Loss - ".$lastrep,$body,$headers)) {
        ///echo("<p>Message succesfully sent...");
    } else {
        echo "message did not deliver";
    }




?>
