<?php
require_once('config.php');

$_SERVER['DOCUMENT_ROOT'] = '/var/www/html/com944x/public_html';
$_SERVER['HTTP_HOST'] = "944.myjuggernaut.com";

$database_name = "944x_944media";
require_once($_SERVER['DOCUMENT_ROOT']."/includes/database.php");
require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions.php");
// require_once($_SERVER['DOCUMENT_ROOT']."/includes/functions-ec.php");

$num_results = generate_all_iifs();

// If new entries were found, email finance
if ($num_results) {
	if ($num_results > 1) {
		$plural = 's';
	}

	$title = "New IIF Generated with ".$num_results." Invoice".$plural;
	$body = "<p>A new IIF has been generated with ".$num_results." new invoice".$plural.". Please download and import this IIF file from:</p>";
	$url = "https://944.myjuggernaut.com/payables/iif/";
	$body .= '<p><a href="'.$url.'">'.$url.'</a>';

	echo $body;
	send_email('juggernaut@944.com', 'Juggernaut', 'payables@944.com,emmanuel@944.com,', $title, $body);
	// send_email('juggernaut@944.com', 'Juggernaut', 'emmanuel@944.com,', $title, $body);
}

?>
