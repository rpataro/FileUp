<?php 

//settings for 944

$default_lang = "en"; 
$database_name = "944x_944media";
$client_name = "944 Media";
$client_id = "944";
$fspath = "/var/www/html/com944x/private_cdata/944/file_structure";
?>