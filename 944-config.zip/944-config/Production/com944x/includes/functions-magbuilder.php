<?php
/////////////////////////////////////////////////////////////////////////
// Original Magbuilder Functions from Lavon, used in some functions below
/////////////////////////////////////////////////////////////////////////

include_once('/var/www/html/proof944/public_html/magbuilder/functions/compositeImages.php');
include_once('/var/www/html/proof944/public_html/magbuilder/functions/imagesizer.php');

define("DB_SERVER","prod-private-db.944.com");
define("DB_SERVER_USERNAME","admin");
define("DB_SERVER_PASSWORD","hautemag");
define("DB_DATABASE","944x_944media");
include_once("/var/www/html/proof944/public_html/magbuilder/functions/database.php");
//*/

// make a connection to the database... now
mag_db_connect() or die('Unable to connect to database server!');

function getTemplateSecSizes($templtID){
	switch($templtID){
		case'1':
		    $sizeIDs[0] = '1';
			break;
		case'2':
		    $sizeIDs[0] = '2';
		    $sizeIDs[1] = '2';
			break;
		case'3':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '4';
			break;
		case'4':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '4';
			break;
		case'5':
		    $sizeIDs[0] = '4';
		    $sizeIDs[1] = '3';
			break;
		case'6':
		    $sizeIDs[0] = '2';
		    $sizeIDs[1] = '2';
			break;
		case'7':
		    $sizeIDs[0] = '4';
		    $sizeIDs[1] = '3';
			break;
		case'8':
		    $sizeIDs[0] = '8';
		    $sizeIDs[1] = '8';
		    $sizeIDs[2] = '8';
		    $sizeIDs[3] = '8';
			break;
		case'9':
		    $sizeIDs[0] = '2';
		    $sizeIDs[1] = '8';
		    $sizeIDs[2] = '8';
			break;
		case'10':
		    $sizeIDs[0] = '8';
		    $sizeIDs[1] = '8';
		    $sizeIDs[2] = '2';
			break;
		case'11':
		    $sizeIDs[0] = '4';
		    $sizeIDs[1] = '3';
			break;
		case'12':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '3';
		    $sizeIDs[2] = '3';
			break;
		case'13':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '9';
		    $sizeIDs[2] = '9';
		    $sizeIDs[3] = '3';
			break;
		case'14':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '3';
		    $sizeIDs[2] = '9';
		    $sizeIDs[3] = '9';
			break;
		case'15':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '2';
		    $sizeIDs[2] = '9';
			break;
		case'16':
		    $sizeIDs[0] = '6';
		    $sizeIDs[1] = '8';
			break;
		case'17':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '3';
		    $sizeIDs[2] = '3';
			break;
		// 18 used to be 9, 9, 3, 3, but that appears to be wrong.. [EJC 2009-06-15]
		case'18':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '3';
		    $sizeIDs[2] = '9';
		    $sizeIDs[3] = '9';
			break;
		case'19':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '9';
		    $sizeIDs[2] = '9';
		    $sizeIDs[3] = '3';
			break;
		case'20':
		    $sizeIDs[0] = '2';
		    $sizeIDs[1] = '9';
		    $sizeIDs[2] = '3';
			break;
		case'21':
		    $sizeIDs[0] = '3';
		    $sizeIDs[1] = '9';
		    $sizeIDs[2] = '9';
		    $sizeIDs[3] = '9';
		    $sizeIDs[4] = '9';
			break;
		case'22':
		    $sizeIDs[0] = '9';
		    $sizeIDs[1] = '9';
		    $sizeIDs[2] = '9';
		    $sizeIDs[3] = '9';
		    $sizeIDs[4] = '3';
			break;

	}
	return $sizeIDs;
}

function insertPageSectionRecords($templtID, $pageID){
	$sizeIDs = getTemplateSecSizes($templtID);
	$size_of_template = count($sizeIDs);

	for ($i=0; $i < $size_of_template; $i++) { 
		// The DB section numbers are 1-based, so the passed section id starts at 1, rather than 0
		mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', $i + 1, 1, '', '', ".$sizeIDs[$i].")");
	}

	// Horrible old Lavon code
	// if($templtID == '1'){
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '1', '1', '', '', ".$sizeIDs[0].")");
	// 	//echo "--- 1 Secs Created<br>";
	// }else if($templtID == '2' || $templtID == '3' || $templtID == '4' || $templtID == '5' || $templtID == '6' || $templtID == '7' || $templtID == '11' || $templtID == '16'){
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '1', '1', '', '', ".$sizeIDs[0].")");
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '2', '1', '', '', ".$sizeIDs[1].")");
	// 	//echo "--- 2 Secs Created<br>";
	// }else if($templtID == '8'  || $templtID == '13' || $templtID == '14'|| $templtID == '18' || $templtID == '19'){
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '1', '1', '', '', ".$sizeIDs[0].")");
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '2', '1', '', '', ".$sizeIDs[1].")");
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '3', '1', '', '', ".$sizeIDs[2].")");
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '4', '1', '', '', ".$sizeIDs[3].")");
	// 	//echo "--- 4 Secs Created<br>";
	// }else if($templtID == '9' || $templtID == '10' || $templtID == '12' || $templtID == '15' || $templtID == '17' || $templtID == '20'){
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '1', '1', '', '', ".$sizeIDs[0].")");
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '2', '1', '', '', ".$sizeIDs[1].")");
	// 	mag_db_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$pageID."', '3', '1', '', '', ".$sizeIDs[2].")");
	// 	//echo "--- 3 Secs Created<br>";
	// }
	
}

function getCurrentNote($type, $rsvID){
	  if($type == '1'){
   	 	$tempresult2 = mag_db_query("SELECT co.company_name FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID WHERE oa.OAID = '".$rsvID."'");
		 $nameRe = mag_db_fetch_array($tempresult2);
		 $title = $nameRe['company_name'];
		 $title = addslashes($title.'-'.$rsvID);
	  }else if($type == '3'){
   	 	$tempresult2 = mag_db_query("SELECT editorial_title FROM orders_editorial WHERE editorialID = '".$rsvID."'");
		 $nameRe = mag_db_fetch_array($tempresult2);
		 $title = $nameRe['editorial_title'];
		 $title = addslashes($title.'-'.$rsvID);
	  }
	return addslashes($title);
}

function deletePendingFromMB($pgID, $and=''){
		//Delete all previous pending placements if this is a confirmed ad or editorial being placed
		$data_result = mag_db_query("SELECT mbs.*, mbp.pagenum, i.iss_name FROM magbuilder_book_sections as mbs LEFT JOIN magbuilder_pages as mbp ON mbp.id = mbs.pageID LEFT JOIN issues as i ON i.id = mbp.bookID WHERE mbs.pageID = '".$pgID."' AND mbs.status = 'Pending' ".$and." GROUP BY mbs.rsvItemID");
		while($data = mag_db_fetch_array($data_result)){
			if($data['type'] == '1'){
				 $tempresult2 = mag_db_query("SELECT co.company_name, u.email FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID LEFT JOIN users as u ON u.userid = co.company_primary_rep WHERE oa.OAID = '".$data['rsvItemID']."'");
				 $nameRe = mag_db_fetch_array($tempresult2);
				 $title = $nameRe['company_name'];
				 $title = $title.'-'.$data['rsvItemID'];
				//Email Rep to let them know that there pending ad is being deleted
			   $headers = "From: webmanager@944.com\r\n" .
				   'X-Mailer: PHP/' . phpversion() . "\r\n" .
				   "MIME-Version: 1.0\r\n" .
				   "Content-Type: text/html; charset=utf-8\r\n" .
				   "Content-Transfer-Encoding: 8bit\r\n\r\n";
			   
			   $message = '
				  <table valign="top" align="left" width="100%" cellspacing="0" cellpadding="3" border="0">
					<tr>
					  <td align="left" width="100%">Your Pending Placement on <strong>Pg.'.($data['pagenum']-1).' of '.$data['iss_name'].' Issue</strong> for <strong>'.$title.'</strong> In Magbuilder Has Been Deleted because the spot was just Sold to a "Confirmed" Ad!</td>
					</tr>
				  </table>';
			   if($nameRe['email'] != ''){ mail($data['email'].' ; webmanager@944.com', 'Your Pending Placement Has Been Deleted: ', $message, $headers); }
			   //if($nameRe['email'] != ''){ mail('webmanager@944.com', 'Your Pending Placement Has Been Deleted', $message, $headers); }
			}
	   }//End While
	   if(!mag_db_query("DELETE FROM magbuilder_book_sections where pageID = '".$pgID."' AND status = 'Pending' ".$and."")){
	     //return false;
	   }
	   return true;
}

function removePieceFromBook($linkID){
    $FOLD_ROOT = "/var/www/html/proof944/public_html/magbuilder/pageimages/";
    $PIECES_ROOT = "/var/www/html/proof944/public_html/magbuilder/pieces/";
    $lastPg = '';
    $allPgs = '';
	  //Find all pieces with that linkID passed and delete them from the database
    $allPieces = mag_db_query("SELECT * FROM magbuilder_pieces WHERE linkID = '".$linkID."'");
    while($row = mag_db_fetch_array($allPieces)){
       $whichPage = mag_db_query("SELECT * FROM magbuilder_book_sections WHERE pieceID = '".$row['id']."' AND status = 'Placed'");
       $page = mag_db_fetch_array($whichPage);
       if($page['pageID'] != $lastPg){
         $allPgs .= $page['pageID'].',';
         $lastPg = $page['pageID'];
       }
		 if($page['rsvItemID'] != ''){
      	 mag_db_query("UPDATE magbuilder_book_sections SET pieceID = '', status = 'Confirmed' WHERE pieceID = '".$row['id']."' AND status = 'Placed'");
		 }else{
      	 mag_db_query("UPDATE magbuilder_book_sections SET pieceID = '', status = '' WHERE pieceID = '".$row['id']."' AND status = 'Placed'");
		 }
	   //echo '<br>Deleting Piece From MB...'; 
       //mag_db_query("DELETE FROM magbuilder_pieces WHERE id = '".$row['id']."'");
       mag_db_query("UPDATE magbuilder_pieces SET used = '0' WHERE id = '".$row['id']."'");
	   //echo '<br>Removing Piece Folder From MB...'; 
       exec("rmdir ".$PIECES_ROOT.$row['bookID'].'/'.$row['id'].'/');

    }
	  
    //Rebuild page
    $allPgs = explode(",",$allPgs);
    for($i=0; $i<sizeof($allPgs); $i++){
       if($allPgs[$i] != ''){
		  //echo '<br>Building Page ('.$allPgs[$i].')...'; 
	   	  BuildPage($allPgs[$i]);
       }
    }
}

function BuildPage($pgID, $use_file_as_full_page = 0) {
	$FOLD_ROOT = "/var/www/html/proof944/public_html/magbuilder/pageimages/";
	$PIECES_ROOT = "/var/www/html/proof944/public_html/magbuilder/pieces/";

	$pageQuery = mag_db_query("SELECT templateID, bookID, id FROM magbuilder_pages WHERE id = '".$pgID."'");
	
	$page = mag_db_fetch_array($pageQuery);

	if (!is_dir($FOLD_ROOT.$page['bookID'].'/')) {
		exec("mkdir --mode=777 ".$FOLD_ROOT.$page['bookID'].'/');
		exec("chmod 777 ".$FOLD_ROOT.$page['bookID'].'/');
	}

	//Create Folder if doesn't exists
	if (!is_dir($FOLD_ROOT.$page['bookID'].'/'.$pgID.'/')) {
		//echo 'Making Folder for Page --'.$pgID.' BookID('.$page['bookID'].')';
		//mkdir($FLD_ROOT.$page['bookID'].'/'.$pgID.'/', 0777);
		exec("mkdir --mode=777 ".$FOLD_ROOT.$page['bookID'].'/'.$pgID.'/');
		exec("chmod 777 ".$FOLD_ROOT.$page['bookID'].'/'.$pgID.'/');
	}
	else{
		//echo 'Didnt Need to Make Folder for Page --'.$pgID.' BookID('.$page['bookID'].')';
	}
		
	//Get All Pieces that are supposed to be on the page
	$pieces = Array();
	$pageSecQuery = mag_db_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pgID."' AND status = 'Placed' ORDER BY section ASC");

	$l = 1;

	while($row = mag_db_fetch_array($pageSecQuery)){
		$pieces[$row['section']] = $row['pieceID'];
		$l++;
	}

	// If a file path is passed, use this file path as the full page image instead of building up a composite page (this is passed from production/magbuilder/sendto)
	if ($use_file_as_full_page) {
		$IMG_ROOT_PAGEIMAGES = $FOLD_ROOT.$page['bookID'].'/'.$pgID.'/';

		copy($use_file_as_full_page, $IMG_ROOT_PAGEIMAGES.'large.jpg');
		exec("chmod 777 ".$IMG_ROOT_PAGEIMAGES.'large.jpg');
		exec("convert -quality 30 -thumbnail 140x ".$use_file_as_full_page." ".$IMG_ROOT_PAGEIMAGES."small.jpg");
		exec("chmod 777 ".$IMG_ROOT_PAGEIMAGES."small.jpg");		
	}
	elseif (mag_db_num_rows($pageSecQuery) > 0) {
		switch ($page['templateID']) {
			case 1:
				if(!full_page($page['bookID'], $pgID, $pieces[1], $FOLD_ROOT, $PIECES_ROOT)) {
					$error = true;
				}
				break;

			case 2:
				if (!halfh_page($page['bookID'], $pgID, $pieces[1], $pieces[2], $FOLD_ROOT, $PIECES_ROOT)) {
					$error = true;
				}
				break;

			case 3:
				if (!thirdvleft_page($page['bookID'], $pgID, $pieces[1], $pieces[2], $FOLD_ROOT, $PIECES_ROOT)) {
					$error = true;
				}
				break;

			case 4:
				if (!thirdhtop_page($page['bookID'], $pgID, $pieces[1], $pieces[2], $FOLD_ROOT, $PIECES_ROOT)) {
					$error = true;
				}
				break;

			case 5:
				if(!thirdhbottom_page($page['bookID'], $pgID, $pieces[1], $pieces[2], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 6:
				if(!halfv_page($page['bookID'], $pgID, $pieces[1], $pieces[2], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 7:
				if(!thirdvright_page($page['bookID'], $pgID, $pieces[1], $pieces[2], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 8:
				if(!quarter_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3],$pieces[4], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 9:
				if(!halfvright_quarter_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 10:
				if(!halfvleft_quarter_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 11:
				if(!thirdhbottom_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 12:
				if(!template12_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 13:
				if(!template13_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $pieces[4], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 14:
				if(!template14_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $pieces[4], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 15:
				if(!template15_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 16:
				if(!template16_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 17:
				if(!template17_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
				break;

			case 18:
				if(!template18_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $pieces[4], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
			break;

			case 19:
				if(!template19_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $pieces[4], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
			break;

			case 20:
				if(!template20_page($page['bookID'], $pgID, $pieces[1],$pieces[2], $pieces[3], $FOLD_ROOT, $PIECES_ROOT)){
					$error = true;
				}
			break;
		} // end switch
	}
	
	else {
		unlink($FOLD_ROOT.$page['bookID']."/".$page['id']."/large.jpg");
		unlink($FOLD_ROOT.$page['bookID']."/".$page['id']."/small.jpg");
	}
}

function sendToMB($ADEDITID, $typeID, $sizeID, $order, $filepath, $bookID){
		/*
		//Correct LinkID field
		$pieceRe_query = mag_db_query("SELECT linkID FROM magbuilder_pieces WHERE id = '".$re['pieceID']."'");
		$pieceRe = mag_db_fetch_array($pieceRe_query);
		$split = explode("-", $pieceRe['linkID']);
		$linkBack_query = mag_db_query("SELECT * FROM job_tickets WHERE (TID = '".$split[1]."' OR OTID = '".$split[1]."') AND OT = '".$re['type']."'");
		*/
	
		$linkID = $typeID."-".$ADEDITID;
		echo '<br>Removing Piece From Book If there was one sent already...';
		removePieceFromBook($linkID);

  		$qry = "INSERT INTO magbuilder_pieces (bookID,size,linkID) VALUES ('".$bookID."','".$sizeID."','".$linkID."') ";
  		mag_db_query($qry);
      	$curPieceID = mag_db_insert_id();
      
		echo '<br>Going to Send Piece over to MB...';
  		//If the book has no pieces folder yet create it.
        $FLD_ROOT = '/var/www/html/proof944/public_html/magbuilder/pieces/'.$bookID.'/';
        if(!is_dir($FLD_ROOT)){
            exec("mkdir --mode=777 ".$FLD_ROOT);
      	    if(!is_dir($FLD_ROOT)){ 
              echo '<br>Book Folder was not created Successfully!';
			  exit;
            }
            exec("chmod 777 ".$FLD_ROOT);
      	}
  		
      	//Copy each piece to magbuilder pieces folder
        $IMG_ROOT = '/var/www/html/proof944/public_html/magbuilder/pieces/'.$bookID.'/'.$curPieceID.'/';
        if(!is_dir($IMG_ROOT)){
            exec("mkdir --mode=777 ".$IMG_ROOT);
      	    if(!is_dir($IMG_ROOT)){
              echo '<br>Pieces Folder was not created Succesfully!';
			  exit;
            }
            exec("chmod 777 ".$IMG_ROOT);
      	}

      	$IMG_COPYTO = $IMG_ROOT.'large.jpg';
      	if (!copy($filepath, $IMG_COPYTO)) {
            echo '<br>Copy to Pieces Folder was NOT Succesful! Check the server chris your file ('.$filepath.') you passed doesn\'t even exists!';
			exit;
        }else{
            echo '<br>Copy to Pieces Folder Worked This Time! you passed ('.$filepath.')';
		}
        exec("chmod 777 ".$IMG_COPYTO);
        //Create the pieces' thumb
        #############################################################################################
        $thumb = array(140, '181');
       
        $use_imagecreatetruecolor = true;
        $use_imagecopyresampled = false;
        $JPG_QUALITY	= 100;  
        #############################################################################################
        $sml_pht = resizer_main('small', $filepath, '', $thumb[0],$thumb[1], $IMG_ROOT);
        exec("chmod 777 ".$IMG_ROOT."small.jpg");
  
	    $pos_qry = "SELECT mbs.pageID, mbs.id FROM magbuilder_book_sections as mbs LEFT JOIN magbuilder_pages as mp ON mp.id = mbs.pageID where mbs.rsvItemID = '".$ADEDITID."' AND ( mbs.status = 'Confirmed' OR mbs.status = 'Placed') ORDER BY mp.pagenum ASC, mbs.section ASC LIMIT ".($order - 1).", ".$order."";
		echo '<br>Going to Run Placement Query... [ '.$pos_qry.' ]';
		$pos_re = mag_db_query($pos_qry);
		$pos = mag_db_fetch_array($pos_re);
		// [EJC 2009-02-27] removed as it was showing up in Juggs
		// print_r($pos);
		
		//Only Place piece where it needs to go if there is a confirmed placement for it
		if(mag_db_num_rows($pos_re) > 0){
			//Now Add Piece To Section of Page Confirmed on
			echo "<br>UPDATE magbuilder_book_sections SET pieceID = '".$curPieceID."', status = 'Placed', removed = 0 WHERE id = '".$pos['id']."'";
			mag_db_query("UPDATE magbuilder_book_sections SET pieceID = '".$curPieceID."', status = 'Placed', removed = 0 WHERE id = '".$pos['id']."'");
			mag_db_query("UPDATE magbuilder_pieces SET used = '1' WHERE id = '".$curPieceID."'");
			echo '<br>Updating Piece Record as used...';
			echo '<br>Starting Build Page...';
			BuildPage($pos['pageID']);
			echo '<br>Build Page Finished...';
			//echo 'Built PgID-'.$pos['pageID'].' With - '.$curPieceID;
		}
		
}

function correctPending($type){
	if($type == 'ads'){
		$pending_result = mag_db_query("SELECT oa.IssueID, jt.ticket_name, oa.OAID, o.probability, mbs.*, mbp.pagenum FROM orders_adsales as oa LEFT JOIN orders as o ON o.OID = oa.OID LEFT JOIN magbuilder_book_sections as mbs ON mbs.rsvItemID = oa.OAID LEFT JOIN magbuilder_pages as mbp ON mbp.id = mbs.pageID LEFT JOIN job_tickets as jt ON jt.OTID = oa.OAID AND jt.OT = '1' WHERE o.probability = '100' AND mbs.status = 'Pending' ORDER BY oa.IssueID");
	}else{
		$pending_result = mag_db_query("SELECT oe.issueID, jt.ticket_name, oe.editorialID, mbs.*, mbp.pagenum FROM orders_editorial as oe LEFT JOIN magbuilder_book_sections as mbs ON mbs.rsvItemID = oe.editorialID LEFT JOIN magbuilder_pages as mbp ON mbp.id = mbs.pageID LEFT JOIN job_tickets as jt ON jt.OTID = oe.editorialID AND jt.OT = '3' WHERE mbs.status = 'Pending' ORDER BY oe.issueID");
	}
	while($pending_re = mag_db_fetch_array($pending_result)){
		
		$sec_result = mag_db_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pending_re['pageID']."' AND section = '".$pending_re['section']."' AND status != 'Pending' ");
		$sec_re = mag_db_fetch_array($sec_result);

		$pieceQuery = '';
		for($x=0; $x < sizeof($usedPieces); $x++){
			if($usedPieces[$x] != ''){ $pieceQuery .= " AND id != '".$usedPieces[$x]."' "; }
		}
		$piece_result = mag_db_query("SELECT * FROM magbuilder_pieces WHERE linkID = '".$pending_re['type']."-".$pending_re['rsvItemID']."' ".$pieceQuery." ORDER BY id ASC");
		if(mag_db_num_rows($piece_result) > 0){
			$piece = mag_db_fetch_array($piece_result);
			if(!mag_db_query("UPDATE magbuilder_book_sections SET rsvItemID = '".$pending_re['rsvItemID']."', status = 'Placed', removed = 0, pieceID = '".$piece['id']."'  WHERE id = '".$sec_re['id']."' ")){
				echo "Placement Reservation Was Not Saved for: (".$pending_re['rsvItemID'].") ! - Contact webmanager@944.com";
			}else{
				deletePendingFromMB($pending_re['pageID'], "AND section = '".$pending_re['section']."'");
			}
			$usedPieces[$i] = $piece['id'];
			mag_db_query("UPDATE magbuilder_pieces SET used = '1' WHERE id = '".$piece['id']."' ");
			BuildPage($sec_re['pageID']);
		}else{
			if(!mag_db_query("UPDATE magbuilder_book_sections SET rsvItemID = '".$pending_re['rsvItemID']."', status = 'Confirmed', removed = 0 WHERE id = '".$sec_re['id']."' ")){
				echo "Placement Reservation Was Not Saved for: (".$pending_re['rsvItemID'].") ! - Contact webmanager@944.com";
			}else{
				deletePendingFromMB($pending_re['pageID'], "AND section = '".$pending_re['section']."'");
			}
		}
		// Removed as it was showing up in Juggernaut
		// [EJC 2009-02-27]
		// echo "Just Did------------------<br>".print_r($pending_re)."<br><br>";
	}
	///*
	
}

function createHTMLLinkToMBI($ADEDITID, $bookID, $status, $popup = false, $extr=''){
	global $user_permissions, $myuser;
	//are they are magbuilder admin?
  	$m="f";
  	if ($user_permissions[$myuser['userid']]['production']['magbuilderadmin']=="1") {
    	$m="t";
  	}

	$link = "<a href='http://proofcenter.944.com/magbuilder/inventory/?id=". $bookID ."&adeditID=". $ADEDITID ."&type=1&pStatus=".$status."&user=". $myuser['userid'] ."&m=". $m . $extr . "' target='".($popup == true ? " _blank" : "_self")."' ><img alter='Inventory System' src='http://944.myjuggernaut.com/images/icons/layout_content.gif' border=0></a>";
	
	return $link;
}


//////////////////////////
// Magbuilder Functions
// /production/magbuilder2
//////////////////////////

function mb_save_page_number($pagenum, $id) {
	$update_pagenum_query = "UPDATE magbuilder_pages SET pagenum = '".$pagenum."' WHERE id = '".$id."'";
	$update_pagenum_result = mysql_query($update_pagenum_query);
}


function mb_save_placement($pkDATA) {
	$usedPieces = array();
	for ($i=0; $i < sizeof($pkDATA); $i++) {
		if ($pkDATA[$i]['Status'] == 'Pending') {
			# This might be the trouble insert that causes empty, duplicate book sections to get created, log to check
			logevent('*** DEBUG: Call from mb_save_placement on page_id '.$pkDATA[$i]['PGID'].' for adeditid '.$pkDATA[$i]['ADEDITID']);
			mysql_query("INSERT INTO magbuilder_book_sections (pageID, rsvItemID, section, status, type) VALUES('".$pkDATA[$i]['PGID']."', '".$pkDATA[$i]['ADEDITID']."', '".$pkDATA[$i]['Section']."', '".$pkDATA[$i]['Status']."', '".$pkDATA[$i]['Type']."')");
		}

		elseif ($pkDATA[$i]['Status'] == 'Confirmed') {
			$sec_result = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pkDATA[$i]['PGID']."' AND section = '".$pkDATA[$i]['Section']."' AND status != 'Pending' ");
			$sec_re = mysql_fetch_assoc($sec_result);

			$pieceQuery = '';
			
			for ($x=0; $x < sizeof($usedPieces); $x++) {
				if($usedPieces[$x] != ''){ $pieceQuery .= " AND id != '".$usedPieces[$x]."' "; }
			}
			
			$piece_result = mysql_query("SELECT * FROM magbuilder_pieces WHERE linkID = '".$sec_re['type']."-".$pkDATA[$i]['ADEDITID']."' ".$pieceQuery." ORDER BY id ASC");
			
			if (mysql_num_rows($piece_result) > 0) {
				$piece = mysql_fetch_assoc($piece_result);
				
				if (!mysql_query("UPDATE magbuilder_book_sections SET rsvItemID = '".$pkDATA[$i]['ADEDITID']."', status = 'Placed', pieceID = '".$piece['id']."', removed = 0  WHERE id = '".$sec_re['id']."' ")) {
					throw new Exception("Placement Reservation Was Not Saved for: (".$pkDATA[$i]['ADEDITID'].") ! - Contact webmanager@944.com");
				}

				$usedPieces[$i] = $piece['id'];
				mysql_query("UPDATE magbuilder_pieces SET used = '1' WHERE id = '".$piece['id']."' ");

				# TODO: Add exception for ad spreads, no reason to rebuild the page here as they're not built correctly, should pull from jpegs auto-created at upload
				BuildPage($sec_re['pageID']);
			}
			else {
				if (!mysql_query("UPDATE magbuilder_book_sections SET rsvItemID = '".$pkDATA[$i]['ADEDITID']."', status = '".$pkDATA[$i]['Status']."', removed = 0  WHERE id = '".$sec_re['id']."' ")) {
					throw new Exception("Placement Reservation Was Not Saved for: (".$pkDATA[$i]['ADEDITID'].") ! - Contact webmanager@944.com");
				}
			}

			$pending_result = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pkDATA[$i]['PGID']."' AND section = '".$pkDATA[$i]['Section']."' AND status = 'Pending' ");
			if (mysql_num_rows($pending_result) > 0) { deletePendingFromMB($pkDATA[$i]['PGID']); }
		} // end elseif 'Confirmed'
	} // end for loop

	return true;
}


function mb_show_run_sheet($bookID, $userid = 0, $can_place_all_ads = 1, $can_place_all_editorial = 1, $show_all_orders = 0, $can_place_houseads = 1) {
	if ($userid && !$can_place_all_ads) {
		// $only_users_orders_query = "AND orders.created_id = ".$userid;
		$only_users_orders_query = "AND '".$userid."' IN (SELECT userid FROM orders_reps WHERE order_type = 1 AND order_type_id = orders_adsales.OAID)";
//		$can_place_all_editorial = 0;
	}

	if ($show_all_orders) {
		$probability = 0;
	}
	else {
		$probability = 100;
	}

	$run_sheet_query = "SELECT orders_adsales.OAID AS 'order', 
		    company.company_name AS 'title', 
		    1 AS 'type', 
			job_tickets.TID AS 'ticket_id',
		    ad_size.ad_size_name AS 'size',
			(ad_size.ad_size_decimal - mb.size_decimal_used) AS 'size_decimal_left',
			ad_position.ad_position_name
		FROM orders 
		  INNER JOIN orders_adsales ON orders.OID = orders_adsales.OID 
		  INNER JOIN company ON orders.CID = company.CID 
		  INNER JOIN issues ON orders_adsales.IssueID = issues.id 
		  INNER JOIN pubs ON issues.pubid = pubs.id 
		  INNER JOIN ad_size ON orders_adsales.SizeID = ad_size.sizeID
		  INNER JOIN ad_position ON ad_position.positionID = orders_adsales.PosID
 		  LEFT JOIN job_tickets ON job_tickets.OT = 1 AND job_tickets.OTID = orders_adsales.OAID
		  LEFT JOIN (SELECT sum(ms.size_decimal) as size_decimal_used, rsvItemID FROM magbuilder_book_sections AS mbs LEFT JOIN magbuilder_pages AS mbp ON mbp.id = mbs.pageID LEFT JOIN magbuilder_sizes AS ms ON ms.size_id = mbs.sizeID WHERE mbp.bookID = ".$bookID." AND type = 1 GROUP BY rsvItemID) mb ON orders_adsales.OAID = mb.rsvItemID
		WHERE issues.id = ".$bookID."
		   AND orders.probability >= ".$probability."
		   AND orders_adsales.kill = '0'
		   AND (mb.rsvItemID IS NULL OR (ad_size.ad_size_decimal - mb.size_decimal_used) > .01)
		   $only_users_orders_query";
	
	if ($can_place_all_editorial) {
		$run_sheet_query .= "
			UNION ALL

			SELECT orders_editorial.editorialID AS 'order', 
			    editorial_title AS 'title', 
			    3 as 'type', 
				0 as 'ticket_id',
			    orders_editorial.editorial_length AS 'size',
				(orders_editorial.editorial_length - mb.size_decimal_used) AS 'size_decimal_left',
				'' AS ad_position_name
			FROM orders_editorial 
			  INNER JOIN issues ON orders_editorial.issueID = issues.id
			  INNER JOIN pubs ON orders_editorial.pubID = pubs.id 
			  LEFT JOIN (SELECT sum(ms.size_decimal) as size_decimal_used, rsvItemID FROM magbuilder_book_sections AS mbs LEFT JOIN magbuilder_pages AS mbp ON mbp.id = mbs.pageID LEFT JOIN magbuilder_sizes AS ms ON ms.size_id = mbs.sizeID WHERE mbp.bookID = ".$bookID." AND type = 3 GROUP BY rsvItemID) mb ON orders_editorial.editorialID = mb.rsvItemID
			WHERE issues.id = ".$bookID."
				AND orders_editorial.dead = 0
				AND (mb.rsvItemID IS NULL OR (orders_editorial.editorial_length - mb.size_decimal_used) > .01)";
	}

	if ($can_place_houseads) {
		$run_sheet_query .= "
			UNION ALL 
				SELECT houseads.id AS 'order', 
				    houseads.name AS 'title', 
				    4 as 'type', 
					0 as 'ticket_id',
				    'House Ad' AS 'size',
					0 AS 'size_decimal_left',
					'' AS ad_position_name
				FROM houseads 
				WHERE houseads.active = 1 AND (houseads.expiration_date = '0000-00-00' OR houseads.expiration_date >= DATE(NOW()))";
	}

	$run_sheet_query .= "
			ORDER BY type, ad_position_name, size, title";

	$run_sheet_result = mysql_query($run_sheet_query);

	if (!mysql_num_rows($run_sheet_result)) {
		echo '<p>Nothing left to place in run sheet.</p>';
	}
	while ($row = mysql_fetch_assoc($run_sheet_result)) {
		if ($row['type'] == 1) {
			$ticket_url = '/production/jobtickets/jobjacket/?id='.$row['ticket_id'];
		}
		elseif ($row['type'] == 3) {
			$ticket_url = '/editorial/details/view/?id='.$row['order'];
		}
		elseif ($row['type'] == 4) {
			$ticket_url = '/production/houseads/details/?id='.$row['order'];
		}
		?>
		<li id="unplaced_<?php echo $row['type']?>_<?php echo $row['order']?>" class="type_<?php echo $row['type']?>">
			<span style="float: left; padding-left: 3px; padding-right: 3px;">
				<a href="<?php echo $ticket_url?>" target="_blank"><img src="/images/ticket_icon.gif" border="0"></a>
			</span>
			<?php echo stripslashes($row['title'].' ('.$row['size'].(($row['ad_position_name'] != '' && $row['ad_position_name'] != 'None') ? ', '.$row['ad_position_name'] : '')).')'?>
			<?php
				// if ($row['size_decimal_left'] > .01 && $row['size_id'] != 160) {
				if ($row['size_decimal_left'] > .01) {
					echo '<br/><b>Partially Placed, '.$row['size_decimal_left'].' page'.(($row['size_decimal_left'] == 1) ? '' : 's').' remaining</b>';
				}
			?>
		</li>
		<?php
	}	
}


function mb_delete_page($pgID) {
	$pageEditingQuery = mysql_query("SELECT * FROM magbuilder_pages WHERE id = '".$pgID."' ");
	$row = mysql_fetch_array($pageEditingQuery);

	if ($row['national'] == '0') {
		$pagePiecesQuery = mysql_query("SELECT pieceID FROM magbuilder_book_sections WHERE pageID = '".$pgID."'");
		while ($pData = mysql_fetch_array($pagePiecesQuery)) {
			//Make all pieces that were on the page usable again
			mysql_query("UPDATE magbuilder_pieces SET used = '0' WHERE id = '".$pData['pieceID']."'");
		}

		$pending_result = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pgID."' AND status = 'Pending' ");

		if (mysql_num_rows($pending_result) > 0){ deletePendingFromMB($pgID); }

		mysql_query("DELETE FROM magbuilder_book_sections WHERE pageID = '".$pgID."'");
	
		if (is_file("/var/www/html/proof944/public_html/magbuilder/pageimages/".$row['bookID']."/".$pgID."/large.jpg")) {
			@unlink("/var/www/html/proof944/public_html/magbuilder/pageimages/".$pgID."/large.jpg");
		}

		if (is_file("/var/www/html/proof944/public_html/magbuilder/pageimages/".$row['bookID']."/".$pgID."/small.jpg")) {
			@unlink("/var/www/html/proof944/public_html/magbuilder/pageimages/".$pgID."/small.jpg"); 
		}

		if (is_dir("/var/www/html/proof944/public_html/magbuilder/pageimages/".$row['bookID']."/".$pgID."/")) { 
			rmdir("/var/www/html/proof944/public_html/magbuilder/pageimages/".$pgID."/"); 
		}
	}

   mysql_query("DELETE FROM magbuilder_pages WHERE id = '".$pgID."'");

	//Re-OrderPages
	$pgOrd = 1;
	$pagesQuery = mysql_query("SELECT * FROM magbuilder_pages WHERE bookID = '".$row['bookID']."' ORDER BY pagenum ASC");

	while ($tmprow = mysql_fetch_array($pagesQuery)) {
		mysql_query("UPDATE magbuilder_pages SET pagenum = '".$pgOrd."' WHERE id = '".$tmprow['id']."'");
		$pgOrd++;
	}

	//Update Issue table page count
	mysql_query("UPDATE issues SET pages = pages-1 WHERE id = '".$row['bookID']."'");

	if (mysql_num_rows(mysql_query("SELECT * FROM issues WHERE id = '".$row['bookID']."' AND iss_name LIKE CONVERT( _utf8 '%National%' USING latin1 )")) > 0) {
		//If Page is a national Page then delete it from all other books it is in
		$natlQuery = mysql_query("SELECT * FROM magbuilder_pages WHERE nationalPageID = '".$pgID."' ORDER BY bookID ASC");
		$curBID = '';

		if (mysql_num_rows($natlQuery) > 0) {
			while ($natl = mysql_fetch_array($natlQuery)) {
				mysql_query("DELETE FROM magbuilder_pages WHERE id = '".$natl['id']."'");
				if ($curBID == '') {
					$curBID = $natl['bookID'];
				}
				elseif ($curBID != $natl['bookID']) {
					//Re-OrderPages
					$pgOrd = 1;
					$pagesQuery = mysql_query("SELECT * FROM magbuilder_pages WHERE bookID = '".$curBID."' ORDER BY pagenum ASC");
					while ($tmprow = mysql_fetch_array($pagesQuery)) {
						mysql_query("UPDATE magbuilder_pages SET pagenum = '".$pgOrd."' WHERE id = '".$tmprow['id']."'");
						$pgOrd++;
					}

					//Update Issue table page count
					$curCount = mysql_num_rows(mysql_query("SELECT * FROM magbuilder_pages WHERE bookID = '".$curBID."' ORDER BY pagenum ASC"));

					mysql_query("UPDATE issues SET pages = '".$curCount."' WHERE id = '".$curBID."'");

					$curBID = $natl['bookID'];
				}
			}
		}
	}
	
	 return true;
}


function mb_add_page($bookID) {
	$pageCount = mysql_query("SELECT id FROM magbuilder_pages WHERE bookID = '".$bookID."'");
	$bookTotal = mysql_num_rows($pageCount);
	$bookTotal += 1;
	$sizeIDs = getTemplateSecSizes('1');

	$insertRe = mysql_query("INSERT INTO magbuilder_pages (bookID, pagenum, templateID) VALUES('".$bookID."','".$bookTotal."', '1') ");
	$recID = mysql_insert_id();

	mysql_query("INSERT INTO magbuilder_book_sections (pageID, section, type, status, categories, sizeID) VALUES('".$recID."', '1', '1', '', '', '".$sizeIDs[0]."')");

	$FLD_ROOT = '/var/www/html/proof944/public_html/magbuilder/pageimages/'.$bookID.'/'.$recID.'/';
	if (!is_dir($FLD_ROOT)) {
		mkdir($FLD_ROOT, 0777);
		exec("chmod 777 ".$FLD_ROOT);
	}

	$result = mysql_query("SELECT * FROM magbuilder_pages WHERE id = '".$recID."'");
	$x=0;
	$pages = '';
	$row = mysql_fetch_array($result);

	if ($row['templateID'] == 0) { $row['templateID'] = 1; }

	$thumb = '';
	$result2 = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$row['id']."' AND status != 'Pending' ORDER BY section ASC");
	$l = 0;
	$sec = Array();

	while ($secData = mysql_fetch_array($result2)) {
		if ($secData['type'] == '1') {
			//$secData['categories'] = '343,347,353';
			$tempresult2 = mysql_query("SELECT co.company_name FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID WHERE oa.OAID = '".$secData['rsvItemID']."'");
			$nameRe = mysql_fetch_array($tempresult2);
			$title = $nameRe['company_name'];

			if ($title != '') { $title = $title.'-'.$secData['rsvItemID']; }else{ $title = ''; }

			$cats = explode(",", $secData['categories']);
			$CatNames = '';
			for ($a=0; $a <= sizeof($cats); $a++) {
				if ($cats[$a] != '') {
					$adCats_data = mysql_fetch_assoc(mysql_query("SELECT * FROM company_categories WHERE id = '".$cats[$a]."' "));
					if ($adCats_data['name'] != '') { $CatNames .= '- '.$adCats_data['name'].' <br>'; }
				}
			}
		}

	if ($secData['productionApproved'] == '0000-00-00 00:00:00') { $approved = '0'; }else{ $approved = '1';  }

	$sec[] = Array('section' => $secData['section'], 'id' => $secData['id'], 'status' => $secData['status'], 'rsvItemID' => $secData['rsvItemID'], 'catgrys' => $secData['categories'], 'type' => $secData['type'], 'title' => $title, 'catNames' => $CatNames, 'approved' => $approved);
	$l++;
	} // end while

	$pages[] = Array('id' => $row['id'], 'title' => $row['title'], 'pagenum' => $row['pagenum'], 'color' => $row['color'], 'templateID' => $row['templateID'], 'national' => $row['national'], 'nationalSec' => $row['nationalSec'], 'thumbSrc' => $thumb, 'sections' => $sec, 'sectionCnt' => $l);
	$x++;

	//Update Issue table page count
	mysql_query("UPDATE issues SET pages = pages+1 WHERE id = '".$bookID."'");

	//Insert A National Page At the end of the national section in all books
	if (mysql_num_rows(mysql_query("SELECT * FROM issues WHERE id = '".$bookID."' AND iss_name LIKE CONVERT( _utf8 '%National%' USING latin1 )")) > 0) {
		$natlBks_Query = mysql_query("SELECT bookID, i.iss_name, MAX(pagenum) as endOfNat  FROM magbuilder_pages as mbp LEFT JOIN issues as i ON i.id = mbp.bookID WHERE nationalBookID = '".$bookID."' AND national = '1' GROUP BY bookID ");
		while ($row = mysql_fetch_array($natlBks_Query)) {
			if ($row['endOfNat'] != '' && $row['endOfNat'] != 0) {
				mysql_query("UPDATE magbuilder_pages SET pagenum = pagenum+1 WHERE pagenum > '".$row['endOfNat']."' AND bookID = '".$row['bookID']."' ");
				mysql_query("INSERT INTO magbuilder_pages (bookID, pagenum, templateID, national, nationalBookID, nationalPageID) VALUES('".$row['bookID']."', '".($row['endOfNat']+1)."', '1', '1', '".$bookID."', '".$recID."') ");
				//Update Issue table page count
				mysql_query("UPDATE issues SET pages = pages+1 WHERE id = '".$row['bookID']."'");
			}
		}
	}

	return $pages;
}


function mb_save_sec_type($type, $sec, $pgID) {
	$sql ="UPDATE magbuilder_book_sections SET type = '".$type."', rsvItemID = '0', status = '', categories = '', removed = 0 WHERE pageID = '".$pgID."' AND section = '".$sec."' AND status != 'Pending' "; 
	mysql_query($sql);
	$tmpPendingRe = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pgID."' AND status = 'Pending' AND section = '".$sec."'");

	if (mysql_num_rows($tmpPendingRe) > 0){ deletePendingFromMB($pgID, "AND section = '".$sec."' "); }

	return true;
}

function mb_save_cat_settings($pgID, $sec, $cats) {
	$sql ="UPDATE magbuilder_book_sections SET categories = '".$cats."', removed = 0 WHERE pageID = '".$pgID."' AND section = '".$sec."' AND status != 'Pending' "; 
	mysql_query($sql);
	return true;
}

function mb_set_template($templtID, $pageID) {
	$sql ="SELECT * FROM magbuilder_pages WHERE id = '".$pageID."'"; 
	$tempresult = mysql_query($sql);
	$row2 = mysql_fetch_array($tempresult);
	$bookID = $row2['bookID'];
	if ($row2['templateID'] != $templtID) {
		//if(is_file("/var/www/html/proof944/public_html/magbuilder/pageimages/".$bookID."/".$pageID."/large.jpg")){

		$mUResult = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pageID."' AND pieceID > 0");

		if (mysql_num_rows($mUResult) > 0) {
			while ($row = mysql_fetch_array($mUResult)) {
				//UPDATE the old pieces and flag them unused
				mysql_query("UPDATE magbuilder_pieces SET used = '0' WHERE id = '".$row['pieceID']."'");
			}
		}

		//DELETE the old pieces placements
		$tmpPendingRe = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pageID."' AND status = 'Pending'");
		if (mysql_num_rows($tmpPendingRe) > 0) { deletePendingFromMB($pageID); }

		mysql_query("DELETE FROM magbuilder_book_sections WHERE pageID = '".$pageID."'");
		//mysql_query("DELETE FROM magbuilder_notes WHERE pageID = '".$pageID."'");
		//Insert section Records into Magbuilder_book_sections for each page
		unlink("/var/www/html/proof944/www/magbuilder/pageimages/".$bookID."/".$pageID."/large.jpg");
		unlink("/var/www/html/proof944/www/magbuilder/pageimages/".$bookID."/".$pageID."/small.jpg");
		unlink("/var/www/html/proof944/www/magbuilder/pageimages/".$bookID."/".$pageID."/final.pdf");
		rmdir("/var/www/html/proof944/www/magbuilder/pageimages/".$bookID."/".$pageID."/");
		insertPageSectionRecords($templtID, $pageID);
      //} 

	}

	$sql1 = "UPDATE magbuilder_pages SET templateID = '".$templtID."' WHERE id = '".$pageID."'";
	$result = mysql_query($sql1);

	return true;
}

function mb_clear_placement($type, $Ad_Edt_ID, $book_id = NULL){
	$modified_pages = array();

	# Added a book_id check for clearing placement for House Ads; don't see any reason why it shouldn't also apply to all ads when clearing from a book, as it should only pertain to that particular book, unique ad/editorial ID per issue
	# Only drawback is you can no longer clear national placement from within a local book, but users shouldn't do this anyhow -- should be removed as an option altogether so it's not confusing
	if ($book_id) {
		$book_query = "AND mp.bookID = '$book_id' ";
	}

	$sec_result = mysql_query("SELECT mbs.*, mp.bookID FROM magbuilder_book_sections AS mbs LEFT JOIN magbuilder_pages AS mp ON mp.id = mbs.pageID WHERE mbs.type = '$type' AND mbs.rsvItemID = '$Ad_Edt_ID' $book_query");
	while ($sec_re = mysql_fetch_assoc($sec_result)) {
		$modified_pages[] = $sec_re['pageID'];
		if ($sec_re['status'] == 'Placed') {
			//removePieceFromBook($sec_re['type']."-".$sec_re['rsvItemID']);
			mysql_query("UPDATE magbuilder_pieces SET used = '0' WHERE id = '".$sec_re['pieceID']."' ");
			
			if (!mysql_query("UPDATE magbuilder_book_sections SET rsvItemID = '', status = '', pieceID = '0', removed = 1  WHERE id = '".$sec_re['id']."' ")) {
				return false;
			}

			BuildPage($sec_re['pageID']);
		}
		elseif ($sec_re['status'] == 'Pending') {
			mysql_query("DELETE FROM magbuilder_book_sections WHERE id = '".$sec_re['id']."' AND status = 'Pending' ");
		}
		else {
			if(!mysql_query("UPDATE magbuilder_book_sections SET rsvItemID = '', status = '', removed = 1 WHERE id = '".$sec_re['id']."' ")){
				return false;
			}
			else{
				# Upon successful deletion, also clear out the thumbnail for the page
				unlink('/var/www/html/proof944/www/magbuilder/pageimages/'.$sec_re['bookID'].'/'.$sec_re['pageID'].'/small.jpg');
				unlink('/var/www/html/proof944/www/magbuilder/pageimages/'.$sec_re['bookID'].'/'.$sec_re['pageID'].'/small-0.jpg');
				unlink('/var/www/html/proof944/www/magbuilder/pageimages/'.$sec_re['bookID'].'/'.$sec_re['pageID'].'/large.jpg');
				unlink('/var/www/html/proof944/www/magbuilder/pageimages/'.$sec_re['bookID'].'/'.$sec_re['pageID'].'/large-0.jpg');
				unlink('/var/www/html/proof944/www/magbuilder/pageimages/'.$sec_re['bookID'].'/'.$sec_re['pageID'].'/final.pdf');
				mysql_query("DELETE FROM magbuilder_notes WHERE pageID = '".$sec_re['pageID']."' AND section = '".$sec_re['section']."' ");
			}
		}
	}
	// return true;
	return $modified_pages;
}

function mb_show_all_templates($id) {
	$templates_query = "SELECT * FROM magbuilder_page_templates WHERE active = 1 ORDER BY id";
	$templates_result = mysql_query($templates_query);
	while ($row = mysql_fetch_assoc($templates_result)) {
		?>
		<div style="float: left; display: block; padding: 5px; width: 120px; height:150px;" onclick="changeTemplate(<?php echo $row['id']?>)">
			<?php echo mb_show_templated_page($row['id'], null, true)?>
			<a href="javascript:changeTemplate(<?php echo $row['id']?>)">Choose Template <?php echo $row['id']?></a>
		</div>
		<?php		
	}
}

function mb_show_page_type($array, $is_national_book = 0) {
	foreach ($array['sections'] as $key => $section) {
		if (!$previous_type && !$stop_now && $section['type'] == 1) {
			$previous_type = $type = '1';
		}
		elseif (!$previous_type && !$stop_now && $section['type'] == 3) {
			$previous_type = $type = '3';
		}
		elseif (!$previous_type && !$stop_now && $section['type'] == 4) {
			$previous_type = $type = '4';
		}
		elseif ($previous_type != $section['type'] && !$stop_now) {
			$previous_type = $type = 'Mixed';
			$stop_now = 1;
		}
	}

	if ($type == 1) {
		$type = 'Ad';
	}
	elseif ($type == 3) {
		$type = 'Editorial';
	}
	elseif ($type == 4) {
		$type = 'House Ad';
	}

	if ($array['national'] || $is_national_book) {
		$output = 'National '.$type;
	}
	else {
		$output = 'Local '.$type;
	}
	
	return $output;
}

function mb_thumbnail_found($array, $type, $css) {
	if ($css == 'display') {
		if ($type == 'thumb' && $array['thumbSrc']) {
			$output = 'visible';
		} 
		elseif ($type == 'thumb' && !$array['thumbSrc']) {
			$output = 'none';
		}
		elseif ($type == 'layout' && !$array['thumbSrc']) {		
			$output = 'visible';
		}
		else {
			$output = 'none';
		}
	}
	
	return $output;
}

function mb_show_title($array, $admin_view = 0, $pageid = 0, $section = 0) {
	if ($array['type'] == 1 && $array['rsvItemID']) {
		$order_query = "SELECT OID FROM orders_adsales WHERE OAID = '".$array['rsvItemID']."'";
		$order_result = mysql_query($order_query);
		list($OID) = mysql_fetch_row($order_result);

		$cleared_out_message = 'javascript:alert(\'This item has been removed and can be cleared out.\');';

		if ($OID) {
			$url = 'http://944.myjuggernaut.com/contacts/proposals/?edit=1&oid='.$OID.'&reloaded=true';
		}
		else {
			$url = $cleared_out_message;
		}

		if ($array['ticket_id']) {
			$ticket_url = 'http://944.myjuggernaut.com/production/jobtickets/jobjacket/?id='.$array['ticket_id'];		
		}
		else {
			$ticket_url = $cleared_out_message;
		}
	}
	elseif ($array['type'] == 3 && $array['rsvItemID']) {
		$url = 'http://944.myjuggernaut.com/editorial/details/view/?id='.$array['rsvItemID'];
	}
	elseif ($array['type'] == 4 && $array['rsvItemID']) {
		$url = '/production/houseads/details/?id='.$array['rsvItemID'];
	}

	$output = '<div id="page_section_'.$pageid.'_'.$section.'" class="rsv_'.$array['type'].'_'.$array['rsvItemID'].'">';

	// Don't display the wrench/clear icons if in admin view (choice of templates)
	if (!$admin_view) {
		$output .= '<div>';
		$output .= '<a href="javascript:showSettingsDialog('.$pageid.','.$section.',\''.$array['type'].'\',\''.$array['catgrys'].'\',\''.js_safe($array['title']).'\')" class="wrench_icon"></a>';

		// Only display the clear link if there's an ad placed on the page (has a title)
		if ($array['title'] || $array['status'] != '') {
			$output .= '<a href="javascript:clearPlacement('.$array['type'].','.$array['rsvItemID'].',\''.js_safe($array['title']).'\')" class="delete_icon"></a>';

			// Only display the ticket icon for ad sales; the link to the editorial center is in the hyperlinked editorial title
			if ($array['type'] == 1) {
				$output .= '<a href="'.$ticket_url.'" target="_blank" class="ticket_icon"></a>';
			}
		}

		$output .= '</div>';
		$output .= '<div class="cleaner"></div>';
	}

	$output .= '<div id="'.$pageid.'_'.$section.'_body" class="section_body">';

	if ($array['title']) {
		$output .= '<a href="'.$url.'" target="_blank" title="'.$array['title'].'">'.$array['title'].'</a>';
	}
	elseif ($array['status'] != '') {
		$output .= '<a href="'.$url.'" title="[Removed Item]">[Removed Item]</a>';
	}
	else {
		$output .= $array['catNames'];		
	}

	$output .= '</div>';

	$output .= '</div>';

	return stripslashes($output);
}

function mb_get_section_class ($array, $admin_view = 0) {

	$output = 'type_'.$array['type'].' ';

	if ($array['status'] == 'Placed' || $array['status'] == 'Confirmed' || $admin_view) {
		$output .= 'overlay';
	}
	elseif ($array['status'] == 'Pending') {
		$output .= 'overlay_pending';
	}
	else {
		$output .= 'overlay_available';
	}
	return $output;
}


function mb_show_templated_page($templateID, $sections_array = null, $admin_view = 0, $pageid = 0) {
	// Display section names if no $sections_array was passed and in admin_view (show all templates)
	if (!$sections_array && $admin_view) {
		$sections_array = array();
		$sections_query = "SELECT * FROM magbuilder_page_sections WHERE template_id = $templateID";
		$sections_result = mysql_query($sections_query);
		while ($row = mysql_fetch_assoc($sections_result)) {
			$sections_array[$row['section']]['catNames'] = stripslashes($row['name']);
			// Default new templates to being ads
			$sections_array[$row['section']]['type'] = 1;
		}
	}
	
	switch ($templateID) {
		case '1':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_full <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '2':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_half_border border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>
				<div id="<?php echo $pageid?>_1_window" class="layout_half <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '3':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_thirdv_border border_right <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>
				<div id="<?php echo $pageid?>_1_window" class="layout_twothirdv <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '7':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_twothirdv <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>
				<div id="<?php echo $pageid?>_1_window" class="layout_thirdv_border border_left <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '8':
			?>
			<div class="layout_wrap">
				<div class="left_column_half">
					<div id="<?php echo $pageid?>_0_window" class="layout_quarter_border_bottom border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
					</div>
					<div id="<?php echo $pageid?>_1_window" class="layout_quarter <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>
				</div>

				<div id="<?php echo $pageid?>_2_window" class="layout_quarter_border_bottom_left border_bottom border_left <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
				</div>
				<div id="<?php echo $pageid?>_3_window" class="layout_quarter_border_left border_left <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '12':
			?>
			<div class="layout_wrap">
				<div class="left_column">
					<div id="<?php echo $pageid?>_0_window" class="layout_third_square_border border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
					</div>
					<div id="<?php echo $pageid?>_1_window" class="layout_third_square <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>
				</div>

				<div id="<?php echo $pageid?>_2_window" class="layout_thirdv border_left <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
				</div>
				
				<div class="cleaner"></div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '13':
			?>
			<div class="layout_wrap">
				<div class="left_column">
					<div id="<?php echo $pageid?>_0_window" class="layout_third_square_border border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
					</div>

					<div id="<?php echo $pageid?>_1_window" class="layout_sixth_h_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>

					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_h <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>
				</div>
				
				<div id="<?php echo $pageid?>_3_window" class="layout_thirdv border_left <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '14':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_thirdv border_right <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>

				<div class="left_column">
					<div id="<?php echo $pageid?>_1_window" class="layout_third_square_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>

					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_v_border border_bottom <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>

					<div id="<?php echo $pageid?>_3_window" class="layout_sixth_v_border border_bottom border_left <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
					</div>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '15':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_thirdv border_right <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>

				<div class="left_column">
					<div id="<?php echo $pageid?>_1_window" class="layout_half_square border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>
				
					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_h <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
							<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '17':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_thirdv border_right <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>

				<div class="left_column">
					<div id="<?php echo $pageid?>_1_window" class="layout_third_square_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>
				
					<div id="<?php echo $pageid?>_2_window" class="layout_third_square <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
							<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '18':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_thirdv border_right <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>

				<div class="left_column">
					<div id="<?php echo $pageid?>_1_window" class="layout_third_square_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>

					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_h_border border_bottom <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>

					<div id="<?php echo $pageid?>_3_window" class="layout_sixth_h <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
					</div>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '19':
			?>
			<div class="layout_wrap">
				<div class="left_column">
					<div id="<?php echo $pageid?>_0_window" class="layout_third_square_border border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
					</div>

					<div id="<?php echo $pageid?>_1_window" class="layout_sixth_v_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>

					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_v_border border_bottom border_left <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>
				</div>

				<div id="<?php echo $pageid?>_3_window" class="layout_thirdv border_left <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;
			
		case '20':
			?>
			<div class="layout_wrap">
				<div class="left_column">
					<div id="<?php echo $pageid?>_0_window" class="layout_half_square border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
					</div>
				
					<div id="<?php echo $pageid?>_1_window" class="layout_sixth_h <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
							<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>
				</div>

				<div id="<?php echo $pageid?>_2_window" class="layout_thirdv border_left <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
					<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '21':
			?>
			<div class="layout_wrap">
				<div id="<?php echo $pageid?>_0_window" class="layout_thirdv border_right <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
				</div>

				<div class="left_column">
					<div id="<?php echo $pageid?>_1_window" class="layout_sixth_h_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>

					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_h_border border_bottom <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>

					<div id="<?php echo $pageid?>_3_window" class="layout_sixth_v_border border_bottom <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
					</div>

					<div id="<?php echo $pageid?>_4_window" class="layout_sixth_v_border border_bottom border_left <?php echo mb_get_section_class($sections_array[4], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[4], $admin_view, $pageid, 4)?>
					</div>
				</div>

			</div>
			<div class="cleaner"></div>
			<?php
			break;

		case '22':
			?>
			<div class="layout_wrap">
				<div class="left_column">
					<div id="<?php echo $pageid?>_0_window" class="layout_sixth_h_border border_bottom <?php echo mb_get_section_class($sections_array[0], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[0], $admin_view, $pageid, 0)?>
					</div>

					<div id="<?php echo $pageid?>_1_window" class="layout_sixth_h_border border_bottom <?php echo mb_get_section_class($sections_array[1], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[1], $admin_view, $pageid, 1)?>
					</div>

					<div id="<?php echo $pageid?>_2_window" class="layout_sixth_v_border border_bottom <?php echo mb_get_section_class($sections_array[2], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[2], $admin_view, $pageid, 2)?>
					</div>

					<div id="<?php echo $pageid?>_3_window" class="layout_sixth_v_border border_bottom border_left <?php echo mb_get_section_class($sections_array[3], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[3], $admin_view, $pageid, 3)?>
					</div>
				</div>

				<div id="<?php echo $pageid?>_4_window" class="layout_thirdv border_left <?php echo mb_get_section_class($sections_array[4], $admin_view)?> page_section">
						<?php echo mb_show_title($sections_array[4], $admin_view, $pageid, 4)?>
				</div>
			</div>
			<div class="cleaner"></div>
			<?php
			break;

		default:
			echo 'Unknown Template: '.$templateID;
			break;
	}
}

function mb_get_page($page_id) {
	$book_query = "SELECT bookID FROM magbuilder_pages WHERE id = '".$page_id."'";
	$book_result = mysql_query($book_query);
	list($bookID) = mysql_fetch_row($book_result);

	return mb_get_book($bookID, NULL, NULL, $page_id);
}

function mb_get_book($id, $type, $Ad_Edt_ID, $passed_page_id = NULL) {
	if ($type == '1') {
		$result3 = mysql_query("SELECT oa.*, asz.ad_size_name, asz.ad_size_decimal, asz.ad_size_decimal as maxselectable FROM orders_adsales as oa LEFT JOIN ad_size as asz ON oa.SizeID = asz.sizeID WHERE oa.OAID = '".$Ad_Edt_ID."' ");
		$row2 = mysql_fetch_assoc($result3);
		$maxSelPos = $row2['maxselectable'];
		$adsize = $row2['ad_size_name'];
		$adsizeD = $row2['ad_size_decimal'];
	}
	elseif ($type == '3') {
		$result3 = mysql_query("SELECT orders_editorial.*, orders_editorial.editorial_length as maxselectable FROM orders_editorial WHERE orders_editorial.editorialID = '".$Ad_Edt_ID."' ");
		$row2 = mysql_fetch_assoc($result3);
		$maxSelPos = $row2['maxselectable'];
		//$maxSelPos = '3';
		$adsize = '';
		$adsizeD = '*';
	}
	elseif ($type == '4') {
		$result3 = mysql_query("SELECT houseads.*, 1 as maxselectable FROM houseads WHERE houseads.id = '".$Ad_Edt_ID."' ");
		$row2 = mysql_fetch_assoc($result3);
		$maxSelPos = $row2['maxselectable'];
		$adsize = '';
		$adsizeD = '*';		
	}
	
	if($maxSelPos == ''){ $maxSelPos = '1'; }
	
	if ($type == '1') {
		// $tempresult2 = mysql_query("SELECT co.company_name, cc.id as CatID FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID LEFT JOIN company_categories as cc ON cc.id = co.CATID WHERE oa.OAID = '".$Ad_Edt_ID."'");
		$tempresult2 = mysql_query("SELECT co.company_name, cc.id as CatID, oa.internal_description, o.CID FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID LEFT JOIN company_categories as cc ON cc.id = co.CATID WHERE oa.OAID = '".$Ad_Edt_ID."'");

		$nameRe = mysql_fetch_array($tempresult2);

		$curAdTitle = $nameRe['company_name'];

		// if($curAdTitle != ''){ $curAdTitle = $curAdTitle.'-'.$Ad_Edt_ID; }else{ $curAdTitle = ''; }
		if ($curAdTitle != '') { 
			if ($nameRe['CID'] == 41263) {
				$curAdTitle = $curAdTitle.' - '.stripslashes($nameRe['internal_description']);
			}
			else {
				// $curAdTitle = $curAdTitle.'-'.$Ad_Edt_ID; 
				$curAdTitle = $curAdTitle; 
			}
		}
		else { 
			$curAdTitle = ''; 
		}
	}
	elseif ($type == '3') {
		//$secData['categories'] = '1,13,31';
		$tempresult2 = mysql_query("SELECT editorial_title, CATID as CatID FROM orders_editorial WHERE editorialID = '".$Ad_Edt_ID."'");
		$nameRe = mysql_fetch_array($tempresult2);
		$curAdTitle = $nameRe['editorial_title'];
		if($curAdTitle != ''){ $curAdTitle = $curAdTitle.'-'.$Ad_Edt_ID; }else{ $curAdTitle = ''; }
	}
	elseif ($type == '4') {
		$tempresult2 = mysql_query("SELECT name FROM houseads WHERE id = '".$Ad_Edt_ID."'");
		$nameRe = mysql_fetch_array($tempresult2);
		$curAdTitle = $nameRe['name'];
		if($curAdTitle != ''){ $curAdTitle = $curAdTitle.'-'.$Ad_Edt_ID; }else{ $curAdTitle = ''; }		
	}

	// Extra SQL query if a pageid is passed so that you can build an array of just that particular page
	if ($passed_page_id) {
		$passed_page_id_extra_query = " AND mbp.id = '".$passed_page_id."'";
	}

	$result = mysql_query("SELECT mbp.*, i.iss_name FROM magbuilder_pages as mbp LEFT JOIN issues as i ON i.id = mbp.bookID WHERE mbp.bookID = '".$id."'" . $passed_page_id_extra_query);

	$x = 0;
	$pages = '';

	while ($row = mysql_fetch_assoc($result)) {
		if ($row['national'] == '1') { 
			$result2 = mysql_query("SELECT mbp.* FROM magbuilder_pages as mbp WHERE mbp.id = '".$row['nationalPageID']."'");
			$row2 = mysql_fetch_assoc($result2);
			$row['templateID'] = $row2['templateID'];
		}

		// Added national_pageid into the array below so that national pages can be manipulated from within the local view
		$pageid = $row['id'];
		$national_pageid = $row['nationalPageID'];

		if ($row['templateID'] == 0) { $row['templateID'] = 1; }

		$file_national = '/var/www/html/proof944/www/magbuilder/pageimages/'.$row['nationalBookID'].'/'.$national_pageid.'/small.jpg';
		$file_local = '/var/www/html/proof944/www/magbuilder/pageimages/'.$row['bookID'].'/'.$pageid.'/small.jpg';

		if (file_exists($file_national) && $row['national']=='1') { 
			$thumb = 'http://proofcenter.944.com/magbuilder/pageimages/'.$row['nationalBookID'].'/'.$national_pageid.'/small.jpg?'.filemtime($file_national); 
			$thumbL = 'http://proofcenter.944.com/magbuilder/pageimages/'.$row['nationalBookID'].'/'.$national_pageid.'/large.jpg?'.filemtime($file_national);
		}
		elseif (file_exists($file_local) && $row['national']=='0') {
			$thumb = 'http://proofcenter.944.com/magbuilder/pageimages/'.$row['bookID'].'/'.$pageid.'/small.jpg?'.filemtime($file_local);
			$thumbL = 'http://proofcenter.944.com/magbuilder/pageimages/'.$row['bookID'].'/'.$pageid.'/large.jpg?'.filemtime($file_local);
		}
		else {
			unset($thumb);
			unset($thumbL);
		}

		// National pages have different ID numbers, but need to also be output in the returned array
		if ($row['national'] == '0') {
			// *** the removed = 0 was causing some issues.. order by id first to last instead to get the most recent good one
			// Might want to also sort by rsvItemID DESC, as there was a blank one on 2010-01-29.. 
			// $result2 = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pageid."' AND removed = 0 ORDER BY section ASC");
			$result2 = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$pageid."' GROUP BY section ORDER BY section ASC, rsvItemID DESC");
		}
		elseif ($row['national'] == '1') {
			// $result2 = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$national_pageid."' AND removed = 0 ORDER BY section ASC");
			$result2 = mysql_query("SELECT * FROM magbuilder_book_sections WHERE pageID = '".$national_pageid."' GROUP BY section ORDER BY section ASC, rsvItemID DESC");
		}

		$l = 0;
		$sec = array();

		while ($secData = mysql_fetch_assoc($result2)) {
			if ($secData['type'] == '1') {
				//$secData['categories'] = '343,347,353';

				// $tempresult2 = mysql_query("SELECT co.company_name FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID WHERE oa.OAID = '".$secData['rsvItemID']."'");
				$tempresult2 = mysql_query("SELECT co.company_name, jt.TID, oa.internal_description, o.CID FROM orders_adsales as oa LEFT JOIN orders as o ON oa.OID=o.OID LEFT JOIN company AS co ON co.CID=o.CID LEFT JOIN job_tickets AS jt ON jt.OTID = oa.OAID AND jt.OT = 1 WHERE oa.OAID = '".$secData['rsvItemID']."'");

				$catRe = mysql_fetch_assoc($tempresult2);
				$title = $catRe['company_name'];

				$ticket_id = $catRe['TID'];

				if ($title != '') { 
					if ($catRe['CID'] == 41263 && $catRe['internal_description']) {
						$title = $title.' ('.stripslashes($catRe['internal_description']).')';
					}
					else {
						$title = $title.'-'.$secData['rsvItemID']; 
					}
				}
				else { 
					$title = ''; 
				}
			
				$cats = explode(",", $secData['categories']);
				$CatNames = '';

				for ($a=0; $a <= sizeof($cats); $a++) {
					if ($cats[$a] != '') {
						$adCats_data = mysql_fetch_assoc(mysql_query("SELECT * FROM company_categories WHERE id = '".$cats[$a]."' "));
						if ($adCats_data['name'] != ''){ $CatNames .= '- '.$adCats_data['name'].' <br>'; }
					}
				}
			}

			elseif ($secData['type'] == '3') {
				//$secData['categories'] = '1,13,31';
				$tempresult2 = mysql_query("SELECT editorial_title FROM orders_editorial WHERE editorialID = '".$secData['rsvItemID']."'");
				$catRe = mysql_fetch_assoc($tempresult2);
				$title = $catRe['editorial_title'];

				$ticket_id = '';
			
				if ($title != ''){ $title = $title.'-'.$secData['rsvItemID']; }else{ $title = ''; }
			
				$cats = explode(",", $secData['categories']);
				$CatNames = '';

				for ($a=0; $a <= sizeof($cats); $a++) {
					if ($cats[$a] != '') {
						$adCats_data = mysql_fetch_assoc(mysql_query("SELECT * FROM editorial_categories WHERE id = '".$cats[$a]."' "));
						if ($adCats_data['name'] != '') { $CatNames .= '- '.$adCats_data['name'].' <br>'; }
					}
				}
			}

			elseif ($secData['type'] == '4') {
				$tempresult2 = mysql_query("SELECT name FROM houseads WHERE id = '".$secData['rsvItemID']."'");
				$catRe = mysql_fetch_assoc($tempresult2);
				$title = $catRe['name'];
				$ticket_id = '';
			
				// if ($title != ''){ $title = $title.'-'.$secData['rsvItemID']; }else{ $title = ''; }
			
				$cats = explode(",", $secData['categories']);
				$CatNames = '';

				for ($a=0; $a <= sizeof($cats); $a++) {
					if ($cats[$a] != '') {
						$adCats_data = mysql_fetch_assoc(mysql_query("SELECT * FROM editorial_categories WHERE id = '".$cats[$a]."' "));
						if ($adCats_data['name'] != '') { $CatNames .= '- '.$adCats_data['name'].' <br>'; }
					}
				}
			}

			//if($secData['pieceID'] == ''){ $secData['pieceID'] = 0; }
			if ($secData['productionApproved'] == '0000-00-00 00:00:00') { $approved = '0'; } else { $approved = '1';  }

			$array_index = $secData['section'] - 1;

	  		$sec[$array_index] = Array('section' => $secData['section'], 'id' => $secData['id'], 'status' => $secData['status'], 'rsvItemID' => $secData['rsvItemID'], 'ticket_id' => $ticket_id, 'catgrys' => $secData['categories'], 'type' => $secData['type'], 'title' => $title, 'catNames' => $CatNames, 'approved' => $approved);
			//, 'pID' => $secData['pieceID']
			$l++;
		}  

		if ($x < 1) {
			$pages[] = Array('CatID' => $nameRe['CatID'], 'bookName' => $row['iss_name'], 'size' => $adsize, 'sizeDecimal' => $adsizeD, 'maxSelPos' => $maxSelPos,'id' => $pageid, 'national_pageid' => $national_pageid, 'title' => $row['title'], 'pagenum' => $row['pagenum'], 'color' => $row['color'], 'templateID' => $row['templateID'], 'national' => $row['national'], 'nationalSec' => $row['nationalSec'], 'thumbSrc' => $thumb, 'sections' => $sec, 'sectionCnt' => $l, 'curAdEditTitle' => $curAdTitle);
		}
		else {
			$pages[] = Array('id' => $pageid, 'national_pageid' => $national_pageid, 'title' => $row['title'], 'pagenum' => $row['pagenum'], 'color' => $row['color'], 'templateID' => $row['templateID'], 'national' => $row['national'], 'nationalSec' => $row['nationalSec'], 'thumbSrc' => $thumb, 'thumbSrcL' => $thumbL, 'sections' => $sec, 'sectionCnt' => $l);
		}
		$x++;
	}

	return $pages;
}


function mb_display_page_number($pagenumber, $number_of_pages, $is_national_book = 0) {
	$right_page_read = '<div class="right_page_number">';
	$left_page_read = '<div class="left_page_number">';
	
	if ($is_national_book) {
		// If national, page number is just the pagenumber..
		$output = $pagenumber;

		// National pages all start with right reads
		if ($pagenumber % 2) {
			$page_read = $right_page_read;
			$output .= ' Right';
		}
		else {
			$page_read = $left_page_read;
			$output .= ' Left';
		}
	}
	else {
		if ($pagenumber == 1) {
			$page_read = $left_page_read;
			// $show_read = 0;
			$output = 'C2 Left';
		}
		elseif ($pagenumber == $number_of_pages - 1) {
			$page_read = $right_page_read;
			// $show_read = 0;
			$output = 'C3 Right';
		}
		elseif ($pagenumber == $number_of_pages) {
			$page_read = $left_page_read;
			// $show_read = 0;
			$output = 'C4 Back Cover';
		}
		else {
			$output = $pagenumber - 1;

			if ($pagenumber % 2) {
				$page_read = $left_page_read;
				$output .= ' Left';
			}
			else {
				$page_read = $right_page_read;
				$output .= ' Right';
			}
		}
	}

	$output = $page_read.$output.'</div>';
	return $output;
}

function mb_get_printed_page_number($pagenumber) {
	if ($pagenumber) {
		$output = $pagenumber - 1;
	}

	return $output;
}


function mb_display_page($pagenum_array, $number_of_pages, $is_national_book = 0) {
	$box_color = ($pagenum_array['national'] || $is_national_book) ? 'gray' : '#C9C9C9';

	// Need to pass the national pageid for any template and setting changes, but use the local pageid for the div in order to have page re-ordering work
	if ($pagenum_array['national_pageid']) {
		$pageid = $pagenum_array['national_pageid'];
	}
	else {
		$pageid = $pagenum_array['id'];
	}
	// 
	// if ($pagenum_array['pagenum'] % 2) {
	// 	$page_read = 'right_page_read';
	// }
	// else {
	// 	$page_read = 'left_page_read';
	// }

	if ($pagenum_array['thumbSrcL']) {
		$large_image_url = $pagenum_array['thumbSrcL'];
	}
	else {
		$large_image_url = "javascript: alert('Sorry, image has not yet been pushed to Magbuilder.');";
	}

	?>
	<li id="<?php echo $pagenum_array['id']?>" style="background-color: <?php echo $box_color?>" <?php echo ($pagenum_array['national'] || $is_national_book) ? 'class="reorder-disabled"' : ''; ?>>

		<div id="box_<?php echo $pageid?>" class="ad-box">
			<div id="header_<?php echo $pageid?>" class="mb_layout_pages_header">
				<?php echo mb_display_page_number($pagenum_array['pagenum'], $number_of_pages, $is_national_book)?>
			</div>

			<div class="toolbar" style="float: right; width: 20px;">
				<a href="<?php echo $large_image_url?>" target="_blank"><img src="/images/zoom.gif" class="flipbook_icon"></a>
				<a href="javascript:flipPage(<?php echo $pageid?>)"><img src="/images/icons/page_go.gif" border="0" class="flipbook_icon"></a>
				<a href="javascript:uploadPage(<?php echo $pageid?>)"><img src="/images/icons/upload_icon.png" border="0" class="flipbook_icon"></a>
				<a href="javascript:showTemplateDialog(<?php echo $pageid?>)"><img src="/images/icons/template.gif" border="0" class="flipbook_icon"></a>
				<a href="javascript:deletePage(<?php echo $pageid?>)"><img src="/images/red_x.gif" border="0" class="flipbook_icon"></a>
			</div>

			<div id="thumb_<?php echo $pageid?>" class="thumb" style="display: <?php echo mb_thumbnail_found($pagenum_array, 'thumb', 'display')?>">
				<?php if ($pagenum_array['thumbSrc']) : ?>
					<img src="<?php echo $pagenum_array['thumbSrc']?>" width="100" height="120">
				<?php else : ?>
					no image found
				<?php endif; ?>
			</div>

			<div id="layout_<?php echo $pageid?>" class="layout" style="display: <?php echo mb_thumbnail_found($pagenum_array, 'layout', 'display')?>">
				<?php echo mb_show_templated_page($pagenum_array['templateID'], $pagenum_array['sections'], false, $pageid)?>
			</div>
		</div>

		<div class="cleaner"></div>

		<div id="footer_<?php echo $pageid?>" class="mb_layout_pages_footer">
			<?php echo mb_show_page_type($pagenum_array, $is_national_book)?>
		</div>

		<div class="cleaner"></div>

	</li>
	<?php
}

function mb_get_book_stats($bookID) {
	// $output = 'Open Pages (Ads):<br/>';

	$stats_array = get_book_stats_array($bookID);

	$output .= '<table cellspacing=5 cellpadding=5 style="border: 1px #999 solid;">';
	$output .= '<tr>';
	$output .= '<td style="font-weight: bold;">Ad Size</b></td>';
	$output .= '<td style="font-weight: bold;">Open</td>';
	$output .= '<td style="font-weight: bold;">Pending</td>';
	$output .= '<td style="font-weight: bold;">Placed</td>';
	$output .= '</tr>';

	foreach ($stats_array as $id => $array) {
		$output .= '<tr>';
		$output .= '<td>'.$array['name'].'</td>';
		$output .= '<td align="center">'.$array['Open'].'</td>';
		$output .= '<td align="center">'.$array['Pending'].'</td>';
		$output .= '<td align="center">';
		if ($placed = $array['Placed'] + $array['Confirmed']) $output .= $placed;
		$output .= '</td>';
		$output .= '</tr>';
	}

	$output .= '</table>';
	$output .= '<br/>';

	// print_r($stats_array);
	
	return $output;
}


function mb_get_drag_drop_ids($item_drag, $page_drop) {
	$page_section = $page_drop;
	$exploded_page_section = explode('_', $page_section);

	$page_id = $exploded_page_section[0];

	// Database section starts at 1, not 0, so need to add 1 here
	$real_section = $exploded_page_section[1];
	$section_id =  $real_section + 1;
	
	$national_page = $exploded_page_section[4];


	$unplaced_type_id = $item_drag;
	$exploded_unplaced_type_id = explode('_', $unplaced_type_id);

	$type = $exploded_unplaced_type_id[1];
	$order_id = $exploded_unplaced_type_id[2];
	
	$return_array = array('page_id' => $page_id, 'real_section' => $real_section, 'section_id' => $section_id, 'type' => $type, 'order_id' => $order_id, 'national_page' => $national_page);
	return $return_array;
}

function mb_category_check($page_id, $section, $type, $order_id) {
	$category_query = "SELECT categories FROM magbuilder_book_sections WHERE pageID = '".$page_id."' AND section = '".$section."' ORDER BY id DESC LIMIT 1";
	$category_result = mysql_query($category_query);
	list($mbs_categories) = mysql_fetch_row($category_result);

	if ($mbs_categories) {
		if ($type == 1) {
			$order_cat_query = "SELECT company.CATID FROM company LEFT JOIN orders AS o ON o.CID = company.CID LEFT JOIN orders_adsales AS oa ON oa.OID = o.OID WHERE oa.OAID = '".$order_id."' AND company.CATID IN (".$mbs_categories.")";
			$order_cat_result = mysql_query($order_cat_query);
		}
		elseif ($type == 3) {
			$order_cat_query = "SELECT CATID FROM orders_editorial WHERE editorialID = '".$order_id."' AND CATID IN (".$mbs_categories.")";
			$order_cat_result = mysql_query($order_cat_query);		
		}
		
		list($category) = mysql_fetch_row($order_cat_result);
	}
	else {
		$category = TRUE;
	}

	return $category;
}

function mb_can_place($page_id, $section, $type, $order_id, $bookID) {
	$output = '';

	// Get the bookID of the page on which the user is trying to place the ad/editorial piece
	$page_book_id_query = "SELECT bookID FROM magbuilder_pages WHERE id = '".$page_id."'";
	$page_book_id_result = mysql_query($page_book_id_query);
	list($page_book_id) = mysql_fetch_row($page_book_id_result);

	// Check if an item has already been placed
	$page_status_query = "SELECT status FROM magbuilder_book_sections WHERE pageID = '".$page_id."' AND section = '".$section."' ORDER BY id DESC LIMIT 1";
	$page_status_result = mysql_query($page_status_query);
	list($page_status) = mysql_fetch_row($page_status_result);

	if ($page_status) {
		$output .= "ERROR: Item already placed there, needs to be cleared first.\n";
	}
	// $national_page isn't actually really passed yet.. may need to implement later
	if ($type == 1) {
		// $size_query = "SELECT orders_adsales.SizeID AS ad_size, ad_size.ad_size_decimal AS ad_size_decimal, mbs.sizeID AS mbs_size, mbs.type AS mbs_type, mbs.categories AS mbs_categories, mp.national AS national_page FROM orders_adsales LEFT JOIN ad_size ON ad_size.sizeID = orders_adsales.SizeID LEFT JOIN magbuilder_book_sections AS mbs ON mbs.pageID = '".$page_id."' AND mbs.section = '".$section."' LEFT JOIN magbuilder_pages AS mp ON mp.id = '".$page_id."' WHERE OAID = '".$order_id."' LIMIT 1";
		$size_query = "SELECT mb.size_decimal_used, (ad_size.ad_size_decimal - mb.size_decimal_used) AS 'size_decimal_left', ad_size.ad_size_decimal AS ad_size_decimal, ad_size.size_check AS size_check,  orders_adsales.SizeID AS ad_size, magbuilder_sizes.size_decimal AS mbs_size_decimal, mbs.sizeID AS mbs_size, mbs.type AS mbs_type, mbs.categories AS mbs_categories, mp.national AS national_page, ad_size.ad_spread FROM orders_adsales 
		LEFT JOIN ad_size ON ad_size.sizeID = orders_adsales.SizeID 
		LEFT JOIN magbuilder_book_sections AS mbs ON mbs.pageID = '".$page_id."' AND mbs.section = '".$section."' 
		LEFT JOIN magbuilder_sizes ON magbuilder_sizes.size_id = mbs.sizeID 
		LEFT JOIN magbuilder_pages AS mp ON mp.id = '".$page_id."' 
		LEFT JOIN (SELECT sum(ms.size_decimal) as size_decimal_used, rsvItemID FROM magbuilder_book_sections AS mbs LEFT JOIN magbuilder_pages AS mbp ON mbp.id = mbs.pageID LEFT JOIN magbuilder_sizes AS ms ON ms.size_id = mbs.sizeID WHERE mbp.bookID = ".$bookID." AND type = 1 GROUP BY rsvItemID) mb ON orders_adsales.OAID = mb.rsvItemID
		WHERE OAID = '".$order_id."' LIMIT 1"; 

		$size_result = mysql_query($size_query);

		$type_name = 'Ad';
	}
	elseif ($type == 3) {
		// $size_query = "SELECT orders_editorial.editorial_length AS ad_size, ad_size.ad_size_decimal AS mbs_size, mbs.sizeID AS mbs_size_id, mbs.type AS mbs_type, mbs.categories AS mbs_categories, mp.national AS national_page FROM orders_editorial LEFT JOIN magbuilder_book_sections AS mbs ON mbs.pageID = '".$page_id."' AND mbs.section = '".$section."' LEFT JOIN magbuilder_pages AS mp ON mp.id = '".$page_id."' LEFT JOIN ad_size ON ad_size.sizeID = mbs.sizeID WHERE orders_editorial.editorialID = '".$order_id."' LIMIT 1";
		$size_query = "SELECT mb.size_decimal_used, (orders_editorial.editorial_length - mb.size_decimal_used) AS 'size_decimal_left', orders_editorial.editorial_length AS ad_size_decimal, magbuilder_sizes.size_decimal AS mbs_size_decimal, ad_size.ad_size_decimal AS mbs_size, ad_size.size_check AS size_check, mbs.sizeID AS mbs_size_id, mbs.type AS mbs_type, mbs.categories AS mbs_categories, mp.national AS national_page FROM orders_editorial LEFT JOIN magbuilder_book_sections AS mbs ON mbs.pageID = '".$page_id."' AND mbs.section = '".$section."' 
		LEFT JOIN magbuilder_pages AS mp ON mp.id = '".$page_id."' 
		LEFT JOIN magbuilder_sizes ON magbuilder_sizes.size_id = mbs.sizeID 
		LEFT JOIN ad_size ON ad_size.sizeID = mbs.sizeID 
		
		LEFT JOIN (SELECT sum(ms.size_decimal) as size_decimal_used, rsvItemID FROM magbuilder_book_sections AS mbs LEFT JOIN magbuilder_pages AS mbp ON mbp.id = mbs.pageID LEFT JOIN magbuilder_sizes AS ms ON ms.size_id = mbs.sizeID WHERE mbp.bookID = ".$bookID." AND type = 3 GROUP BY rsvItemID) mb ON orders_editorial.editorialID = mb.rsvItemID
		
		WHERE orders_editorial.editorialID = '".$order_id."' LIMIT 1";
		$size_result = mysql_query($size_query);

		$type_name = 'Editorial';
	}
	elseif ($type == 4) {
		$size_query = "SELECT mb.size_decimal_used, 0 AS 'size_decimal_left', 1 AS ad_size_decimal, magbuilder_sizes.size_decimal AS mbs_size_decimal, ad_size.ad_size_decimal AS mbs_size, ad_size.size_check AS size_check, mbs.sizeID AS mbs_size_id, mbs.type AS mbs_type, mbs.categories AS mbs_categories, mp.national AS national_page FROM houseads LEFT JOIN magbuilder_book_sections AS mbs ON mbs.pageID = '".$page_id."' AND mbs.section = '".$section."' 
		LEFT JOIN magbuilder_pages AS mp ON mp.id = '".$page_id."' 
		LEFT JOIN magbuilder_sizes ON magbuilder_sizes.size_id = mbs.sizeID 
		LEFT JOIN ad_size ON ad_size.sizeID = mbs.sizeID 
		
		LEFT JOIN (SELECT sum(ms.size_decimal) as size_decimal_used, rsvItemID FROM magbuilder_book_sections AS mbs LEFT JOIN magbuilder_pages AS mbp ON mbp.id = mbs.pageID LEFT JOIN magbuilder_sizes AS ms ON ms.size_id = mbs.sizeID WHERE mbp.bookID = ".$bookID." AND type = 4 GROUP BY rsvItemID) mb ON houseads.id = mb.rsvItemID
		
		WHERE houseads.id = '".$order_id."' LIMIT 1";

		$size_result = mysql_query($size_query);
		
		$type_name = 'House Ads';
	}

	// Check if trying to place a local ad on a national book and vice versa
	if ($bookID != $page_book_id) {
		$output .= "ERROR: Local/National ".$type_name." Mismatch\n";
	}

	// Check if there is a category assigned to the page, and error out if the item being placed doesn't match the category
	if (!mb_category_check($page_id, $section, $type, $order_id)) {
		$output .= "ERROR: ".$type_name." Category doesn't match Template Category\n";
	}

	while ($row = mysql_fetch_assoc($size_result)) {
		// Can't use the actual sizeID's as the MB ones don't match up to the orders ones.. thanks Lavon!!
		// if ($row['ad_size'] != $row['mbs_size']) {

		if ($row['size_decimal_left']) {
			// $output .= "sdl = ".$row['size_decimal_left'].", msd = ".$row['mbs_size_decimal'];
			$size_after_placement = $row['size_decimal_left'] - $row['mbs_size_decimal'];
		}
		else {
			$size_after_placement = $row['ad_size_decimal'] - $row['mbs_size_decimal'];			
		}

		# If it's an ad spread (ad_spread = 1), allow the ad to be split only into full pages (mbs_size = 1), otherwise don't allow splitting for ads, only editorial
		# Also add an exception for ad sizes with size_check disabled
		if ($row['ad_spread'] && $type == 1 && $row['mbs_size'] != 1 && $row['mbs_size'] != 2) {
			$output .= "ERROR: ".$type_name." spreads can only be split between full pages\n";
		}
		// if (abs($row['ad_size_decimal'] - $row['mbs_size_decimal']) > .01) {
		elseif (abs($size_after_placement) > .01 && $type == 1 && !$row['ad_spread']  && $row['size_check']) {
			$output .= "ERROR: ".$type_name." Size doesn't match Template Size\n";
		}
		elseif ($size_after_placement < -.01 && $type == 3) {
			if ($row['size_decimal_left']) {
				$output .= "ERROR: Remaining ".$type_name." Size is smaller than this Template Size\n";
			}
			else {
				$output .= "ERROR: ".$type_name." Size doesn't match Template Size\n";
			}
		}

		if ($type != $row['mbs_type']) {
			$output .= "ERROR: ".$type_name." Type doesn't match Template Type\n";
		}
	}

	if ($output) {
		return $output;
	}
	else {
		return 1;
	}
}


?>
