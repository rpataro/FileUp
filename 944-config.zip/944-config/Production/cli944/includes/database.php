<?php
if (!isset($database_name)) {
	$database_name = '944x_944media';
}

$db_server = "prod-private-db.944.com";
$db_user="admin";
$db_password="hautemag";
$db = mysql_connect($db_server,$db_user,$db_password);
mysql_select_db($database_name,$db);

$d = explode("?",$_SERVER['REQUEST_URI']);
$path = explode("/",$d[0]);

error_reporting("E_ALL");
?>