<?php  if ( ! defined("BASEPATH")) exit("No direct script access allowed");
$config["UPLOADED_BACKUPS_PATH"]="/var/www/html/phpforms/backup/";
$config["UPLOADED_FILES_PATH"]="/var/www/html/phpforms/file/";
$config["UPLOADED_TMP_FILES_PATH"]="/var/www/html/phpforms/tmp/";
$config["URL_BASE"]="http://reg.accentsandfurnishings.com/";
$config["UPLOADED_AVATARS_PATH"]="/var/www/html/phpforms/avatar/";
$config["DIRECTORY"]="/var/www/html/phpforms/";
$config["DB_INITIALIZED"]=true;
$config["USER_INITIALIZED"]=false;
$config["LANGUAGE"]="english";      
$config["USER_INITIALIZED"]=true;
$config["LICENSE"]="#3e467613bc23952cef338ace300b189f";

