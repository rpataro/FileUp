<?php

/*
$db = mysql_connect('localhost',"root","root");
mysql_select_db("payment_gateway",$db);


$db = mysql_connect('stage-private-db.944.com',"admin","hautemag");
mysql_select_db("payment_gateway",$db);
*/

$db = mysql_connect('prod-private-db.944.com',"admin","hautemag");
mysql_select_db("payment_gateway",$db);

?>