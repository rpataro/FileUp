<?php
  $_SERVER['SUBSCRIPTION_DOC_ROOT'] = '/var/www/html/payment_gateway';
?>