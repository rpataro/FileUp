<?php

$ftp_server = 'ftp.944.com';
$ftp_user = 'admin944';
$ftp_pass = '944m3d14';

?>
