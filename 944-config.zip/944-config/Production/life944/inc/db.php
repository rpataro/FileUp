<?php
$db = mysql_connect('prod-private-db.944.com',"admin","hautemag");
mysql_select_db("944web",$db);
?>